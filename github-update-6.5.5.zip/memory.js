'use strict';
/* Lazzy sound 3.8 — keeps RAM in check.
   • every in-memory cache is capped (oldest entries go first) and trimmed every 45 s;
   • when Android reports memory pressure or the app goes to the background (onTrimMemory), caches are emptied,
     the pre-buffered next track is released and decorative canvases free their pixels. */
const MEM_CAPS={searchCache:24,audiusApiCache:80,tintCache:120,archiveMetadataCache:60,infoCache:40,resolvedStreams:60,hintCache:80,albumTrackCache:30,lyricsCache:20,lyrMem:20,catalogCache:40};
/* no eval/new Function (strict Content-Security-Policy): explicit getters for the global caches */
const MEM_GET={searchCache:()=>typeof searchCache!=='undefined'?searchCache:null,audiusApiCache:()=>typeof audiusApiCache!=='undefined'?audiusApiCache:null,tintCache:()=>typeof tintCache!=='undefined'?tintCache:null,archiveMetadataCache:()=>typeof archiveMetadataCache!=='undefined'?archiveMetadataCache:null,infoCache:()=>typeof infoCache!=='undefined'?infoCache:null,resolvedStreams:()=>typeof resolvedStreams!=='undefined'?resolvedStreams:null,hintCache:()=>typeof hintCache!=='undefined'?hintCache:null,albumTrackCache:()=>typeof albumTrackCache!=='undefined'?albumTrackCache:null,lyricsCache:()=>typeof lyricsCache!=='undefined'?lyricsCache:null,lyrMem:()=>typeof lyrMem!=='undefined'?lyrMem:null,catalogCache:()=>typeof catalogCache!=='undefined'?catalogCache:null};
const memRef=name=>{try{return MEM_GET[name]?.()??null}catch{return null}};
function trimCaches(scale=1){
  for(const [name,cap] of Object.entries(MEM_CAPS)){const m=memRef(name);if(!(m instanceof Map))continue;const keep=Math.floor(cap*scale);
    while(m.size>keep)m.delete(m.keys().next().value)}
}
setInterval(()=>trimCaches(1),45000);
window.__lazzyTrim=level=>{
  /* Android levels: 5/10/15 = running moderate/low/critical, 20 = UI hidden, 40+ = background */
  const hard=level>=15&&level!==20||level>=40;
  trimCaches(hard?0:.4);
  if(typeof releaseWarm==='function')releaseWarm();
  if(level>=20){if(typeof FxEngine!=='undefined'&&FxEngine.free)FxEngine.free();if(typeof Backdrop!=='undefined')Backdrop.release()}
  if(hard&&typeof store!=='undefined'){try{const c=store.get('lyrCache',{});const k=Object.keys(c);if(k.length>10){for(const x of k.slice(0,k.length-10))delete c[x];store.set('lyrCache',c)}}catch{}}
};
