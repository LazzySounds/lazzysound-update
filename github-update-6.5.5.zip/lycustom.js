'use strict';
/* Lazzy sound 5.7.1 — lyrics look (alignment, size, weight, font, colour, glow), the «Чистый» mode (one line, dead centre,
   nothing else on screen) and custom backgrounds: animated geometric lines, plain black, or your own picture / GIF / video. */

/* ---------- lyrics look ---------- */
const LYC_DEF={align:'auto',size:0,weight:0,font:'app',color:'',dim:0,glow:true,width:0,outline:'dark',olw:1.5,olc:'#000000',contrast:true};
const LYC_OL={none:'Нет',dark:'Тёмная',light:'Светлая',accent:'Акцент',custom:'Своя'};
const LYC_FONTS={app:'Как в приложении',light:'Тонкий',serif:'С засечками',mono:'Моноширинный',round:'Округлый'};
const LYC_FONT_CSS={app:'',light:'"Inter",-apple-system,"Segoe UI Light","Segoe UI",Roboto,sans-serif',serif:'Georgia,"Times New Roman",serif',mono:'"JetBrains Mono",Consolas,"Courier New",monospace',round:'"Nunito","Arial Rounded MT Bold","Segoe UI",sans-serif'};
const lyc=()=>({...LYC_DEF,...(store.get('lyCustom',{})||{})});
function applyLyCustom(){
  const c=lyc(),s=stage.style;stage.dataset.lyAlign=c.align;
  s.setProperty('--lyc-fs',c.size?c.size+'px':'');s.setProperty('--lyc-fw',c.weight||'');s.setProperty('--lyc-font',fontCss(c.font));
  s.setProperty('--lyc-dim',c.dim?String(c.dim):'');s.setProperty('--lyc-w',c.width?c.width+'px':'');
  if(c.color){s.setProperty('--text',c.color);s.setProperty('--accent-2',c.color)}else{s.removeProperty('--text');s.removeProperty('--accent-2')}
  for(const k of ['size','weight','font','dim','width'])stage.toggleAttribute('data-lyc-'+k,!!(c[k]&&c[k]!=='app'));
  stage.toggleAttribute('data-lyc-noglow',!c.glow);
  const olc={dark:'rgba(0,0,0,.75)',light:'rgba(255,255,255,.9)',accent:'var(--accent)',custom:c.olc}[c.outline];
  stage.toggleAttribute('data-lyc-outline',!!olc);s.setProperty('--lyc-olw',(c.olw||1.5)+'px');s.setProperty('--lyc-olc',olc||'transparent');
  stage.toggleAttribute('data-lyc-contrast',!!c.contrast);
}
function setLyc(k,v){const c=lyc();c[k]=v;store.set('lyCustom',c);applyLyCustom();if(Ly.open)sync(true)}

/* ---------- fonts: presets, the online catalog (Google Fonts) and your own file ---------- */
const GF=[ /* name, tags: s sans, r serif, h hand, d display, m mono, c = has Cyrillic */
['Inter','sc'],['Roboto','sc'],['Montserrat','sc'],['Open Sans','sc'],['Rubik','sc'],['Manrope','sc'],['Nunito','sc'],['Golos Text','sc'],['Onest','sc'],['Unbounded','dc'],
['Geologica','sc'],['Jost','sc'],['Raleway','sc'],['Oswald','dc'],['PT Sans','sc'],['Ubuntu','sc'],['Fira Sans','sc'],['Exo 2','dc'],['Comfortaa','dc'],['Play','sc'],
['IBM Plex Sans','sc'],['Source Sans 3','sc'],['Sofia Sans','sc'],['Commissioner','sc'],['Wix Madefor Display','sc'],['Montserrat Alternates','dc'],['Didact Gothic','sc'],['Ysabeau','sc'],['Tenor Sans','sc'],['Jura','dc'],
['Poiret One','dc'],['Philosopher','dc'],['Russo One','dc'],['Dela Gothic One','dc'],['Rubik Mono One','dc'],['Seymour One','dc'],['Stalinist One','dc'],['Press Start 2P','dc'],['Tektur','dc'],['Yanone Kaffeesatz','dc'],
['Rubik Glitch','dc'],['Rubik Wet Paint','dc'],['Rubik Puddles','dc'],['Rubik Moonrocks','dc'],['Rubik Microbe','dc'],['Rubik Beastly','dc'],['Train One','dc'],['Rampart One','dc'],['Reggae One','dc'],['Oi','dc'],
['Lobster','hc'],['Pacifico','hc'],['Caveat','hc'],['Marck Script','hc'],['Neucha','hc'],['Bad Script','hc'],['Amatic SC','hc'],['Pangolin','hc'],['Shantell Sans','hc'],['Kurale','rc'],
['Underdog','dc'],['Pattaya','dc'],['Gabriela','rc'],['Ledger','rc'],['Podkova','rc'],['Kelly Slab','dc'],['Ruslan Display','dc'],['Yeseva One','dc'],['Prata','rc'],['Forum','rc'],
['Playfair Display','rc'],['Lora','rc'],['Literata','rc'],['PT Serif','rc'],['Merriweather','rc'],['Noto Serif','rc'],['Roboto Slab','rc'],['Cormorant Garamond','rc'],['Cormorant','rc'],['EB Garamond','rc'],
['Old Standard TT','rc'],['Spectral','rc'],['Alegreya','rc'],['Vollkorn','rc'],['Roboto Mono','mc'],['JetBrains Mono','mc'],['IBM Plex Mono','mc'],['Fira Code','mc'],['Ubuntu Mono','mc'],['PT Mono','mc'],
['Bebas Neue','d'],['Anton','d'],['Orbitron','d'],['Space Grotesk','s'],['Poppins','s'],['Syne','d'],['Righteous','d'],['Bungee','d'],['Monoton','d'],['Audiowide','d'],
['Permanent Marker','h'],['Dancing Script','h'],['Satisfy','h'],['Great Vibes','h'],['Shadows Into Light','h'],['Indie Flower','h'],['Space Mono','m'],['DM Serif Display','r'],['Abril Fatface','d'],['Archivo Black','d']];
const GF_CATS={all:'Все',c:'Кириллица',s:'Без засечек',r:'С засечками',h:'Рукописные',d:'Декоративные',m:'Моно'};
const gfLoaded=new Set();
function gfLoad(name,text){const key=name+(text?'|t':'');if(gfLoaded.has(key)||!/^[A-Za-z0-9 ]{2,40}$/.test(name))return;gfLoaded.add(key);
  const l=document.createElement('link');l.rel='stylesheet';l.href='https://fonts.googleapis.com/css2?family='+encodeURIComponent(name).replace(/%20/g,'+')+(text?'&text='+encodeURIComponent(text):'')+'&display=swap';document.head.appendChild(l)}
let fileFontReady=false;
async function loadFileFont(){if(fileFontReady)return;try{const f=await BgDB.getKey('font');if(!f)return;const ff=new FontFace('LazzyLyricsFont',await f.arrayBuffer());await ff.load();document.fonts.add(ff);fileFontReady=true;applyLyCustom()}catch{}}
function fontCss(v){
  if(!v||v==='app')return '';if(LYC_FONT_CSS[v])return LYC_FONT_CSS[v];
  if(v==='file'){loadFileFont();return '"LazzyLyricsFont",sans-serif'}
  if(v.startsWith('gf:')){const n=v.slice(3);gfLoad(n);return `"${n}",sans-serif`}return '';
}
const fontLabel=v=>v==='file'?'Свой файл':v?.startsWith('gf:')?v.slice(3):LYC_FONTS[v]||LYC_FONTS.app;
function openFontCatalog(){
  const PREV='Под луной горят';let cat='c',q='';
  const ov=document.createElement('div');ov.className='gf-ov';ov.innerHTML=`<div class="gf-box glass" role="dialog" aria-label="Каталог шрифтов">
    <div class="gf-top"><b>Шрифты для текста песен</b><button class="ibtn" id="gfX" aria-label="Закрыть"><svg><use href="#i-down"/></svg></button></div>
    <input class="settings-input" id="gfQ" placeholder="Поиск или любое название из Google Fonts">
    <div class="choice-row gf-cats" id="gfCats">${Object.entries(GF_CATS).map(([k,v])=>`<button data-c="${k}" class="${k===cat?'on':''}">${v}</button>`).join('')}</div>
    <div class="gf-list" id="gfList"></div>
    <div class="api-actions"><label class="chip">Загрузить свой шрифт (.ttf .otf .woff)<input type="file" id="gfFile" accept=".ttf,.otf,.woff,.woff2,font/*" hidden></label></div></div>`;
  document.body.appendChild(ov);const close=()=>{ov.remove();document.removeEventListener('keydown',esc2)};const esc2=e=>{if(e.key==='Escape')close()};document.addEventListener('keydown',esc2);
  ov.onclick=e=>{if(e.target===ov)close()};ov.querySelector('#gfX').onclick=close;
  const io=new IntersectionObserver(es=>es.forEach(en=>{if(en.isIntersecting){gfLoad(en.target.dataset.f,PREV+en.target.dataset.f);io.unobserve(en.target)}}),{root:ov.querySelector('#gfList')});
  const cur0=lyc().font;
  const draw=()=>{const qq=q.trim().toLowerCase();let list=GF.filter(([n,t])=>(cat==='all'||t.includes(cat))&&(!qq||n.toLowerCase().includes(qq)));
    let extra='';if(qq&&!GF.some(([n])=>n.toLowerCase()===qq)&&/^[a-z0-9 ]{2,40}$/i.test(q.trim()))extra=`<button class="gf-item" data-f="${esc(q.trim().replace(/\b\w/g,m=>m.toUpperCase()))}"><span class="gf-name">Попробовать «${esc(q.trim())}» из Google Fonts</span></button>`;
    ov.querySelector('#gfList').innerHTML=extra+list.map(([n,t])=>`<button class="gf-item${cur0==='gf:'+n?' on':''}" data-f="${esc(n)}"><span class="gf-prev" style="font-family:'${esc(n)}',sans-serif">${t.includes('c')?PREV:'Under the moon'}</span><span class="gf-name">${esc(n)}${t.includes('c')?'':' · только латиница'}</span></button>`).join('')||'<p class="settings-help">Ничего не нашли</p>';
    ov.querySelectorAll('.gf-item[data-f]').forEach(el=>io.observe(el))};
  ov.querySelector('#gfQ').oninput=e=>{q=e.target.value;draw()};
  ov.querySelector('#gfCats').onclick=e=>{const b=e.target.closest('[data-c]');if(!b)return;cat=b.dataset.c;ov.querySelectorAll('#gfCats button').forEach(x=>x.classList.toggle('on',x===b));draw()};
  ov.querySelector('#gfList').onclick=e=>{const b=e.target.closest('.gf-item');if(!b)return;setLyc('font','gf:'+b.dataset.f);toast('Шрифт текста: '+b.dataset.f);close();renderLyricsSettings()};
  ov.querySelector('#gfFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>15e6){toast('Файл шрифта больше 15 МБ');return}
    try{const ff=new FontFace('LazzyLyricsFont',await f.arrayBuffer());await ff.load();document.fonts.add(ff);await BgDB.putKey('font',f);fileFontReady=true;setLyc('font','file');toast('Свой шрифт установлен');close();renderLyricsSettings()}catch{toast('Это не похоже на файл шрифта')}};
  draw();setTimeout(()=>ov.querySelector('#gfQ').focus(),50);
}

/* ---------- «Чистый»: only the current line, exactly in the middle ---------- */
LY_STYLES.clean={label:'Чистый',hint:'Только текущая строка точно по центру, слова загораются по очереди'};
LY_STYLES.cleanl={label:'Чистый по буквам',hint:'Одна строка по центру, буквы заливаются по звуку, протяжки тянутся'};
/* «Чистый» is a layout over the word / letter engines: the stage keeps words|letters as its style and gets data-ly-clean */
const baseApplyLyStyle=applyLyStyle;
applyLyStyle=function(){baseApplyLyStyle();const st=store.get('lyStyle','letters'),clean=st==='clean'||st==='cleanl';
  stage.toggleAttribute('data-ly-clean',clean);if(clean){stage.dataset.lyStyle=st==='cleanl'?'letters':'words';Ly.wk=-2;Ly.gLine=-1;if(Ly.synced){Ly.plan=null;try{renderAligned()}catch{}}if(Ly.open)sync(true)}};
let uiTimer=0;
function revealUi(){if(!stage.hasAttribute('data-ly-clean'))return;stage.classList.add('ui-show');clearTimeout(uiTimer);uiTimer=setTimeout(()=>stage.classList.remove('ui-show'),2500)}
for(const ev of ['pointermove','pointerdown','keydown'])stage.addEventListener(ev,revealUi,{passive:true});

/* ---------- custom backgrounds ---------- */
const BG_MODES={off:'Обложка трека',lines:'Линии',stars:'Звёздный полёт',waves:'Волны',grid:'Ретро-сетка',aurora:'Сияние',bars:'Эквалайзер',rings:'Круги',gradient:'Градиент',black:'Чёрный',custom:'Свой файл'};
const bgc=()=>({mode:'off',scope:'player',dim:.35,blur:0,...(store.get('customBg',{})||{})});
const BgDB={db:null,open(){return this.db||(this.db=new Promise((res,rej)=>{const r=indexedDB.open('lazzy-bg',1);r.onupgradeneeded=()=>r.result.createObjectStore('f');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}))},
  async put(v){const d=await this.open();return new Promise((res,rej)=>{const t=d.transaction('f','readwrite');t.objectStore('f').put(v,'bg');t.oncomplete=res;t.onerror=()=>rej(t.error)})},
  async get(){return this.getKey('bg')},
  async putKey(k,v){const d=await this.open();return new Promise((res,rej)=>{const t=d.transaction('f','readwrite');t.objectStore('f').put(v,k);t.oncomplete=res;t.onerror=()=>rej(t.error)})},
  async getKey(k){const d=await this.open();return new Promise(res=>{const r=d.transaction('f').objectStore('f').get(k);r.onsuccess=()=>res(r.result||null);r.onerror=()=>res(null)})}};
let bgUrl='',linesAnim=null;
function bgLayer(host){let el=host.querySelector(':scope>.cbg');if(!el){el=document.createElement('div');el.className='cbg';host.appendChild(el)}return el}
function linesCanvas(el){
  const c=document.createElement('canvas');c.className='cbg-lines';el.appendChild(c);const x=c.getContext('2d');
  const P=Array.from({length:16},()=>({x:Math.random(),y:Math.random(),vx:(Math.random()-.5)*.012,vy:(Math.random()-.5)*.012}));
  let last=0;const draw=t=>{if(!c.isConnected)return;requestAnimationFrame(draw);if(document.hidden||!c.offsetWidth||t-last<33)return;const dt=Math.min(.1,(t-last)/1000)||.03;last=t;
    const w=c.width=c.clientWidth*(devicePixelRatio>1?1.5:1),h=c.height=c.clientHeight*(devicePixelRatio>1?1.5:1);if(!w||!h)return;
    const lvl=typeof FxEngine!=='undefined'?Math.min(1,+FxEngine.pulse||0):0;
    for(const p of P){p.x+=p.vx*dt*(1+lvl*2);p.y+=p.vy*dt*(1+lvl*2);if(p.x<-.15||p.x>1.15)p.vx*=-1;if(p.y<-.15||p.y>1.15)p.vy*=-1}
    x.clearRect(0,0,w,h);x.lineWidth=Math.max(1,w/900);x.strokeStyle=`rgba(255,255,255,${.3+lvl*.25})`;x.beginPath();
    P.forEach((p,i)=>{const near=P.map((q,j)=>[j,(q.x-p.x)**2+(q.y-p.y)**2]).filter(([j])=>j!==i).sort((a,b)=>a[1]-b[1]).slice(0,3);
      for(const [j] of near){if(j<i)continue;x.moveTo(p.x*w,p.y*h);x.lineTo(P[j].x*w,P[j].y*h)}});
    x.stroke()};
  requestAnimationFrame(draw);
}
/* animated presets: one tiny canvas loop, ~30 fps, reacts to the track's loudness (FxEngine.pulse) */
function presetCanvas(el,mode){
  const c=document.createElement('canvas');c.className='cbg-lines';el.appendChild(c);const x=c.getContext('2d');let last=0,T=0;
  const acc=()=>{const cs=getComputedStyle(document.documentElement);return [cs.getPropertyValue('--accent').trim()||'#46b7ff',cs.getPropertyValue('--accent-2').trim()||'#8bf3e6']};
  const S=Array.from({length:180},()=>({x:Math.random()*2-1,y:Math.random()*2-1,z:Math.random()}));
  const draw=t=>{if(!c.isConnected)return;requestAnimationFrame(draw);if(document.hidden||!c.offsetWidth||t-last<33)return;const dt=Math.min(.1,(t-last)/1000)||.03;last=t;
    const k=devicePixelRatio>1?1.5:1,w=c.width=c.clientWidth*k,h=c.height=c.clientHeight*k;if(!w||!h)return;
    const lvl=typeof FxEngine!=='undefined'?Math.min(1,+FxEngine.pulse||0):0;T+=dt*(1+lvl*1.5);const [a1,a2]=acc();x.clearRect(0,0,w,h);
    if(mode==='stars'){x.fillStyle='#fff';for(const p of S){p.z-=dt*(.18+lvl*.6);if(p.z<=.02){p.x=Math.random()*2-1;p.y=Math.random()*2-1;p.z=1}
        const sx=w/2+p.x/p.z*w*.35,sy=h/2+p.y/p.z*h*.35,r=Math.max(.4,(1-p.z)*2.4*k);x.globalAlpha=Math.min(1,(1-p.z)*1.4);x.beginPath();x.arc(sx,sy,r,0,7);x.fill()}x.globalAlpha=1}
    else if(mode==='waves'){for(let i=0;i<7;i++){x.beginPath();x.strokeStyle=i%2?a1:a2;x.globalAlpha=.38+.12*i/7+lvl*.25;x.lineWidth=k*(1+i*.3);
        for(let X=0;X<=w;X+=8*k){const Y=h*(.3+i*.07)+Math.sin(X/w*6.3+T*(.6+i*.13)+i)*h*(.05+lvl*.06)+Math.sin(X/w*13+T*1.7)*h*.01;X?x.lineTo(X,Y):x.moveTo(X,Y)}x.stroke()}x.globalAlpha=1}
    else if(mode==='grid'){const hz=h*.55,g=x.createLinearGradient(0,0,0,hz);g.addColorStop(0,'#0a0420');g.addColorStop(1,'#3a0d4a');x.fillStyle=g;x.fillRect(0,0,w,hz);
        const sun=x.createLinearGradient(0,hz-h*.32,0,hz);sun.addColorStop(0,'#ffd27a');sun.addColorStop(1,'#ff4f9a');x.fillStyle=sun;x.beginPath();x.arc(w/2,hz,h*.22*(1+lvl*.08),Math.PI,0);x.fill();
        x.fillStyle='#0a0420';for(let i=0;i<6;i++)x.fillRect(0,hz-h*.03*(i+1)-i*3*k,w,(1.5+i)*k);
        x.fillStyle='#07020f';x.fillRect(0,hz,w,h-hz);x.strokeStyle='#ff4fd8';x.globalAlpha=.7;x.lineWidth=k;
        for(let i=-14;i<=14;i++){x.beginPath();x.moveTo(w/2+i*w*.02,hz);x.lineTo(w/2+i*w*.22,h);x.stroke()}
        for(let i=0;i<14;i++){const f=((i+T*.6)%14)/14,Y=hz+(h-hz)*f*f;x.globalAlpha=.25+.6*f;x.beginPath();x.moveTo(0,Y);x.lineTo(w,Y);x.stroke()}x.globalAlpha=1}
    else if(mode==='aurora'){for(let i=0;i<4;i++){const cx=w*(.5+.38*Math.sin(T*.13+i*1.7)),cy=h*(.45+.3*Math.cos(T*.11+i*2.3)),r=Math.max(w,h)*(.45+.1*i+lvl*.1);
        const g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,[a1,a2,'#7a4dff','#ff5a9a'][i]);g.addColorStop(1,'transparent');x.globalAlpha=.55;x.fillStyle=g;x.fillRect(0,0,w,h)}x.globalAlpha=1}
    else if(mode==='bars'){const n=48,bw=w/n;for(let i=0;i<n;i++){const v=.12+.5*Math.abs(Math.sin(i*.45+T*2.2)*Math.sin(i*.13-T*1.3))*(.6+lvl)+lvl*.15,bh=h*.45*Math.min(1,v);
        const g=x.createLinearGradient(0,h,0,h-bh);g.addColorStop(0,a1);g.addColorStop(1,a2);x.fillStyle=g;x.globalAlpha=.6;x.fillRect(i*bw+bw*.15,h-bh,bw*.7,bh)}x.globalAlpha=1}
    else if(mode==='rings'){x.lineWidth=1.2*k;for(let i=0;i<10;i++){const f=((T*.12+i/10)%1),r=f*Math.hypot(w,h)*.6;x.strokeStyle=i%2?a1:a2;x.globalAlpha=(1-f)*(.6+lvl*.4);x.beginPath();x.arc(w/2,h/2,r,0,7);x.stroke()}x.globalAlpha=1}
  };requestAnimationFrame(draw);
}
async function applyBg(){
  const c=bgc(),hosts=[$('#fullBg'),$('#ambient')].filter(Boolean);
  document.documentElement.dataset.cbg=c.mode==='off'?'':c.mode;document.documentElement.dataset.cbgScope=c.scope;
  for(const h of hosts){const old=h.querySelector(':scope>.cbg');if(old)old.remove()}
  if(bgUrl){URL.revokeObjectURL(bgUrl);bgUrl=''}
  if(c.mode==='off')return;
  const targets=c.scope==='all'?hosts:hosts.slice(0,1);
  let file=null;if(c.mode==='custom'){file=await BgDB.get().catch(()=>null);if(!file)return;bgUrl=URL.createObjectURL(file)}
  for(const h of targets){const el=bgLayer(h);el.style.setProperty('--cbg-dim',c.mode==='custom'?c.dim:c.dim*.4);el.style.setProperty('--cbg-blur',(c.blur||0)+'px');
    if(c.mode==='lines')linesCanvas(el);
    else if(['stars','waves','grid','aurora','bars','rings'].includes(c.mode))presetCanvas(el,c.mode);
    else if(c.mode==='gradient')el.classList.add('cbg-grad');
    else if(c.mode==='custom')el.insertAdjacentHTML('afterbegin',/^video\//.test(file.type)?`<video src="${bgUrl}" autoplay muted loop playsinline disablepictureinpicture></video>`:`<img src="${bgUrl}" alt="">`)}
}

/* ---------- settings ---------- */
const baseLyrSettings=renderLyricsSettings;
renderLyricsSettings=function(){
  baseLyrSettings();const host=$('#lyricsSettings');if(!host)return;const c=lyc();
  {const st=store.get('lyStyle','letters');host.querySelectorAll('#lyStyles [data-ly]').forEach(x=>x.classList.toggle('on',x.dataset.ly===st))}
  const row=(id,opts,cur,attr)=>`<div class="choice-row" id="${id}">${opts.map(([v,l])=>`<button data-${attr}="${v}" class="${String(v)===String(cur)?'on':''}">${l}</button>`).join('')}</div>`;
  host.insertAdjacentHTML('beforeend',`<div class="lyc">
    <p class="field-label">Выравнивание</p>${row('lycAlign',[['auto','Как в стиле'],['left','Слева'],['center','По центру'],['right','Справа']],c.align,'v')}
    <p class="field-label">Свой размер <b id="lycSizeV">${c.size?c.size+' px':'нет'}</b></p><input type="range" id="lycSize" min="0" max="96" step="2" value="${c.size}">
    <p class="field-label">Толщина</p>${row('lycWeight',[[0,'Как в стиле'],[300,'Тонкий'],[500,'Обычный'],[700,'Жирный'],[900,'Очень жирный']],c.weight,'v')}
    <p class="field-label">Шрифт <b>${esc(fontLabel(c.font))}</b></p>${row('lycFont',Object.entries(LYC_FONTS),c.font,'v')}<div class="api-actions"><button class="btn-accent" id="lycCatalog">Каталог шрифтов онлайн</button></div>
    <p class="field-label">Цвет текста</p><div class="choice-row" id="lycColor">${[['','Тема'],['#ffffff','Белый'],['#9fe8ff','Голубой'],['#ffd27a','Золото'],['#ff9ad5','Розовый'],['#b7ff9a','Мята']].map(([v,l])=>`<button data-v="${v}" class="${v===c.color?'on':''}">${v?`<i class="lyc-dot" style="background:${v}"></i>`:''}${l}</button>`).join('')}<label class="chip lyc-pick">Свой<input type="color" id="lycCustomColor" value="${c.color||'#ffffff'}"></label></div>
    <p class="field-label">Яркость неактивных строк <b id="lycDimV">${c.dim?Math.round(c.dim*100)+'%':'как в стиле'}</b></p><input type="range" id="lycDim" min="0" max="0.8" step="0.05" value="${c.dim}">
    <p class="field-label">Ширина колонки <b id="lycWV">${c.width?c.width+' px':'авто'}</b></p><input type="range" id="lycW" min="0" max="1600" step="50" value="${c.width}">
    <p class="field-label">Обводка зажжённого текста</p><div class="choice-row" id="lycOl">${Object.entries(LYC_OL).map(([k,v])=>`<button data-v="${k}" class="${k===c.outline?'on':''}">${v}</button>`).join('')}<label class="chip lyc-pick">Цвет<input type="color" id="lycOlColor" value="${c.olc||'#000000'}"></label></div>
    <p class="field-label">Толщина обводки <b id="lycOlwV">${c.olw} px</b></p><input type="range" id="lycOlw" min="0.5" max="5" step="0.25" value="${c.olw}">
    <label class="toggle-row"><span><b>Высокий контраст</b><small>Зажжённые слова ярче, остальные тише, лёгкая тень под буквами</small></span><input type="checkbox" id="lycContrast" ${c.contrast?'checked':''}></label>
    <label class="toggle-row"><span><b>Свечение</b><small>Мягкий ореол вокруг текущей строки</small></span><input type="checkbox" id="lycGlow" ${c.glow?'checked':''}></label>
    <button class="chip" id="lycReset">Сбросить вид текста</button></div>`);
  const pick=(id,k,num)=>{$('#'+id).onclick=e=>{const b=e.target.closest('[data-v]');if(!b)return;setLyc(k,num?+b.dataset.v:b.dataset.v);renderLyricsSettings()}};
  $('#lycCatalog').onclick=openFontCatalog;
  pick('lycAlign','align');pick('lycWeight','weight',1);pick('lycFont','font');pick('lycColor','color');
  $('#lycCustomColor').oninput=e=>setLyc('color',e.target.value);$('#lycCustomColor').onchange=()=>renderLyricsSettings();
  $('#lycSize').oninput=e=>{setLyc('size',+e.target.value);$('#lycSizeV').textContent=+e.target.value?e.target.value+' px':'нет'};
  $('#lycDim').oninput=e=>{setLyc('dim',+e.target.value);$('#lycDimV').textContent=+e.target.value?Math.round(e.target.value*100)+'%':'как в стиле'};
  $('#lycW').oninput=e=>{setLyc('width',+e.target.value);$('#lycWV').textContent=+e.target.value?e.target.value+' px':'авто'};
  $('#lycGlow').onchange=e=>setLyc('glow',e.target.checked);
  pick('lycOl','outline');$('#lycOlColor').oninput=e=>{const c2=lyc();c2.olc=e.target.value;c2.outline='custom';store.set('lyCustom',c2);applyLyCustom()};$('#lycOlColor').onchange=()=>renderLyricsSettings();
  $('#lycOlw').oninput=e=>{setLyc('olw',+e.target.value);$('#lycOlwV').textContent=e.target.value+' px'};
  $('#lycContrast').onchange=e=>setLyc('contrast',e.target.checked);
  $('#lycReset').onclick=()=>{store.set('lyCustom',{});applyLyCustom();renderLyricsSettings();if(Ly.open)sync(true)};
  renderBgSettings();
};
function renderBgSettings(){
  let host=$('#bgSettings');const anchor=$('#fxSettings')||$('#lyricsSettings');if(!anchor)return;
  if(!host){host=document.createElement('div');host.className='settings-group';host.id='bgSettings'}
  if(host.previousElementSibling!==anchor)anchor.parentNode.insertBefore(host,anchor.nextSibling);
  const c=bgc(),art=cur()?.art||'';
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-palette"/></svg><h2>Фон плеера и текста</h2></div>
    <div class="bg-tiles" id="bgMode">${Object.entries(BG_MODES).map(([k,v])=>`<button data-v="${k}" class="bg-tile${k===c.mode?' on':''}"><span class="bg-prev bg-prev-${k}">${k==='off'&&art?`<img src="${esc(art)}" alt="" referrerpolicy="no-referrer">`:k==='custom'?'<svg><use href="#i-upload"/></svg>':''}</span><b>${v}</b></button>`).join('')}</div>
    <input type="file" id="bgFile" accept="image/*,video/mp4,video/webm" hidden>
    <p class="field-label">Где</p><div class="choice-row" id="bgScope"><button data-v="player" class="${c.scope==='player'?'on':''}">Плеер и текст</button><button data-v="all" class="${c.scope==='all'?'on':''}">Везде</button></div>
    <p class="field-label">Затемнение <b>${Math.round(c.dim*100)}%</b></p><input type="range" id="bgDim" min="0" max="0.9" step="0.05" value="${c.dim}">
    <p class="field-label">Размытие (для своего файла) <b>${c.blur} px</b></p><input type="range" id="bgBlur" min="0" max="30" step="1" value="${c.blur}">
    <p class="settings-help">Анимированные фоны ускоряются под громкость трека. Свой файл — картинка, GIF или видео до 60 МБ, хранится только на этом устройстве.</p>`;
  for(const el of host.querySelectorAll('.bg-prev')){const m=[...el.classList].find(x=>x.startsWith('bg-prev-')).slice(8);
    if(m==='lines')linesCanvas(el);else if(['stars','waves','grid','aurora','bars','rings'].includes(m))presetCanvas(el,m)}
  const save=(k,v)=>{const s2=bgc();s2[k]=v;store.set('customBg',s2);applyBg()};
  $('#bgMode').onclick=e=>{const b=e.target.closest('[data-v]');if(!b)return;if(b.dataset.v==='custom'){$('#bgFile').click();return}save('mode',b.dataset.v);host.querySelectorAll('.bg-tile').forEach(x=>x.classList.toggle('on',x===b))};
  $('#bgScope').onclick=e=>{const b=e.target.closest('[data-v]');if(b){save('scope',b.dataset.v);renderBgSettings()}};
  $('#bgDim').onchange=e=>{save('dim',+e.target.value);renderBgSettings()};$('#bgBlur').onchange=e=>{save('blur',+e.target.value);renderBgSettings()};
  $('#bgFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;if(f.size>60e6){toast('Файл больше 60 МБ');return}
    try{await BgDB.put(f);save('mode','custom');renderBgSettings();toast('Фон установлен')}catch{toast('Не удалось сохранить файл')}};
}
applyLyCustom();applyBg();renderLyricsSettings();
applyLyStyle();

/* ---------- 5.8.0: seekable progress in the lyrics screen + volume (PC) ---------- */
(function(){
  const bar=$('#lyProg')?.parentElement;if(!bar)return;bar.classList.add('ly-seek');bar.setAttribute('role','slider');bar.setAttribute('aria-label','Позиция');
  bar.insertAdjacentHTML('afterend','<div class="ly-times"><span id="lyCur">0:00</span><span id="lyDur">0:00</span></div>');
  const fmtT=s=>isFinite(s)&&s>=0?Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0'):'0:00';
  const frac=e=>{const r=bar.getBoundingClientRect(),pad=8;return Math.max(0,Math.min(1,(e.clientX-r.left-pad)/Math.max(1,r.width-pad*2)))};
  let drag=false;
  const show=f=>{$('#lyProg').style.transform=`scaleX(${f})`;$('#lyCur').textContent=fmtT(f*mDur())};
  const seek=f=>{const d=mDur();if(!d)return;mSeek(f*d);Ly.userUntil=0;Ly.gLine=-1;Ly.wk=-2;if(Ly.open)sync(true)};
  bar.addEventListener('pointerdown',e=>{if(!mDur())return;drag=true;bar.setPointerCapture(e.pointerId);bar.classList.add('drag');show(frac(e));e.preventDefault()});
  bar.addEventListener('pointermove',e=>{if(drag)show(frac(e))});
  const end=e=>{if(!drag)return;drag=false;bar.classList.remove('drag');seek(frac(e))};
  bar.addEventListener('pointerup',end);bar.addEventListener('pointercancel',()=>{drag=false;bar.classList.remove('drag')});
  bar.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();e.stopPropagation();mSeek(mPos()+(e.key==='ArrowRight'?5:-5));sync(true)}});bar.tabIndex=0;
  audio.addEventListener('timeupdate',()=>{if(drag||!Ly.open)return;$('#lyCur').textContent=fmtT(audio.currentTime);$('#lyDur').textContent=fmtT(audio.duration)});
  audio.addEventListener('loadedmetadata',()=>{$('#lyDur').textContent=fmtT(audio.duration)});
  /* volume (shown on devices with a mouse) */
  $('.ly-foot .ly-ctrl')?.insertAdjacentHTML('afterend','<div class="ly-vol"><svg><use href="#i-vol"/></svg><input type="range" id="lyVol" min="0" max="100" aria-label="Громкость"></div>');
  const lv=$('#lyVol'),mv=$('#vol');
  const paint=()=>{const v=Math.round(audio.volume*100);if(lv){lv.value=v;lv.style.setProperty('--p',v+'%')}if(mv){mv.value=v;mv.style.setProperty('--p',v+'%')}};
  lv?.addEventListener('input',e=>{audio.volume=e.target.value/100;store.set('vol',audio.volume);paint()});
  audio.addEventListener('volumechange',paint);paint();
  /* mouse wheel over the lyrics changes volume while «Чистый» hides the controls */
  stage.addEventListener('wheel',e=>{if(!stage.hasAttribute('data-ly-clean'))return;e.preventDefault();audio.volume=Math.max(0,Math.min(1,audio.volume-Math.sign(e.deltaY)*.05));store.set('vol',audio.volume);revealUi()},{passive:false});
})();



/* ---------- 5.8.4: tap-to-sync — tap the line the moment it is sung; the offset is saved for this track ---------- */
(function(){
  const off=$('#lyPlus');if(!off)return;
  off.insertAdjacentHTML('afterend','<button class="chip ly-tapsync" id="lyTap" aria-pressed="false">Синхр.</button>');
  const btn=$('#lyTap');let armed=false;
  const arm=v=>{armed=v;btn.classList.toggle('on',v);btn.setAttribute('aria-pressed',v);stage.classList.toggle('tap-armed',v);if(v)toast('Тапни строку в момент, когда её начинают петь — работает и в наушниках')};
  btn.onclick=e=>{e.stopPropagation();arm(!armed)};
  /* precise mode for headphones: after the first line, tap the pad (or Space) at the start of every next line — the median of 5 taps is used */
  stage.insertAdjacentHTML('beforeend','<button class="ly-tappad" id="lyTapPad" hidden><b>ТАП</b><span id="lyTapN">в начале каждой строки · 1/5</span></button>');
  const pad=$('#lyTapPad');let samples=[];
  const median=a=>{const b=[...a].sort((x,y)=>x-y);return b[b.length>>1]};
  const apply=()=>{const m=+median(samples).toFixed(2);nudge(+(m-Sync.manual).toFixed(2))};
  const finish=()=>{pad.hidden=true;arm(false);if(samples.length){const b=[...samples].sort((x,y)=>x-y),q=b.length>2?(b[Math.floor(b.length*.75)]-b[Math.floor(b.length*.25)])/2:.2;
    toast('Готово: '+(Sync.manual>=0?'+':'')+Sync.manual.toFixed(2)+' с, точность ≈ ±'+Math.max(.05,q).toFixed(2)+' с · сохранено для всех')}samples=[]};
  const tapNow=()=>{const now=playTime();let best=null,bd=1.6;
    for(const L of Ly.lines){if(!L.text)continue;const at=L.t*Sync.scale+Sync.auto+Sync.manual+latency(),d=Math.abs(at-now);if(d<bd){bd=d;best=L}}
    if(!best){toast('Не попал в начало строки — тапни, когда строка начинается');return}
    samples.push(now-.1-latency()-Sync.auto-best.t*Sync.scale);apply();$('#lyTapN').textContent='в начале каждой строки · '+Math.min(5,samples.length+1)+'/5';if(samples.length>=5)finish()};
  pad.addEventListener('click',e=>{e.stopPropagation();tapNow()});
  document.addEventListener('keydown',e=>{if(!pad.hidden&&e.code==='Space'){e.preventDefault();e.stopImmediatePropagation();tapNow()}},true);
  linesEl.addEventListener('click',e=>{
    if(!armed)return;const p=e.target.closest('.ly-line[data-i]');if(!p||!Ly.synced)return;e.stopImmediatePropagation();e.preventDefault();
    const L=Ly.lines[+p.dataset.i];if(!L)return;
    samples=[playTime()-.18-latency()-Sync.auto-L.t*Sync.scale]; /* .18 s ≈ reaction time */
    apply();pad.hidden=false;$('#lyTapN').textContent='в начале каждой строки · 2/5';toast('Теперь жми «ТАП» (или пробел) в начале следующих строк — для точности');
  },true);
  btn.addEventListener('click',()=>{if(!armed&&!pad.hidden)finish()});
  /* keyboard on PC: [ and ] shift by 0.1 s, T arms tap-sync */
  document.addEventListener('keydown',e=>{if(!Ly.open||/INPUT|TEXTAREA/.test(e.target.tagName))return;
    if(e.key==='['){nudge(-.1)}else if(e.key===']'){nudge(.1)}else if(e.key==='t'||e.key==='е'){arm(!armed)}});
  /* no audio to check against (Hitmoz): say how to fix a constant lag */
  let hinted=false;audio.addEventListener('playing',()=>{const t=cur();if(hinted||!t||!Ly.open||!Ly.synced||!(window.isHitmoz&&isHitmoz(t)))return;hinted=true;
    setTimeout(()=>{if(Ly.open)toast('источник не дал звук для автоподстройки. Если текст отстаёт — «Синхр.» и тапни строку')},4000)});
})();

/* ---------- 5.8.5: AI auto-sync by microphone + shared timings for everyone (also headphone users) ---------- */
const syncKey=t=>{const s=(normalize(cleanArtist(t.artist||''))+'|'+normalize(cleanTitle(t.title||''))+'|'+Math.round(liveDur(t)||0)).toLowerCase();let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)+s.length.toString(16)};
async function shareSync(t,offset,how){try{if(typeof signedIn!=='function'||!signedIn())return;await setDoc('/syncs/'+syncKey(t),{offset:+offset.toFixed(2),how,at:Date.now()})}catch{}}
const baseInitSync=initSync;
initSync=function(t,res){baseInitSync(t,res);
  if(Sync.manual||typeof signedIn!=='function'||!signedIn()||!res?.synced?.length)return;const id=t.id;
  getDoc('/syncs/'+syncKey(t)).then(d=>{if(!d||typeof d.offset!=='number'||Sync.id!==id||Sync.manual)return;Sync.manual=d.offset;paintOffset();Ly.gLine=-1;Ly.wk=-2;if(Ly.open)sync(true);
    toast('Тайминг подстроен по синхронизации сообщества ('+(d.offset>=0?'+':'')+d.offset.toFixed(2)+' с)')}).catch(()=>{})};
/* tap-sync results are shared too */
const baseNudge=nudge;nudge=function(dv){baseNudge(dv);clearTimeout(nudge.t);const t=cur();if(t&&Ly.synced)nudge.t=setTimeout(()=>shareSync(t,Sync.manual,'tap'),4000)};
(function(){
  const tap=$('#lyTap');if(!tap)return;
  tap.insertAdjacentHTML('afterend','<button class="chip ly-tapsync" id="lyMic">🎤 Авто</button>');
  const btn=$('#lyMic');let busy=false;
  btn.onclick=async e=>{e.stopPropagation();if(busy)return;const t=cur();
    if(!t||!Ly.synced){toast('Нужен текст с таймингами строк');return}
    if(audio.paused){toast('Включи трек вслух (через динамик) и нажми ещё раз');return}
    const key=(window.LAZZY_CONFIG||{}).groqKey;if(!key){toast('ИИ недоступен');return}
    let stream;try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:true}})}catch{toast('Нет доступа к микрофону');return}
    busy=true;btn.classList.add('on');const mime=['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg'].find(m=>{try{return MediaRecorder.isTypeSupported(m)}catch{return false}})||'';
    const rec=new MediaRecorder(stream,mime?{mimeType:mime}:{}),chunks=[];rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);
    let t0=0;rec.onstart=()=>{t0=audio.currentTime};
    const done=new Promise(r=>rec.onstop=r);rec.start(250);
    for(let s=22;s>0;s--){btn.textContent='🎤 '+s+' с';await new Promise(z=>setTimeout(z,1000));if(cur()?.id!==t.id||audio.paused)break}
    rec.stop();await done;stream.getTracks().forEach(x=>x.stop());btn.textContent='🎤 ИИ…';
    try{
      const blob=new Blob(chunks,{type:rec.mimeType||mime||'audio/webm'}),ext=/mp4/.test(blob.type)?'m4a':/ogg/.test(blob.type)?'ogg':'webm';
      const fd=new FormData();fd.append('model','whisper-large-v3-turbo');fd.append('response_format','verbose_json');fd.append('timestamp_granularities[]','word');fd.append('temperature','0');fd.append('file',blob,'mic.'+ext);
      const r=await fetch('https://api.groq.com/openai/v1/audio/transcriptions',{method:'POST',headers:{Authorization:'Bearer '+key},body:fd});if(!r.ok)throw new Error('Whisper HTTP '+r.status);
      const W=((await r.json()).words||[]).map(w=>({n:asrNorm(w.word),s:+w.start})).filter(w=>w.n&&isFinite(w.s));
      if(W.length<3)throw new Error('ИИ не расслышал слов — сделай громче');
      const toks=[];Ly.words.forEach((ws,i)=>ws&&ws.forEach((w,k)=>{const n=asrNorm(w.w);if(n)toks.push({n,s:k===0&&Ly.lines[i]?Ly.lines[i].t:w.s,first:k===0})}));
      const map=asrAlign(toks.map(x=>x.n),W.map(w=>w.n)),diffs=[];
      const firsts=[];map.forEach((j,k)=>{if(j>=0){const d=(t0+W[j].s)-toks[k].s*Sync.scale;diffs.push(d);if(toks[k].first)firsts.push(d)}});const nMatch=diffs.length;if(nMatch>=3&&firsts.length>=2){diffs.length=0;diffs.push(...firsts)}
      if(nMatch<3)throw new Error('Слова не совпали с текстом ('+nMatch+') — попробуй на куплете');
      diffs.sort((a,b)=>a-b);const med=diffs[diffs.length>>1],spread=diffs[Math.floor(diffs.length*.75)]-diffs[Math.floor(diffs.length*.25)];
      if(spread>3)throw new Error('Не уверен в результате — попробуй ещё раз на другом куплете');
      const manual=+(med-latency()-Sync.auto).toFixed(2);baseNudge(+(manual-Sync.manual).toFixed(2));shareSync(t,Sync.manual,'mic');
      toast('ИИ подстроил текст: '+(Sync.manual>=0?'+':'')+Sync.manual.toFixed(2)+' с ('+nMatch+' слов) — сохранено для всех');
    }catch(err){toast(err.message||'Не получилось')}
    busy=false;btn.classList.remove('on');btn.textContent='🎤 Авто';
  };
})();

/* ---------- 5.8.7: no fake timings. Plain lyrics stay plain (like Spotify) until real timings exist:
   Whisper (audio available), community timings, or «Записать тайминги» — tap along once, shared with everyone ---------- */
/* 6.3.3: estimates are back as a fallback (marked «≈»), Whisper replaces them with real timings when it gets the audio */
const plainLines=res=>String(res.plain||'').split('\n').map(x=>x.trim()).filter(Boolean);
const lrcRender=render;
render=function(res){
  Ly.noAuto=!(res.synced&&res.synced.length>2);stage.classList.toggle('ly-plain',Ly.noAuto);lrcRender(res);const t=cur();if(!t)return;
  $('#lyRec')&&($('#lyRec').hidden=!(Ly.noAuto||res.estimated)||!res.plain);
  if(Ly.noAuto&&res.plain){const src=$('#lySrc');if(src)src.textContent='Текст без таймингов · '+(res.src||'')+' — нажми «Записать тайминги», чтобы синхронизировать для всех';
    if(typeof signedIn==='function'&&signedIn()){const id=t.id,L=plainLines(res);
      getDoc('/lrc/'+syncKey(t)).then(d=>{if(!d||!Array.isArray(d.t)||d.t.length!==L.length||cur()?.id!==id||Ly.id!==id||!Ly.noAuto)return;
        render({...res,synced:L.map((x,i)=>({t:+d.t[i],text:x})),community:true});toast('Тайминги строк от сообщества')}).catch(()=>{})}}
  else if(res.community){const src=$('#lySrc');if(src)src.textContent='Тайминги строк от сообщества · '+(res.src||'')}
};
(function(){
  const anchor=$('#lyMic')||$('#lyTap');if(!anchor)return;
  anchor.insertAdjacentHTML('afterend','<button class="chip ly-tapsync" id="lyRec" hidden>✍ Тайминги</button>');
  stage.insertAdjacentHTML('beforeend','<div class="ly-recbar" id="lyRecBar" hidden><button class="chip" id="lyRecUndo">↶ Назад</button><button class="ly-tappad ly-recpad" id="lyRecPad"><b>ТАП</b><span id="lyRecN"></span></button><button class="chip" id="lyRecStop">Готово</button></div>');
  let rec=null;
  const els=()=>[...linesEl.querySelectorAll('.ly-line.plain')];
  const mark=()=>{const E=els();E.forEach((e,i)=>{e.classList.toggle('rec-done',i<rec.i);e.classList.toggle('rec-next',i===rec.i)});const n=E[rec.i];
    $('#lyRecN').textContent=rec.i<rec.L.length?`строка ${rec.i+1}/${rec.L.length}: «${rec.L[rec.i].slice(0,40)}»`:'все строки отмечены';
    if(n){Ly.userUntil=Date.now()+1e4;n.scrollIntoView({block:'center',behavior:'smooth'})}};
  const stop=async save=>{if(!rec)return;const r=rec;rec=null;$('#lyRecBar').hidden=true;els().forEach(e=>e.classList.remove('rec-done','rec-next'));
    if(!save||r.ts.length<3){toast('Запись отменена');return}
    const t=cur();if(!t||t.id!==r.id)return;const L=r.L,ts=r.ts.slice();
    for(let i=ts.length;i<L.length;i++)ts.push((ts[i-1]||0)+3); /* untapped tail: 3 s apart, can be re-recorded */
    const res={...r.res,synced:L.map((x,i)=>({t:+ts[i].toFixed(2),text:x})),v:2,community:true};
    lyrMem.set(t.id,res);try{lyrStore.set(t.id,res)}catch{}
    render(res);toast('Тайминги записаны ('+r.ts.length+' строк) — сохранено для всех');
    try{if(typeof signedIn==='function'&&signedIn())await setDoc('/lrc/'+syncKey(t),{t:ts.map(x=>+x.toFixed(2)),n:L.length,at:Date.now()})}catch{}};
  $('#lyRec').onclick=e=>{e.stopPropagation();const t=cur();const res=lyrMem.get(t?.id)||lyrStore.get(t?.id);if(!t||!res?.plain)return;
    rec={id:t.id,res,L:plainLines(res),i:0,ts:[]};$('#lyRecBar').hidden=false;mark();
    if(mPos()>2)mSeek(0);if(typeof YTS!=='undefined'&&YTS.on){if(!YTS.playing)YTS.p?.playVideo?.()}else if(audio.paused)audio.play().catch(()=>{});toast('Жми «ТАП» (или пробел) в момент начала каждой строки')};
  const tap=()=>{if(!rec||rec.i>=rec.L.length)return;rec.ts.push(Math.max(0,mPos()-.12-latency()));rec.i++;mark();if(rec.i>=rec.L.length)stop(true)};
  $('#lyRecPad').onclick=e=>{e.stopPropagation();tap()};
  $('#lyRecUndo').onclick=e=>{e.stopPropagation();if(!rec||!rec.i)return;rec.i--;rec.ts.pop();mSeek(rec.ts[rec.i-1]??0);mark()};
  $('#lyRecStop').onclick=e=>{e.stopPropagation();stop(true)};
  document.addEventListener('keydown',e=>{if(rec&&e.code==='Space'){e.preventDefault();e.stopImmediatePropagation();tap()}},true);
  audio.addEventListener('loadstart',()=>{if(rec&&cur()?.id!==rec.id)stop(false)});
})();
