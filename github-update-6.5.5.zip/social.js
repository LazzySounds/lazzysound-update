'use strict';
/* Lazzy sound 4.9 — accounts like SoundCloud, on Firebase (your project; see README «Аккаунты»).
   Sign-in: the Google account already connected in the app → Firebase Auth (signInWithIdp).
   Data (Firestore): users/{uid} profile · followers/following · likes · playlists · tracks (uploads → uploader's Google Drive, free Spark plan).
   Visibility (public / friends = mutual follow / private) is enforced by firestore.rules on the server, not only in the UI. */
const FBCFG=Object.assign({apiKey:'',projectId:''},(window.LAZZY_CONFIG||{}).firebase||{},store.get('fbConfig',{}));
const Soc={uid:'',idToken:'',exp:0,me:null,ready:()=>!!(FBCFG.apiKey&&FBCFG.projectId)};
const FS=()=>`https://firestore.googleapis.com/v1/projects/${FBCFG.projectId}/databases/(default)/documents`;
const VIS={public:'Все',friends:'Друзья',private:'Только я'};

/* ---------- Firestore value codec ---------- */
const toV=v=>v==null?{nullValue:null}:typeof v==='boolean'?{booleanValue:v}:typeof v==='number'?(Number.isInteger(v)?{integerValue:String(v)}:{doubleValue:v}):typeof v==='string'?{stringValue:v}:Array.isArray(v)?{arrayValue:{values:v.map(toV)}}:{mapValue:{fields:toF(v)}};
const toF=o=>Object.fromEntries(Object.entries(o).filter(([,v])=>v!==undefined).map(([k,v])=>[k,toV(v)]));
const fromV=x=>'stringValue' in x?x.stringValue:'integerValue' in x?+x.integerValue:'doubleValue' in x?x.doubleValue:'booleanValue' in x?x.booleanValue:'nullValue' in x?null:'arrayValue' in x?(x.arrayValue.values||[]).map(fromV):'mapValue' in x?fromF(x.mapValue.fields||{}):'timestampValue' in x?x.timestampValue:null;
const fromF=f=>Object.fromEntries(Object.entries(f||{}).map(([k,v])=>[k,fromV(v)]));
const docId=d=>d.name.split('/').pop();

/* ---------- Auth ---------- */
async function fbAuth(){
  if(!Soc.ready())throw new Error('Аккаунты не настроены: Профиль → Источники → Аккаунты Lazzy');
  if(Soc.idToken&&Date.now()<Soc.exp-60000)return Soc.idToken;
  const rt=store.get('fbRefresh','');
  if(rt){const r=await fetch(`https://securetoken.googleapis.com/v1/token?key=${FBCFG.apiKey}`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=refresh_token&refresh_token='+encodeURIComponent(rt)});
    if(r.ok){const j=await r.json();Soc.idToken=j.id_token;Soc.uid=j.user_id;Soc.exp=Date.now()+j.expires_in*1000;store.set('fbRefresh',j.refresh_token);return Soc.idToken}}
  if(!window.LumenNative?.googleToken||!Google.profile){const e=new Error('Войди в аккаунт Lazzy');e.login=true;throw e}
  const id='tok-'+Date.now();const g=await gCall(id,()=>LumenNative.googleToken(id),20000);if(!g.idToken)throw new Error('Google не выдал id_token — войди через Google заново');
  const r=await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${FBCFG.apiKey}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({postBody:'id_token='+g.idToken+'&providerId=google.com',requestUri:'http://localhost',returnSecureToken:true,returnIdpCredential:true})});
  const j=await r.json();if(!r.ok){const m=j.error?.message||String(r.status);
    throw new Error(/INVALID_IDP_RESPONSE|audience|aud/i.test(m)?'Firebase не принимает вход Google: Authentication → Sign-in method → Google → «Whitelist client IDs» → добавь Client ID приложения':/OPERATION_NOT_ALLOWED/.test(m)?'В Firebase выключен вход через Google: Authentication → Sign-in method → Google → Enable':/API key|API_KEY/i.test(m)?'Неверный Firebase apiKey':'Firebase: '+m)}
  fbSession(j);return Soc.idToken;
}
function fbSession(j){Soc.idToken=j.idToken;Soc.uid=j.localId;Soc.email=j.email||'';Soc.exp=Date.now()+(+j.expiresIn)*1000;store.set('fbRefresh',j.refreshToken);if(j.email)store.set('fbEmail',j.email)}
async function fs(path,{method='GET',body,query=''}={}){
  const tok=await fbAuth();const ac=new AbortController(),tm=setTimeout(()=>ac.abort(),20000);let r;try{r=await fetch(FS()+path+query,{signal:ac.signal,method,headers:{Authorization:'Bearer '+tok,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined})}catch(e){throw e.name==='AbortError'?new Error('Сервер долго не отвечает — проверь интернет и нажми ещё раз'):e}finally{clearTimeout(tm)}
  const j=await r.json().catch(()=>({}));const em=j.error?.message||'';
  if(r.status===404){if(/database.*does not exist|NOT_FOUND.*database/i.test(em))throw Object.assign(new Error('В Firebase не создана база Firestore: Firestore Database → Create database'),{status:404});return null}
  if(!r.ok){const e=new Error(/has not been used|is disabled|SERVICE_DISABLED/i.test(em)?'В проекте выключен Cloud Firestore API — открой Firestore Database в консоли Firebase и создай базу':r.status===403?'Нет доступа к '+(path.split('/').slice(0,4).join('/')||'базе')+' ('+method+'): опубликуй firestore.rules из версии 5.3 в Firestore → Rules':'Firestore: '+(em||r.status));e.status=r.status;e.raw=em;throw e}return j;
}
async function fsCommit(writes){const root=`projects/${FBCFG.projectId}/databases/(default)/documents`;
  for(let k=0;k<writes.length;k+=400){const chunk=writes.slice(k,k+400).map(w=>w.delete?{delete:root+w.delete}:{update:{name:root+w.path,fields:toF(w.data)}});
    await fs(':commit',{method:'POST',body:{writes:chunk}})}}
const getDoc=async p=>{const d=await fs(p);return d?{id:docId(d),...fromF(d.fields)}:null};
const setDoc=(p,data,opts='')=>fs(p,{method:'PATCH',body:{fields:toF(data)},query:opts});
const delDoc=p=>fs(p,{method:'DELETE'}).catch(()=>null);
async function listDocs(p,size=300){try{const j=await fs(p,{query:'?pageSize='+size});return (j?.documents||[]).map(d=>({id:docId(d),...fromF(d.fields)}))}catch(e){if(e.status===403)return null;throw e}}
async function query(parent,coll,where,limit=100){
  const sq={from:[{collectionId:coll}],limit};if(where)sq.where=where;
  const j=await fs(parent+':runQuery',{method:'POST',body:{structuredQuery:sq}});return (j||[]).filter(x=>x.document).map(x=>({id:docId(x.document),...fromF(x.document.fields)}));
}
const fIn=(field,vals)=>({fieldFilter:{field:{fieldPath:field},op:'IN',value:toV(vals)}});

/* ---------- Model ---------- */
const trackKey=t=>String(t.id).replace(/[^A-Za-z0-9_.:-]/g,'_').slice(0,140);
const cleanTrack=t=>{const {blob,_rank,providers,_wave,_ai,_alt,...c}=t;return JSON.parse(JSON.stringify(c))};
async function staffTickFailed(){
  try{const tok=await fbAuth();const j=await fbIdt('lookup',{idToken:tok});const acc=(j.users||[])[0]||{};
    if(acc.emailVerified===false){if(!store.get('verifyMailAt',0)||Date.now()-store.get('verifyMailAt',0)>36e5){await fbIdt('sendOobCode',{requestType:'VERIFY_EMAIL',idToken:tok});store.set('verifyMailAt',Date.now())}
      toast('Галочка появится после подтверждения почты '+(acc.email||'')+' — письмо отправлено, открой ссылку и перезапусти приложение');return}
    if(!staffTickFailed.retried){staffTickFailed.retried=1;Soc.exp=0;await fbAuth();const me=Soc.me;if(me){me.verified=true;const {id,...d}=me;try{await setDoc('/users/'+Soc.uid,d);if(view==='user'&&UV.uid===Soc.uid)openUser(Soc.uid);return}catch{me.verified=false}}}
    toast('Галочка не сохранилась: в Firebase ещё старые правила — опубликуй firestore.rules')}catch{}}
/* verified tick: set only by the team accounts themselves (firestore.rules allow verified:true only for them) */
const vBadge=u=>u&&u.verified===true?'<svg class="vbadge" viewBox="0 0 24 24" role="img" aria-label="Подтверждённый аккаунт"><path d="M12 1.8l2.6 1.9 3.2-.2 1 3 2.6 1.9-1 3.1 1 3-2.6 1.9-1 3-3.2-.1L12 22.2l-2.6-1.9-3.2.2-1-3-2.6-1.9 1-3.1-1-3 2.6-1.9 1-3 3.2.1z"/><path d="M7.8 12.3l2.7 2.7 5.7-5.8" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>':'';
async function myProfile(){await fbAuth();if(Soc.me)return Soc.me;let me=await getDoc('/users/'+Soc.uid);
  if(!me){let base=(Google.profile?.email||Soc.email||store.get('fbEmail','')||'user').split('@')[0].toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,20)||'user';if(base.length<3||modTextLocal({handle:base},{handle:base}))base='user'+Math.floor(Math.random()*90000+10000);
    me={name:(n=>modTextLocal({name:n})?'Слушатель':n)(Google.profile?.name||Prefs.name||'Слушатель'),handle:base,handleLower:base,avatar:Google.profile?.picture||'',bio:'',visibility:'public',showLikes:'public',createdAt:Date.now()};
    await claimHandle(base).catch(()=>{me.handle=me.handleLower=base+Math.floor(Math.random()*9000+1000);return claimHandle(me.handleLower)});await setDoc('/users/'+Soc.uid,me);me.id=Soc.uid}
  {const pn=(Prefs.name||'').trim();if((!me.name||me.name==='Слушатель')&&pn&&pn!=='Слушатель'&&!modTextLocal({name:pn})){me.name=pn;me.nameLower='';}}
  if(me.nameLower!==(me.name||'').toLowerCase()){me.nameLower=(me.name||'').toLowerCase();const {id,...d}=me;setDoc('/users/'+Soc.uid,d).catch(()=>{})}
  {const v=typeof isStaffUser==='function'&&isStaffUser();if(!!me.verified!==v){me.verified=v;const {id,...d}=me;setDoc('/users/'+Soc.uid,d).catch(()=>{me.verified=false;staffTickFailed()})}}
  Soc.me=me;if((me.mediaOk===false||me.textOk===false)&&!Soc.recheckAt){Soc.recheckAt=1;setTimeout(recheckMedia,8000)}return me}
/* ---------- background moderation: saving never waits for the AI ---------- */
let modTimer=0,modBusy=false;
function modState(t){Soc.modState=t;const el=$('#uModState');if(el){el.textContent=t;el.hidden=!t}}
async function bgModerate(job){
  const u=Soc.me;if(!u||modBusy)return;clearTimeout(modTimer);modBusy=true;
  try{
    if(!job){const m=u.mediaOk===false?await userMedia(Soc.uid,u):{},frames=[];for(const src of [m.avatar,m.banner])if(src)frames.push(...await framesFromSrc(src));
      job={texts:u.textOk===false?{name:u.name,bio:u.bio}:{},frames}}
    if(!job.frames.length&&!Object.keys(job.texts).length){Object.assign(u,{mediaOk:true,textOk:true});return}
    modState('Профиль на проверке…');
    /* 6.4.0: text and pictures are judged separately, and only what changed — a verdict on one never wipes the other */
    const hasT=Object.values(job.texts).some(Boolean),hasF=job.frames.length>0;let tBad='',fBad='';
    const run=async j=>{try{await moderateProfile(j,{patient:true});return ''}catch(e){if(e.unavailable)throw e;return e.message||'Модерация не пропустила'}};
    try{if(hasT)tBad=await run({texts:job.texts,frames:[]});if(hasF)fBad=await run({texts:{},frames:job.frames})}
    catch(e){modState(aiHasKey?.()?'Проверка отложена — ИИ не ответил':'Проверка отложена — бесплатный ИИ занят. Свой ключ (Настройки → ИИ) проверяет сразу');modTimer=setTimeout(()=>bgModerate(),Math.min(45,Math.max(15,e.retryIn||60))*1000);return}
    if(fBad){await deleteMedia('avatar');await deleteMedia('banner');Object.assign(u,{avatarPending:'',avatarFull:false,banner:false,mediaAt:Date.now()})}
    else Object.assign(u,{avatar:u.avatarPending||u.avatar,avatarPending:''});
    if(tBad){const pv=u.prevText||{name:'Слушатель',bio:''};Object.assign(u,{name:pv.name||'Слушатель',nameLower:(pv.name||'Слушатель').toLowerCase(),bio:pv.bio??''})}
    Object.assign(u,{mediaOk:true,textOk:true,prevText:null});
    if(tBad||fBad)toast((tBad||fBad)+' — '+(tBad&&fBad?'изменения':tBad?'имя/описание':'картинки')+' не сохранены');
    const {id,...d}=u;await setDoc('/users/'+Soc.uid,d);delete Soc.media[Soc.uid];modState('');
    if(view==='user'&&UV.uid===Soc.uid)openUser(Soc.uid);
  }catch(e){console.warn('moderation',e.message)}finally{modBusy=false}
}
const recheckMedia=()=>bgModerate();
async function claimHandle(h){const cur=await getDoc('/handles/'+h).catch(()=>null);if(cur&&cur.uid!==Soc.uid)throw new Error('Имя @'+h+' занято');if(!cur)await setDoc('/handles/'+h,{uid:Soc.uid})}
async function relation(uid){
  if(uid===Soc.uid)return {self:true};
  const [iFollow,followsMe]=await Promise.all([getDoc(`/users/${uid}/followers/${Soc.uid}`).catch(()=>null),getDoc(`/users/${Soc.uid}/followers/${uid}`).catch(()=>null)]);
  return {iFollow:!!iFollow,followsMe:!!followsMe,friends:!!iFollow&&!!followsMe};
}
const allowed=(rel,v)=>rel.self||v==='public'||(v==='friends'&&rel.friends);
async function followUser(uid,on){
  if(on){await setDoc(`/users/${uid}/followers/${Soc.uid}`,{at:Date.now(),name:Soc.me?.name||'',handle:Soc.me?.handle||'',avatar:Soc.me?.avatar||''});const u=await getDoc('/users/'+uid);await setDoc(`/users/${Soc.uid}/following/${uid}`,{at:Date.now(),name:u?.name||'',handle:u?.handle||'',avatar:u?.avatar||''})}
  else{await delDoc(`/users/${uid}/followers/${Soc.uid}`);await delDoc(`/users/${Soc.uid}/following/${uid}`)}
}

/* ---------- Mirroring the local library ---------- */
let socSyncTimer=0;
function socSchedule(){if(!Soc.ready()||!store.get('fbRefresh',''))return;clearTimeout(socSyncTimer);socSyncTimer=setTimeout(socSync,4000)}
let socSyncing=false;
function syncState(t){const el=$('#uSyncState');if(el){el.textContent=t;el.hidden=!t}}
async function socSync(){
  if(socSyncing)return;socSyncing=true;
  try{await myProfile();const W=[];
    /* likes: two-way merge (known = keys present at the last sync) */
    const known=new Set(store.get('socLiked',[])),remote=await listDocs(`/users/${Soc.uid}/likes`,1000)||[],remoteKeys=new Set(remote.map(r=>trackKey(r)));
    const localKeys=new Set(S.favs.filter(t=>t.type!=='local').map(trackKey));let changedLocal=false,pulled=0;
    for(const r of remote){const k=trackKey(r);if(!localKeys.has(k)&&!known.has(k)){const {at,...t}=r;S.favs.push(t);localKeys.add(k);changedLocal=true;pulled++}}
    for(const k of known)if(!remoteKeys.has(k)&&localKeys.has(k)){S.favs=S.favs.filter(t=>trackKey(t)!==k);localKeys.delete(k);changedLocal=true}
    for(const k of known)if(remoteKeys.has(k)&&!localKeys.has(k))W.push({delete:`/users/${Soc.uid}/likes/${k}`});
    let pushed=0;S.favs.forEach((t,i)=>{if(t.type!=='local'&&!remoteKeys.has(trackKey(t))){W.push({path:`/users/${Soc.uid}/likes/${trackKey(t)}`,data:{...cleanTrack(t),at:Date.now()-i}});pushed++}});
    if(changedLocal){store.set('favs',S.favs);try{DB.saveCollection('favorites',S.favs)}catch{}try{updateUI()}catch{}if(view==='library')renderLib()}
    /* playlists */
    const vis=store.get('plVis',{}),rp=await listDocs(`/users/${Soc.uid}/playlists`,300)||[];let changedPl=false;
    const plKey=id=>String(id).replace(/[^A-Za-z0-9_:-]/g,'_');const have=new Set(Library.playlists.map(p=>plKey(p.id))),gone=new Set(Object.keys(store.get('tomb',{})).map(plKey));
    for(const r of rp){if(have.has(r.id)||gone.has(r.id))continue;Library.playlists.push({id:r.origId||r.id,name:r.name||'Плейлист',tracks:r.tracks||[],createdAt:r.updatedAt||Date.now(),updatedAt:r.updatedAt||Date.now()});vis[r.origId||r.id]=r.visibility||'private';changedPl=true}
    if(changedPl){store.set('plVis',vis);baseSave(false);if(view==='library')renderLib()}
    for(const r of rp)if(gone.has(r.id))W.push({delete:`/users/${Soc.uid}/playlists/${r.id}`});
    for(const p of Library.playlists){const prev=rp.find(r=>r.id===plKey(p.id));if(prev&&(prev.updatedAt||0)>=(p.updatedAt||0)&&prev.visibility===(vis[p.id]||'private'))continue;
      W.push({path:`/users/${Soc.uid}/playlists/${plKey(p.id)}`,data:{name:p.name,origId:p.id,visibility:vis[p.id]||'private',tracks:p.tracks.filter(t=>t.type!=='local').slice(0,500).map(cleanTrack),updatedAt:p.updatedAt||Date.now()}})}
    if(W.length)await fsCommit(W);
    store.set('socLiked',[...localKeys]);store.set('socSyncAt',Date.now());
    syncState('');if(pulled)toast(`+${pulled} в любимом с других устройств`);
    if(view==='user'&&UV.uid===Soc.uid&&(pushed||W.length))renderUserTab();
  }catch(e){console.warn('social sync',e.message);syncState('Синхронизация не удалась: '+e.message)}finally{socSyncing=false}
}
const baseFav=window.cloudFavoriteChanged;window.cloudFavoriteChanged=(t,on)=>{baseFav?.(t,on);socSchedule()};
const baseSave=Library.save.bind(Library);Library.save=function(sync=true){baseSave(sync);socSchedule()};

/* ---------- Profile page ---------- */
const UV={uid:'',tab:'tracks',rel:null,user:null};
async function openUser(uid){
  UV.busy=true;go('user');UV.busy=false;const v=$('[data-view="user"]');UV.tab='tracks';
  $('#uHead').innerHTML='<div class="loader"><i></i><i></i><i></i></div>';$('#uList').innerHTML='';
  try{await myProfile();if(uid==='me')uid=Soc.uid;UV.uid=uid;v.classList.toggle('is-self',uid===Soc.uid);$('#profile-account').hidden=true;
    let [u,rel]=await Promise.all([uid===Soc.uid?Soc.me:getDoc('/users/'+uid),relation(uid)]);if(!u)throw new Error('Профиль не найден');UV.user=u;UV.rel=rel;
    const [fol,ing]=await Promise.all([listDocs(`/users/${uid}/followers`,1000),listDocs(`/users/${uid}/following`,1000)]);
    const open=allowed(rel,u.visibility);
    const okKey='modOk:'+uid+':'+(u.mediaAt||0),seen=store.get(okKey,null),pending=!rel.self&&u.mediaOk===false,stale=Date.now()-(+u.mediaAt||0)>6e5,hide=pending&&seen!=='ok'&&!(stale&&seen!=='bad'),media=hide?{}:await userMedia(uid,u),ownAva=hide?u.avatar:u.avatarPending||u.avatar;
    const tPend=!rel.self&&u.textOk===false&&u.prevText&&!!modTextLocal({name:u.name||'',bio:u.bio||''});if(tPend){u={...u,name:u.prevText.name||u.name,bio:u.prevText.bio??u.bio}}
    if(pending&&seen==null&&!UV.checking?.[okKey]){(UV.checking=UV.checking||{})[okKey]=1;viewerCheck(uid,u,okKey)}
    const nf=fol?.length||0,ni=ing?.length||0,visIc={public:'globe',friends:'user',private:'info'}[u.visibility||'public'];
    const w=(n,a,b,c)=>plural(n,a,b,c).replace(/^\d+\s*/,'');
    const likesOk=rel.self||allowed(rel,u.showLikes||'public');
    const stats=nf||ni||rel.self||likesOk?`<div class="u-stats2"><button data-ul="followers"><b>${nf}</b><span>${w(nf,'подписчик','подписчика','подписчиков')}</span></button><button data-ul="following"><b>${ni}</b><span>${w(ni,'подписка','подписки','подписок')}</span></button><div><b id="uLikeN">${rel.self?S.favs.length:likesOk?'…':'—'}</b><span>в любимом</span></div></div>`:'';
    $('#uHead').innerHTML=`<div class="u-banner${media.banner?'':' empty'}">${media.banner?mediaTag(media.banner):hide&&u.banner?'<span class="u-checking">Обложка на проверке</span>':''}</div>
      <div class="u-card"><div class="u-ava">${media.avatar||ownAva?mediaTag(media.avatar||ownAva):esc((u.name||'?')[0].toUpperCase())}</div>
        <div class="u-copy"><h1>${esc(u.name||'Слушатель')}${vBadge(u)}</h1><p>@${esc(u.handle||'')}${rel.friends?' · <b>друзья</b>':rel.followsMe?' · подписан на тебя':''}</p></div>
</div>
      ${rel.self?`<div class="u-visrow"><button class="u-vischip" id="uVis"><svg><use href="#i-${visIc}"/></svg>${{public:'Виден всем',friends:'Только друзьям',private:'Только мне'}[u.visibility||'public']}<svg class="chev"><use href="#i-down"/></svg></button></div>`:''}
      ${u.bio?`<p class="u-bio">${esc(u.bio)}</p>`:''}${stats}
      ${rel.self?`<p class="u-note" id="uModState" ${Soc.modState?'':'hidden'}>${esc(Soc.modState||'')}</p><p class="u-note" id="uSyncState" hidden></p>`:''}
      <div class="u-actions2">${rel.self?`<button class="u-btn" id="uEdit">Изменить</button><button class="u-btn" id="uPeople"><svg><use href="#i-user"/></svg>Люди</button><label class="u-btn icon" aria-label="Загрузить трек"><svg><use href="#i-upload"/></svg><input type="file" id="uUpload" accept="audio/*" hidden></label>`
        :`<button class="u-btn ${rel.iFollow?'':'accent'}" id="uFollow">${rel.iFollow?'Вы подписаны':'Подписаться'}</button>`}<button class="u-btn icon" id="uMore" aria-label="Ещё"><svg><use href="#i-more"/></svg></button></div>
      ${open?'':`<div class="u-empty"><span class="u-empty-ic"><svg><use href="#i-info"/></svg></span><b>Закрытый профиль</b><span>${u.visibility==='friends'?'Видно только друзьям — подпишитесь друг на друга.':'Владелец скрыл профиль.'}</span></div>`}`;
    if(!rel.self&&likesOk)listDocs(`/users/${uid}/likes`,1000).then(l=>{const el=$('#uLikeN');if(el&&UV.uid===uid)el.textContent=l?(l.length>=1000?'1000+':String(l.length)):'—'}).catch(()=>{const el=$('#uLikeN');if(el)el.textContent='—'});
    $('#uSeg').hidden=!open;$$('#uSeg button').forEach(b=>b.classList.toggle('on',b.dataset.ut===UV.tab));
    if(rel.self&&Date.now()-store.get('socSyncAt',0)>60000)setTimeout(socSync,300);
    if($('#uEdit'))$('#uEdit').onclick=editProfile;if($('#uPeople'))$('#uPeople').onclick=openPeopleSearch;
    if($('#uUpload'))$('#uUpload').onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)uploadTrack(f)};
    if($('#uFollow'))$('#uFollow').onclick=async()=>{const on=!UV.rel.iFollow;$('#uFollow').disabled=true;try{await followUser(uid,on);toast(on?'Подписка оформлена':'Подписка отменена');openUser(uid)}catch(e){toast(e.message)}};
    if($('#uVis'))$('#uVis').onclick=()=>pickVisibility(u);
    $('#uMore').onclick=()=>profileMenu(u,rel);
    $$('#uHead [data-ul]').forEach(b=>b.onclick=()=>openPeople(uid,b.dataset.ul,b.dataset.ul==='followers'?fol:ing));
    if(open)renderUserTab();
  }catch(e){if(e.login){accountHero();return}$('#uHead').innerHTML=`<div class="empty"><b>Не получилось</b><span>${esc(e.message)}</span></div>`}
}
function sheetMenu(title,items){openSheet({title,sub:'',tracks:[],cover:{title}});$('#sheet').dataset.mode='people';$('#sheetActions').innerHTML='';
  $('#sheetList').innerHTML=items.map((it,i)=>`<button class="lib-row" data-mi="${i}"><div class="cover pl-empty"><svg><use href="#i-${it.icon}"/></svg></div><span class="meta"><b>${esc(it.label)}</b>${it.sub?`<span>${esc(it.sub)}</span>`:''}</span></button>`).join('');
  $('#sheetList').onclick=e=>{const b=e.target.closest('[data-mi]');if(!b)return;closeSheet();items[+b.dataset.mi].run()}}
function pickVisibility(u){sheetMenu('Кто видит профиль',[['public','globe','Виден всем'],['friends','user','Только друзьям','взаимная подписка'],['private','info','Только мне']].map(([k,icon,label,sub])=>({icon,label:label+(u.visibility===k?' ✓︎':''),sub,run:async()=>{u.visibility=k;const {id,...d}=u;try{await setDoc('/users/'+Soc.uid,d);openUser(Soc.uid)}catch(e){toast(e.message)}}})))}
function profileMenu(u,rel){
  const share={icon:'external',label:'Поделиться профилем',run:()=>shareText?.('Lazzy sound','@'+u.handle+' в Lazzy sound')};
  if(!rel.self){sheetMenu('@'+(u.handle||''),[share]);return}
  sheetMenu('Профиль',[share,
    {icon:'cloud',label:'Синхронизировать',sub:store.get('socSyncAt',0)?'Последняя: '+new Date(store.get('socSyncAt',0)).toLocaleString('ru-RU'):'',run:()=>{socSync();if(Google.profile)googleSync?.();toast('Синхронизация…')}},
    {icon:'sliders',label:'Настройки приложения',run:()=>go('profile')},
    {icon:'back',label:'Выйти из аккаунта',run:signOutAll}]);
}
/* pending pictures are shown right away; if this viewer's AI check finds them unacceptable they are hidden here */
async function viewerCheck(uid,u,okKey){try{const m=await userMedia(uid,u),frames=[];for(const src of [m.avatar,m.banner])if(src)frames.push(...await framesFromSrc(src));
  if(frames.length)await moderateProfile({frames});store.set(okKey,'ok');if(view==='user'&&UV.uid===uid)openUser(uid)}catch(e){if(e?.blocked)store.set(okKey,'bad')}}
/* ---------- avatar / banner (static or animated), stored in users/{uid}/media/{avatar|banner} ---------- */
Soc.media={};
/* media are split into ≤240 KB parts: media/{kind} = {mime, parts, animated, at}, media/{kind}_{i} = {d} */
const MEDIA_PART=240000;
async function readMedia(uid,k){try{const m=await getDoc(`/users/${uid}/media/${k}`);if(!m)return '';if(m.data)return m.data;
  const parts=await Promise.all(Array.from({length:Math.min(9,m.parts||0)},(_,i)=>getDoc(`/users/${uid}/media/${k}_${i}`)));return parts.every(Boolean)?parts.map(p=>p.d||'').join(''):''}catch{return ''}}
async function writeMedia(k,{data,animated,at}){const n=Math.ceil(data.length/MEDIA_PART);if(n>9)throw new Error('файл слишком большой');const W=[];
  for(let i=0;i<n;i++)W.push({path:`/users/${Soc.uid}/media/${k}_${i}`,data:{d:data.slice(i*MEDIA_PART,(i+1)*MEDIA_PART)}});
  W.push({path:`/users/${Soc.uid}/media/${k}`,data:{mime:(/^data:([^;,]+)/.exec(data)||[])[1]||'',parts:n,animated:!!animated,at}});await fsCommit(W)}
async function rulesProbe(){
  try{await fsCommit([{path:`/users/${Soc.uid}/media/banner_8`,data:{d:'x'}}]);await fsCommit([{delete:`/users/${Soc.uid}/media/banner_8`}]).catch(()=>{});return 'new'}catch{return 'old'}}
async function deleteMedia(k){await fsCommit([{delete:`/users/${Soc.uid}/media/${k}`},...Array.from({length:9},(_,i)=>({delete:`/users/${Soc.uid}/media/${k}_${i}`}))]).catch(()=>{})}
async function userMedia(uid,u){
  if(Soc.media[uid]&&Soc.media[uid].at===u.mediaAt)return Soc.media[uid];
  const [a,b]=await Promise.all([u.avatarFull?readMedia(uid,'avatar'):'',u.banner?readMedia(uid,'banner'):'']);
  return Soc.media[uid]={avatar:a,banner:b,at:u.mediaAt};
}
const uEmpty=(icon,title,sub,btn='')=>`<div class="u-empty"><span class="u-empty-ic"><svg><use href="#i-${icon}"/></svg></span><b>${title}</b><span>${sub}</span>${btn}</div>`;
async function renderUserTab(){
  const el=$('#uList'),uid=UV.uid,rel=UV.rel,vis=rel.self?null:rel.friends?['public','friends']:['public'];loading(el);
  try{
    if(UV.tab==='likes'){if(!allowed(rel,UV.user.showLikes||'public')){el.innerHTML=uEmpty('heart','Любимое скрыто','Владелец закрыл этот раздел.');return}
      const l=await listDocs(`/users/${uid}/likes`,300)||[];if(!l.length){el.innerHTML=uEmpty('heart',rel.self?'Здесь появятся любимые треки':'Пока пусто',rel.self?'Ставь ♥︎ трекам — они синхронизируются с аккаунтом.':'');return}renderList(el,l.sort((a,b)=>(b.at||0)-(a.at||0)));return}
    if(UV.tab==='playlists'&&!rel.self&&!allowed(rel,UV.user.showPlaylists||'public')){el.innerHTML=uEmpty('queue','Плейлисты скрыты','Владелец закрыл этот раздел.');return}
    const parent=`/users/${uid}`,coll=UV.tab==='playlists'?'playlists':'tracks';
    const docs=await query(parent,coll,vis?fIn('visibility',vis):null);
    if(coll==='tracks'){if(!docs.length){el.innerHTML=uEmpty('note','Здесь пока нет треков',rel.self?'Добавь свои треки, чтобы они появились в профиле.':'Автор ещё ничего не загрузил.',rel.self?'<button class="btn-accent u-add" id="uAdd">Добавить трек</button>':'');if($('#uAdd'))$('#uAdd').onclick=()=>$('#uUpload')?.click();return}
      renderList(el,docs.map(d=>({...d,id:'cloud:'+uid+':'+d.id,type:'cloud'})));return}
    el.innerHTML=docs.length?docs.map((p,i)=>`<button class="lib-row" data-up="${i}">${mosaicHTML(p.tracks||[])}<span class="meta"><b>${esc(p.name)}</b><span>${plural((p.tracks||[]).length,'трек','трека','треков')}${rel.self?' · '+VIS[p.visibility||'private']:''}</span></span></button>`).join(''):uEmpty('queue','Плейлистов нет',rel.self?'Создай плейлист в Медиатеке — он появится здесь (видимость меняется в меню плейлиста).':'');
    el.onclick=e=>{const b=e.target.closest('[data-up]');if(!b)return;const p=docs[+b.dataset.up];openCollection({kind:'cloudpl',kindLabel:'Плейлист @'+(UV.user.handle||''),title:p.name,sub:UV.user.name||'',coverHTML:mosaicHTML(p.tracks||[]),tracks:p.tracks||[],metaFn:tr=>plural(tr.length,'трек','трека','треков')})};
  }catch(e){el.innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}
function openPeople(uid,kind,list){openPeople0(uid,kind,list);if(list?.length){const tok=openPeople.tok=Symbol();livePeople(list.slice(0,200)).then(l=>{if(openPeople.tok===tok&&$('#sheet').dataset.mode==='people'&&$('#sheet').classList.contains('open'))openPeople0(uid,kind,l)})}}
function openPeople0(uid,kind,list){
  openSheet({title:kind==='followers'?'Подписчики':'Подписки',sub:'',tracks:[],cover:{title:kind}});$('#sheet').dataset.mode='people';$('#sheetActions').innerHTML='';
  if(!list){$('#sheetList').innerHTML='<div class="empty">Скрыто</div>';return}
  $('#sheetList').innerHTML=list.length?list.map((p,i)=>`<button class="lib-row" data-pp="${i}"><span class="cover round">${p.avatar?`<img src="${esc(p.avatar)}" alt="" referrerpolicy="no-referrer">`:esc((p.name||'?')[0])}</span><span class="meta"><b>${esc(p.name||'')}${vBadge(p)}</b><span>@${esc(p.handle||'')}</span></span></button>`).join(''):'<div class="empty">Пока никого</div>';
  $('#sheetList').onclick=e=>{const b=e.target.closest('[data-pp]');if(b){closeSheet();openUser(list[+b.dataset.pp].id)}};
}
function editProfile(){
  const u=Soc.me,m=Soc.media[Soc.uid]||{},pend={};openSheet({title:'Профиль',sub:'Как тебя видят другие',tracks:[],cover:{title:u.name||'?'}});$('#sheet').dataset.mode='editprofile';$('#sheetList').innerHTML='';
  const row=(id,cur)=>`<div class="choice-row" id="${id}">${Object.entries(VIS).map(([k,v])=>`<button data-v="${k}" class="${k===cur?'on':''}">${v}</button>`).join('')}</div>`;
  const ava=m.avatar||u.avatar,ban=m.banner;
  $('#sheetActions').innerHTML=`<div class="wave-tune">
    <div class="pe-media"><label class="pe-banner" id="peBanner">${ban?mediaTag(ban):''}<span>Обложка</span><input type="file" accept="image/*,video/mp4,video/webm" hidden></label>
      <label class="pe-ava" id="peAva">${ava?mediaTag(ava):''}<span>Аватар</span><input type="file" accept="image/*,video/mp4,video/webm" hidden></label></div>
    <p class="settings-help">Фото, GIF/WebP-анимация или короткое видео — большие анимации сжимаются автоматически (до 6 с). ${ban?'<button class="text-link" id="peBanDel">Убрать обложку</button>':''}</p>
    <label class="field-label">Имя</label><input class="settings-input" id="peName" maxlength="40" value="${esc(u.name||'')}">
    <label class="field-label">Ник</label><input class="settings-input" id="peHandle" maxlength="24" value="${esc(u.handle||'')}" placeholder="латиница, цифры, _">
    <label class="field-label">О себе</label><textarea class="settings-input" id="peBio" rows="3" maxlength="200">${esc(u.bio||'')}</textarea>
    <p class="field-label">Кто видит профиль</p>${row('peVis',u.visibility||'public')}
    <p class="field-label">Кто видит «Любимое»</p>${row('peLikes',u.showLikes||'public')}
    <p class="field-label">Кто видит плейлисты</p>${row('pePls',u.showPlaylists||'public')}
    <p class="settings-help">Имена, описание и картинки проверяет ИИ-модерация. «Друзья» — взаимная подписка.</p>
    <p class="api-status" id="peMsg"></p>
    <div class="api-actions"><button class="btn-accent" id="peSave">Сохранить</button></div></div>`;
  const msg=t=>$('#peMsg').textContent=t;
  for(const id of ['peVis','peLikes','pePls'])$('#'+id).onclick=e=>{const b=e.target.closest('[data-v]');if(!b)return;$$('#'+id+' button').forEach(x=>x.classList.toggle('on',x===b))};
  for(const [id,kind] of [['peAva','avatar'],['peBanner','banner']])$('#'+id+' input').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;msg('Готовим картинку…');
    try{const r=await prepareProfileImage(f,kind,msg);pend[kind]=r;const box=$('#'+id);box.querySelector('img,video')?.remove();box.insertAdjacentHTML('afterbegin',mediaTag(r.full));msg(r.animated?'Анимация · проверим при сохранении':'')}catch(x){msg(x.message)}};
  if($('#peBanDel'))$('#peBanDel').onclick=()=>{pend.banner=null;$('#peBanner img,#peBanner video')?.remove();$('#peBanDel').remove()};
  $('#peSave').onclick=async()=>{const h=$('#peHandle').value.trim().toLowerCase();if(!/^[a-z0-9_]{3,24}$/.test(h)){msg('Ник: 3–24 символа, латиница, цифры, _');return}
    const texts={name:$('#peName').value.trim()||'Слушатель',handle:h,bio:$('#peBio').value.trim()};
    const changed=texts.name!==u.name||h!==u.handleLower||texts.bio!==(u.bio||'')||pend.avatar||pend.banner;
    const local=modTextLocal(texts,{handle:h});if(local){msg(local);return}
    const btn=$('#peSave');btn.disabled=true;msg('Сохраняем…');
    try{
      const prevName=u.name,prevBio=u.bio||'',prevH=u.handleLower;
      const media=!!(pend.avatar||pend.banner),textChanged=texts.name!==u.name||texts.bio!==(u.bio||'')||h!==u.handleLower;
      if(h!==u.handleLower){await claimHandle(h);await delDoc('/handles/'+u.handleLower)}
      const now=Date.now();
      let mediaErr='';const putMedia=async(k,d)=>{try{await writeMedia(k,d);const back=await getDoc(`/users/${Soc.uid}/media/${k}`);if(!back||back.at!==d.at)throw new Error('не записалось');return true}catch(e){mediaErr=(k==='banner'?'обложка':'аватар')+': '+(e.status===403?(await rulesProbe()==='old'?`в Firebase-проекте ${FBCFG.projectId} всё ещё старые правила. Firestore Database → Rules → вставь firestore.rules из 5.3.3 целиком → Publish, подожди 1 минуту`:'правила отклонили файл'):e.message);return false}};
      if(pend.avatar&&!await putMedia('avatar',{data:pend.avatar.full,animated:pend.avatar.animated,at:now}))pend.avatar=null;
      if(pend.banner&&!await putMedia('banner',{data:pend.banner.full,animated:pend.banner.animated,at:now}))pend.banner=undefined;
      if(pend.avatar){Object.assign(u,{avatarPending:pend.avatar.thumb,avatarFull:true,avatarAnim:pend.avatar.animated,mediaAt:now})}
      if(pend.banner){Object.assign(u,{banner:true,bannerAnim:pend.banner.animated,mediaAt:now})}
      else if(pend.banner===null){await deleteMedia('banner');Object.assign(u,{banner:false,mediaAt:now})}
      if(textChanged&&u.textOk!==false)u.prevText={name:u.name||'Слушатель',bio:u.bio||''};
      Object.assign(u,{...texts,nameLower:texts.name.toLowerCase(),handleLower:h,visibility:$('#peVis .on').dataset.v,showLikes:$('#peLikes .on').dataset.v,showPlaylists:$('#pePls .on').dataset.v});
      if(media)u.mediaOk=false;if(textChanged)u.textOk=false;
      const {id,...data}=u;await setDoc('/users/'+Soc.uid,data);delete Soc.media[Soc.uid];closeSheet();
      if(mediaErr)modState('Не сохранено — '+mediaErr);
      toast(mediaErr?'Не сохранено — '+mediaErr:media?'Сохранено · картинки появятся для всех после проверки':'Профиль сохранён');openUser(Soc.uid);
      const chT={};if(prevName!==texts.name)chT.name=texts.name;if(prevBio!==texts.bio)chT.bio=texts.bio;if(prevH!==h)chT.handle=h;
      if(media||textChanged)bgModerate({texts:chT,frames:[...(pend.avatar?.frames||[]),...(pend.banner?.frames||[])]});
    }catch(e){msg(e.message)}finally{btn.disabled=false}};
}
async function uploadTrack(file){
  if(file.size>40e6){toast('Файл больше 40 МБ');return}
  const title=(await askText('Название трека',file.name.replace(/\.[^.]+$/,'')))?.trim();if(!title)return;if(modTextLocal({title})){toast('Недопустимое название');return}
  toast('Загружаем на твой Google Диск…');
  try{await fbAuth();const id=Date.now().toString(36),type=file.type||'audio/mpeg',b='lazzy'+id;
    const body=new Blob([`--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify({name:`Lazzy · ${title}`,mimeType:type,appProperties:{lazzy:'1'}})}\r\n--${b}\r\nContent-Type: ${type}\r\n\r\n`,file,`\r\n--${b}--`]);
    let f;try{f=await drive('/upload/drive/v3/files?uploadType=multipart&fields=id',{method:'POST',body,headers:{'Content-Type':'multipart/related; boundary='+b}})}
    catch(e){throw new Error(/403|доступа/.test(e.message)?'Разреши загрузку: выйди и войди через Google снова':e.message)}
    await drive(`/drive/v3/files/${f.id}/permissions`,{method:'POST',body:JSON.stringify({role:'reader',type:'anyone'}),headers:{'Content-Type':'application/json'}});
    const src=`https://drive.usercontent.google.com/download?id=${f.id}&export=download&confirm=t`;
    const dur=await new Promise(res=>{const a=new Audio();a.preload='metadata';a.onloadedmetadata=()=>res(Math.round(a.duration)||0);a.onerror=()=>res(0);a.src=URL.createObjectURL(file)});
    await setDoc(`/users/${Soc.uid}/tracks/${id}`,{title,artist:Soc.me?.name||'',src,driveId:f.id,duration:dur,visibility:'public',at:Date.now()});
    toast('Трек опубликован');openUser(Soc.uid);
  }catch(e){toast(e.message)}
}

/* ---------- People in search ---------- */
async function searchPeople(q,limit=6){
  if(!Soc.ready()||!signedIn())return [];q=String(q||'').trim().toLowerCase().replace(/^@/,'');if(q.length<2)return [];
  const pre=(f,v)=>({compositeFilter:{op:'AND',filters:[{fieldFilter:{field:{fieldPath:f},op:'GREATER_THAN_OR_EQUAL',value:toV(v)}},{fieldFilter:{field:{fieldPath:f},op:'LESS_THAN',value:toV(v+'')}}]}});
  const h=q.replace(/[^a-z0-9_]/g,'');
  const [a,b]=await Promise.all([h.length>=2?query('','users',pre('handleLower',h),limit).catch(()=>[]):[],query('','users',pre('nameLower',q),limit).catch(()=>[])]);
  const seen=new Set();return [...a,...b].filter(u=>!seen.has(u.id)&&seen.add(u.id)).slice(0,limit*2);
}
async function newestPeople(limit=24){const j=await fs(':runQuery',{method:'POST',body:{structuredQuery:{from:[{collectionId:'users'}],orderBy:[{field:{fieldPath:'createdAt'},direction:'DESCENDING'}],limit}}});return (j||[]).filter(x=>x.document).map(x=>({id:docId(x.document),...fromF(x.document.fields)}))}
const personRow=(p,i)=>`<button class="lib-row" data-pp="${i}"><span class="cover round">${p.avatar?`<img src="${esc(p.avatar)}" alt="" referrerpolicy="no-referrer">`:esc((p.name||'?')[0].toUpperCase())}</span><span class="meta"><b>${esc(p.name||'')}${vBadge(p)}</b><span>@${esc(p.handle||'')}${p.bio?' · '+esc(p.bio.slice(0,60)):''}</span></span></button>`;
function openPeopleSearch(){
  if(!signedIn()){openMyAccount();toast('Сначала войди в аккаунт');return}
  openSheet({title:'Люди',sub:'Поиск по имени или @нику',tracks:[],cover:{title:'Люди'}});$('#sheet').dataset.mode='people';
  $('#sheetActions').innerHTML='<div class="people-search"><input class="settings-input" id="psQ" type="search" placeholder="Имя или @ник" autocomplete="off" enterkeyhint="search"></div>';
  let list=[],gen=0;const L=$('#sheetList');
  const show=(arr,empty)=>{list=arr.filter(p=>p.id!==Soc.uid);L.innerHTML=list.length?list.map(personRow).join(''):`<div class="empty">${empty}</div>`};
  L.onclick=e=>{const b=e.target.closest('[data-pp]');if(b){closeSheet();openUser(list[+b.dataset.pp].id)}};
  const run=async()=>{const q=$('#psQ').value.trim(),g=++gen;loading(L);
    try{const r=q.length>=2?await searchPeople(q,15):await newestPeople();if(g===gen)show(r,q.length>=2?'Никого не нашли':'Пока никого')}catch(e){if(g===gen)L.innerHTML=`<div class="empty">${esc(e.message)}</div>`}};
  let t=0;$('#psQ').oninput=()=>{clearTimeout(t);t=setTimeout(run,300)};run();setTimeout(()=>$('#psQ')?.focus(),300);
}
const baseArtistHits=artistHits;
artistHits=async function(q,token){await baseArtistHits(q,token);const ppl=await searchPeople(q);if(!ppl.length||token!==searchGeneration)return;
  const el=$('#artistHits');let row=el.querySelector('.artist-hits');if(!row){el.innerHTML='<div class="artist-hits"></div>';row=el.querySelector('.artist-hits')}
  row.insertAdjacentHTML('afterbegin',ppl.map(p=>`<button class="artist-hit glass" data-uid="${esc(p.id)}"><span class="cover round">${p.avatar?`<img src="${esc(p.avatar)}" alt="" referrerpolicy="no-referrer">`:esc((p.name||'?')[0])}</span><span class="ah-copy"><b>${esc(p.name||'')}${vBadge(p)}</b><small>@${esc(p.handle||'')} · профиль</small></span></button>`).join(''));
  row.addEventListener('click',e=>{const b=e.target.closest('[data-uid]');if(b){e.stopPropagation();openUser(b.dataset.uid)}},true)};

/* ---------- Email sign-in / sign-up (Firebase Auth REST) ---------- */
const FB_ERR={EMAIL_EXISTS:'Такой email уже зарегистрирован — войди',EMAIL_NOT_FOUND:'Аккаунт не найден',INVALID_PASSWORD:'Неверный пароль',INVALID_LOGIN_CREDENTIALS:'Неверный email или пароль',INVALID_EMAIL:'Некорректный email',WEAK_PASSWORD:'Пароль минимум 6 символов',MISSING_PASSWORD:'Введи пароль',TOO_MANY_ATTEMPTS_TRY_LATER:'Слишком много попыток, попробуй позже',OPERATION_NOT_ALLOWED:'Вход по email пока выключен',USER_DISABLED:'Аккаунт отключён'};
async function fbIdt(method,body){const r=await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:${method}?key=${FBCFG.apiKey}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();
  if(!r.ok){const c=(j.error?.message||'').split(' ')[0].split(':')[0];throw new Error(FB_ERR[c]||'Ошибка входа: '+(j.error?.message||r.status))}return j}
async function afterLogin(){Soc.me=null;await myProfile();socSync();openUser(Soc.uid)}
const signedIn=()=>!!store.get('fbRefresh','');
function renderSocialSettings(){}
/* ---------- Account tab: one-tap Google (account is created automatically), email as a fallback ---------- */
function accountHero(){
  UV.uid='';$('[data-view="user"]').classList.add('is-self');$('#profile-account').hidden=true;$('#uSeg').hidden=true;$('#uList').innerHTML='';renderAccount?.();
  const g=!!window.LumenNative?.googleSignIn||webG();
  $('#uHead').innerHTML=`<div class="glass acc-hero"><span class="g-orb" aria-hidden="true"></span><h1>Аккаунт Lazzy</h1><p>Профиль, подписчики, плейлисты и свои треки — на всех устройствах. Ничего настраивать не нужно.</p>
    ${g?`<button class="google-btn" id="gIn">${G_LOGO}Продолжить с Google</button>`+(webG()?((t=>t?`<p class="settings-help">Не получается войти через Google? <a href="https://t.me/${esc(t)}" target="_blank" rel="noopener">Напиши владельцу в Telegram</a></p>`:'')(String((window.LAZZY_CONFIG||{}).ownerTelegram||'').replace(/^@/,''))):''):''}<p class="api-status" id="gStatus" role="status"></p>
    <details class="acc-email"${g?'':' open'}><summary>${g?'Другой способ — email':'Вход по email'}</summary>
      <input class="settings-input" id="lgEmail" type="email" autocomplete="email" placeholder="Email" value="${esc(store.get('fbEmail',''))}">
      <input class="settings-input" id="lgPass" type="password" autocomplete="current-password" placeholder="Пароль (мин. 6 символов)">
      <div class="api-actions"><button class="btn-accent" id="lgIn">Войти</button><button class="chip" id="lgUp">Создать аккаунт</button><button class="text-link" id="lgReset">Забыли пароль?</button></div></details></div>`;
  const msg=(t,st='')=>gStatus(t,st),val=()=>({email:$('#lgEmail').value.trim(),password:$('#lgPass').value});
  const run=async fn=>{msg('…');try{await fn();await afterLogin()}catch(e){msg(e.message,'error')}};
  if($('#gIn'))$('#gIn').onclick=async()=>{if(webG()){msg('…');webGoogleStart().catch(e=>msg(e.message,'error'));return}if(Google.profile){run(()=>fbAuth());return}await signIn()};
  $('#lgIn').onclick=()=>run(async()=>fbSession(await fbIdt('signInWithPassword',{...val(),returnSecureToken:true})));
  $('#lgUp').onclick=()=>run(async()=>{const j=await fbIdt('signUp',{...val(),returnSecureToken:true});fbSession(j);fbIdt('sendOobCode',{requestType:'VERIFY_EMAIL',idToken:j.idToken}).catch(()=>{})});
  $('#lgReset').onclick=async()=>{const e=val().email;if(!e){msg('Введи email','error');return}try{await fbIdt('sendOobCode',{requestType:'PASSWORD_RESET',email:e});msg('Письмо для сброса пароля отправлено')}catch(x){msg(x.message,'error')}};
}
/* ---------- Google on the web build (Netlify etc.): Firebase redirect flow ---------- */
const webG=()=>!window.LumenNative&&location.protocol==='https:';
/* one redirect URI per site: https://host/ (never /index.html or a deep path) */
const webRedirect=()=>location.origin+location.pathname.replace(/[^/]*$/,'');
async function webGoogleStart(){
  const cid=(window.LAZZY_CONFIG||{}).googleWebClientId;
  if(cid){const n=Math.random().toString(36).slice(2)+Date.now();store.set('gWebSession','idt');store.set('gWebNonce',n);
    location.href='https://accounts.google.com/o/oauth2/v2/auth?'+new URLSearchParams({client_id:cid,redirect_uri:webRedirect(),response_type:'id_token',scope:'openid email profile',nonce:n,prompt:'select_account'});return}
  let j;try{j=await fbIdt('createAuthUri',{providerId:'google.com',continueUri:webRedirect(),customParameter:{prompt:'select_account'}})}
  catch(e){throw new Error(/UNAUTHORIZED_DOMAIN|INVALID_CONTINUE_URI/.test(e.message)?'Добавь '+location.hostname+' в Firebase → Authentication → Settings → Authorized domains':e.message)}
  store.set('gWebSession',j.sessionId);location.href=j.authUri}
async function webGoogleFinish(){
  const sid=store.get('gWebSession','');if(!sid||!/[?&#](code|state|id_token|error)=/.test(location.href))return;store.set('gWebSession','');
  const url=location.href;history.replaceState(null,'',location.pathname);
  const idt=new URLSearchParams(url.split('#')[1]||'').get('id_token'),err=new URLSearchParams(url.split('#')[1]||'').get('error');
  if(err){toast('Google: '+err);return}
  /* the id_token must carry the nonce this device asked for (blocks injected/replayed tokens) */
  if(sid==='idt'){const want=store.get('gWebNonce','');store.set('gWebNonce','');let got='';try{got=JSON.parse(decodeURIComponent(escape(atob(String(idt||'').split('.')[1].replace(/-/g,'+').replace(/_/g,'/')))))?.nonce||''}catch{}
    if(!want||got!==want){toast('Google: вход отклонён (проверка безопасности)');return}}
  try{fbSession(await fbIdt('signInWithIdp',sid==='idt'?{postBody:'id_token='+idt+'&providerId=google.com',requestUri:location.origin,returnSecureToken:true,returnIdpCredential:true}:{requestUri:url,sessionId:sid,returnSecureToken:true,returnIdpCredential:true}));UV.busy=true;go('user');UV.busy=false;await afterLogin()}
  catch(e){toast('Google: '+e.message)}}
if(webG())setTimeout(webGoogleFinish,300);
function openAccount(){
  if(signedIn()){openUser(Soc.uid||'me');return}
  if(Google.profile&&Soc.ready()){fbAuth().then(afterLogin).catch(e=>{accountHero();gStatus(e.message,'error')});return}
  accountHero();
}
function openMyAccount(){UV.busy=true;go('user');UV.busy=false;openAccount()}
const openLogin=openMyAccount;
window.onGoogleSignedIn=()=>{if(Soc.ready())fbAuth().then(afterLogin).catch(e=>gStatus(e.message,'error'))};
function signOutAll(){store.set('fbRefresh','');store.set('fbEmail','');Soc.idToken='';Soc.uid='';Soc.me=null;Soc.media={};
  if(Google.profile){try{LumenNative.googleSignOut()}catch{}Google.profile=null;applyGoogleProfile()}
  accountHero();toast('Ты вышел из аккаунта')}
go=(base=>function(v){base.apply(this,arguments);if(v==='user'&&!UV.busy)openAccount()})(go);
$$('#uSeg button').forEach(b=>b.onclick=()=>{UV.tab=b.dataset.ut;$$('#uSeg button').forEach(x=>x.classList.toggle('on',x===b));renderUserTab()});
$('#uBack').onclick=openMyAccount;
/* playlist visibility from the playlist menu */
document.addEventListener('click',e=>{if(!e.target.closest('#colMenu')||!Soc.ready()||!store.get('fbRefresh',''))return;setTimeout(()=>{const pl=Library.get(colState?.id);if(!pl||!$('#sheetActions'))return;
  const vis=store.get('plVis',{});const b=document.createElement('div');b.className='choice-row';b.innerHTML=Object.entries(VIS).map(([k,v])=>`<button data-pv="${k}" class="${(vis[pl.id]||'private')===k?'on':''}">${v}</button>`).join('');
  const lab=document.createElement('p');lab.className='field-label';lab.textContent='Кто видит плейлист в профиле';$('#sheetActions').append(lab,b);
  b.onclick=ev=>{const x=ev.target.closest('[data-pv]');if(!x)return;vis[pl.id]=x.dataset.pv;store.set('plVis',vis);b.querySelectorAll('button').forEach(y=>y.classList.toggle('on',y===x));socSchedule();toast('Видимость: '+VIS[x.dataset.pv])}},60)},true);
if(store.get('fbRefresh',''))setTimeout(socSync,6000);
/* ---------- notifications (new followers) ---------- */
/* 6.5.3: follow records keep the name/avatar from the moment of following — show the person's current profile instead */
const liveCache=new Map();
async function livePeople(list){return Promise.all((list||[]).map(async p=>{try{let u=liveCache.get(p.id);if(!u||Date.now()-u.t>120000){const d=await bounded(getDoc('/users/'+p.id),8000);u={t:Date.now(),d};liveCache.set(p.id,u)}
  const d=u.d;if(!d)return p;const tPend=d.textOk===false&&d.prevText&&modTextLocal({name:d.name||'',bio:d.bio||''});
  return {...p,name:(tPend?d.prevText.name:d.name)||p.name,handle:d.handle||p.handle,avatar:d.avatar||'',verified:d.verified===true}}catch{return p}}))}
async function loadNotifs(){if(!signedIn()||!Soc.ready())return [];await myProfile();const l=await listDocs(`/users/${Soc.uid}/followers`,200)||[];return l.sort((a,b)=>(b.at||0)-(a.at||0))}
async function checkNotifs(){try{const l=await loadNotifs(),seen=store.get('notifSeen',0);const n=l.filter(x=>(x.at||0)>seen).length;const d=$('#notifBtn .top-dot');if(d)d.hidden=!n}catch{}}
async function openNotifications(){
  if(!signedIn()){openMyAccount();toast('Войди, чтобы видеть уведомления');return}
  openSheet({title:'Уведомления',sub:'',tracks:[],cover:{title:'!'}});$('#sheet').dataset.mode='people';$('#sheetActions').innerHTML='';loading($('#sheetList'));
  try{const l=await livePeople((await loadNotifs()).slice(0,60)),seen=store.get('notifSeen',0);store.set('notifSeen',Date.now());$('#notifBtn .top-dot').hidden=true;
    $('#sheetList').innerHTML=l.length?l.slice(0,60).map((p,i)=>`<button class="lib-row${(p.at||0)>seen?' is-new':''}" data-pp="${i}"><span class="cover round">${p.avatar?`<img src="${esc(p.avatar)}" alt="" referrerpolicy="no-referrer">`:esc((p.name||'?')[0])}</span><span class="meta"><b>${esc(p.name||'@'+p.handle)}</b><span>подписался на тебя · ${p.at?new Date(p.at).toLocaleDateString('ru-RU'):''}</span></span></button>`).join(''):uEmpty('bell','Пока тихо','Здесь появятся новые подписчики.');
    $('#sheetList').onclick=e=>{const b=e.target.closest('[data-pp]');if(b){closeSheet();openUser(l[+b.dataset.pp].id)}}}
  catch(e){$('#sheetList').innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}
$('#notifBtn')?.addEventListener('click',openNotifications);
if(signedIn()){setTimeout(checkNotifs,9000);setInterval(checkNotifs,5*60000)}
