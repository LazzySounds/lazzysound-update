'use strict';
/* Lazzy sound 3.4 — swipeable tabs.
   Profile is split into «Аккаунт · Вид · ИИ · Источники»; Library keeps its tabs. In both, a horizontal swipe on the
   content follows the finger and flips to the neighbouring tab; tapping a tab slides in the same direction. */
const SWIPE_EASE='cubic-bezier(.2,.9,.25,1)';

function slideIn(el,dir){
  if(!el||!dir||reducedMotionTabs())return;
  el.getAnimations().forEach(a=>a.cancel());
  el.animate([{transform:`translate3d(${dir*56}px,0,0)`},{transform:'none'}],{duration:300,easing:SWIPE_EASE});
}
const reducedMotionTabs=()=>document.documentElement.dataset.motion==='reduce'||window.LZ_OSREDUCE===true;

/** Horizontal swipe on `area` moves `moving` and calls set(index±1). Vertical scrolling is untouched. */
function swipeTabs({area,moving,keys,get,set}){
  area.classList.add('swipe-area');
  let x0=0,y0=0,t0=0,dx=0,lock=null,active=false;
  const skip=e=>e.target.closest('input[type=range],.cards,.seg,.choice-row,.accent-choices,.icon-grid,.avatar-grid,.fx-choices,.wave-modes,.q-grip,.artist-hits,select,textarea');
  area.addEventListener('touchstart',e=>{if(e.touches.length!==1||skip(e)){active=false;return}active=true;lock=null;dx=0;x0=e.touches[0].clientX;y0=e.touches[0].clientY;t0=performance.now()},{passive:true});
  area.addEventListener('touchmove',e=>{
    if(!active)return;const tx=e.touches[0].clientX-x0,ty=e.touches[0].clientY-y0;
    if(lock===null&&(Math.abs(tx)>10||Math.abs(ty)>10))lock=Math.abs(tx)>Math.abs(ty)*1.25?'x':'y';
    if(lock!=='x')return;
    const i=keys().indexOf(get());const edge=(tx>0&&i<=0)||(tx<0&&i>=keys().length-1);
    dx=edge?tx*.25:tx;moving.style.transform=`translate3d(${dx}px,0,0)`;
  },{passive:true});
  const end=()=>{
    if(!active)return;active=false;if(lock!=='x')return;
    const ks=keys(),i=ks.indexOf(get()),v=dx/Math.max(1,performance.now()-t0);
    const dir=(dx<-Math.min(90,innerWidth*.22)||v<-.5)?1:(dx>Math.min(90,innerWidth*.22)||v>.5)?-1:0;
    const j=i+dir;
    if(dir&&j>=0&&j<ks.length){
      moving.style.transform='';
      window.__quietList=true;set(ks[j]);setTimeout(()=>{window.__quietList=false});
      if(!reducedMotionTabs())moving.animate([{transform:`translate3d(${dir*Math.min(120,innerWidth*.25)}px,0,0)`},{transform:'none'}],{duration:320,easing:SWIPE_EASE});
      if(navigator.vibrate)try{navigator.vibrate(6)}catch{}
    }else{
      moving.animate([{transform:`translate3d(${dx}px,0,0)`},{transform:'none'}],{duration:300,easing:SWIPE_EASE});
      moving.style.transform='';
    }
    dx=0;lock=null;
  };
  area.addEventListener('touchend',end,{passive:true});area.addEventListener('touchcancel',end,{passive:true});
}

/* ---------- Profile tabs: a native scroll-snap carousel ----------
   The browser moves the pages under the finger on the compositor (no JS per frame, full 120/144 Hz).
   Inactive pages are collapsed only after the swipe settles, so the page height follows the open tab. */
(function profileTabs(){
  const view=$('[data-view="profile"]');if(!view)return;
  const groupOf=sel=>{const n=view.querySelector(sel);return n?(n.closest('.settings-group,.profile-card,.profile-stats,.profile-account,.connection-note')||n):null};
  const PANES=[
    ['design','Дизайн',['#themeChoices','#fontChoice','#iconChoices']],
    ['bg','Фон',['#fxSettings']],
    ['lyrics','Текст',['#lyricsSettings','#gemSettings','#asrSettings']],
    ['ai','ИИ',['#aiSettings']],
    ['sources','Музыка',['#offlineSettings','#scSettings','#spSettings','#ymSettings','#hitmozSettings','#jamendoSettings','#apiSettings','.connection-note']],
    ['net','<svg class="ptab-ic"><use href="#i-sliders"/></svg>Мод',['#netSettings']],
    ['me','Профиль',['#profileName','#avatarChoices','#perfSettings','#reduceMotion']]
  ];
  const seg=document.createElement('div');seg.className='seg ptabs';seg.id='profileSeg';
  seg.innerHTML=PANES.map(([k,l])=>`<button data-ptab="${k}">${l}</button>`).join('');
  const track=document.createElement('div');track.className='ptab-track';track.id='profilePanes';
  view.querySelector('.page-title').after(seg,track);
  const panes=PANES.map(([k,,sels])=>{const pane=document.createElement('div');pane.className='ptab-pane';pane.dataset.pane=k;for(const s of sels){const g=groupOf(s);if(g)pane.appendChild(g)}track.appendChild(pane);return pane});
  const keys=PANES.map(p=>p[0]);
  let current=store.get('profileTab','design');if(!keys.includes(current))current='design';
  let expanded=false,settleTimer=0,programmatic=false;
  const idx=()=>Math.max(0,Math.min(keys.length-1,Math.round(track.scrollLeft/Math.max(1,track.clientWidth))));
  const markSeg=k=>seg.querySelectorAll('button').forEach(b=>{const on=b.dataset.ptab===k;b.classList.toggle('on',on);if(on){const l=b.offsetLeft-(seg.clientWidth-b.offsetWidth)/2;seg.scrollTo({left:Math.max(0,l),behavior:'smooth'})}});
  function expand(){if(expanded)return;expanded=true;panes.forEach(p=>p.classList.remove('collapsed'))}
  function collapse(){expanded=false;panes.forEach(p=>p.classList.toggle('collapsed',p.dataset.pane!==current))}
  function settle(){
    programmatic=false;const k=keys[idx()];const changed=k!==current;current=k;store.set('profileTab',k);markSeg(k);
    const top=seg.getBoundingClientRect().top+scrollY-70;
    collapse();
    if(changed&&scrollY>top)scrollTo({top,behavior:'instant'});
    if(changed&&k==='design'&&typeof renderIconPicker==='function')renderIconPicker();
  }
  function go(k,smooth=true){
    const i=keys.indexOf(k);if(i<0)return;expand();markSeg(k);programmatic=true;
    track.scrollTo({left:i*track.clientWidth,behavior:smooth&&!reducedMotionTabs()?'smooth':'instant'});
    clearTimeout(settleTimer);settleTimer=setTimeout(settle,smooth?450:30);
  }
  let tx=0,ty=0,horiz=false;
  track.addEventListener('touchstart',e=>{const t=e.touches[0];tx=t.clientX;ty=t.clientY;horiz=false},{passive:true});
  track.addEventListener('touchmove',e=>{if(horiz)return;const t=e.touches[0],dx=Math.abs(t.clientX-tx),dy=Math.abs(t.clientY-ty);if(dx>10&&dx>dy*1.3){horiz=true;clearTimeout(settleTimer);expand()}},{passive:true});
  track.addEventListener('touchend',()=>{if(!horiz)return;clearTimeout(settleTimer);settleTimer=setTimeout(settle,220)},{passive:true});
  track.addEventListener('scroll',()=>{expand();if(!programmatic)markSeg(keys[idx()]);clearTimeout(settleTimer);settleTimer=setTimeout(settle,140)},{passive:true});
  if('onscrollend' in window)track.addEventListener('scrollend',()=>{clearTimeout(settleTimer);settle()});
  seg.onclick=e=>{const b=e.target.closest('[data-ptab]');if(b&&b.dataset.ptab!==keys[idx()])go(b.dataset.ptab)};
  window.setProfileTab=k=>go(k,false);
  // open on the remembered tab without animation
  markSeg(current);collapse();
  const place=()=>{track.scrollLeft=keys.indexOf(current)*track.clientWidth};
  new MutationObserver(()=>{if(view.classList.contains('active'))requestAnimationFrame(place)}).observe(view,{attributes:true,attributeFilter:['class']});
  addEventListener('resize',()=>{expand();place();collapse()});
  requestAnimationFrame(place);
})();

/* ---------- Library tabs ---------- */
(function libraryTabs(){
  const seg=$('#libSeg'),list=$('#libList');if(!seg||!list)return;
  const keys=()=>[...seg.querySelectorAll('button')].map(b=>b.dataset.lib);
  const host=document.createElement('div');host.className='lib-panes';list.before(host);host.append($('#libActions'),list);
  seg.addEventListener('click',e=>{const b=e.target.closest('[data-lib]');if(!b)return;const before=keys().indexOf(libTab);window.__quietList=true;requestAnimationFrame(()=>{window.__quietList=false;slideIn(host,Math.sign(keys().indexOf(b.dataset.lib)-before))})},true);
  swipeTabs({area:$('[data-view="library"]'),moving:host,keys,get:()=>libTab,set:k=>{libTab=k;renderLib()}});
})();
