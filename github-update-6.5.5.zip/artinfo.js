'use strict';
/* 6.1.4: richer artist info — Wikipedia (ru/en) bio, Wikidata facts + links, MusicBrainz (genres, area, years, links), AI as last resort. */
const AI_MUSIC_RX=/музык|групп|певиц|певец|рэпер|репер|исполнит|композит|диджей|продюсер|автор-исполн|коллектив|ансамбл|singer|band|rapper|musician|\bdj\b|producer|songwriter|\bduo\b|group|record|album/i;
const mbWait=(()=>{let last=0;return async()=>{const w=1100-(Date.now()-last);if(w>0)await new Promise(r=>setTimeout(r,w));last=Date.now()}})();
const cleanName=s=>String(s||'').replace(/\s*\([^)]*\)\s*$/,'').trim();

async function wikiFind(name,lang){
  const q=name+(lang==='ru'?' музыкант OR группа OR исполнитель':' musician OR band OR singer OR rapper');
  const u=`https://${lang}.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrlimit=8&gsrsearch=${encQ(q)}&prop=extracts|pageprops|description&exintro=1&explaintext=1&ppprop=wikibase_item&redirects=1`;
  const j=await extGet(u,7*864e5);const pages=Object.values(j?.query?.pages||{}).sort((a,b)=>(a.index||0)-(b.index||0));
  const ok=p=>similarity(name,cleanName(p.title))>.78&&AI_MUSIC_RX.test((p.description||'')+' '+(p.extract||'').slice(0,500));
  const p=pages.find(ok);if(!p)return null;
  return {lang,title:p.title,text:String(p.extract||'').replace(/\n{3,}/g,'\n\n').trim(),desc:p.description||'',qid:p.pageprops?.wikibase_item||'',url:`https://${lang}.wikipedia.org/wiki/${encodeURIComponent(p.title.replace(/ /g,'_'))}`}}

async function mbFind(name){
  await mbWait();const j=await extGet('https://musicbrainz.org/ws/2/artist/?fmt=json&limit=5&query='+encQ('artist:"'+name.replace(/"/g,'')+'"'),7*864e5);
  const a=(j.artists||[]).find(x=>(x.score||0)>=85&&similarity(name,x.name)>.8);if(!a)return null;
  await mbWait();let full={};try{full=await extGet(`https://musicbrainz.org/ws/2/artist/${a.id}?fmt=json&inc=url-rels+genres+tags`,7*864e5)}catch{}
  return {...a,...full}}

const WD_CLAIMS={genre:'P136',label:'P264',members:'P527',birthPlace:'P19',formedIn:'P740',country:'P495',citizen:'P27',inception:'P571',dissolved:'P576',born:'P569',workStart:'P2031',
  site:'P856',instagram:'P2003',vk:'P3185',telegram:'P3789',youtube:'P2397',spotify:'P1902',yandex:'P1553',apple:'P2850',genius:'P2373',discogs:'P1953',mb:'P434',lastfm:'P3192',twitter:'P2002',soundcloud:'P3040',bandcamp:'P3283'};
async function wdFacts(qid){
  if(!/^Q\d+$/.test(qid||''))return null;
  const j=await extGet(`https://www.wikidata.org/w/api.php?action=wbgetentities&format=json&origin=*&ids=${qid}&props=claims`,7*864e5);
  const cl=j?.entities?.[qid]?.claims||{};const vals=p=>(cl[p]||[]).filter(c=>c.rank!=='deprecated').map(c=>c.mainsnak?.datavalue?.value).filter(v=>v!=null);
  const out={};const ids=new Set();
  for(const [k,p] of Object.entries(WD_CLAIMS)){const v=vals(p);if(!v.length)continue;
    if(typeof v[0]==='object'&&v[0].id){out[k]=v.slice(0,8).map(x=>x.id);out[k].forEach(i=>ids.add(i))}
    else if(typeof v[0]==='object'&&v[0].time){const m=String(v[0].time).match(/^[+-](\d{4})-(\d\d)-(\d\d)/);if(m)out[k]={y:+m[1],m:+m[2],d:+m[3],prec:v[0].precision}}
    else out[k]=String(v[0])}
  if(ids.size){try{const L=await extGet(`https://www.wikidata.org/w/api.php?action=wbgetentities&format=json&origin=*&ids=${[...ids].slice(0,50).join('|')}&props=labels&languages=ru|en`,7*864e5);
    const lab=i=>{const e=L?.entities?.[i]?.labels||{};return (e.ru||e.en||{}).value||''};
    for(const k of Object.keys(out))if(Array.isArray(out[k]))out[k]=out[k].map(lab).filter(Boolean)}catch{for(const k of Object.keys(out))if(Array.isArray(out[k]))delete out[k]}}
  return out}

async function aiBio(name){
  if(typeof aiAsk!=='function')return '';
  const t=await aiAsk('Ты музыкальный справочник. Пиши по-русски, кратко и только проверенные факты.',`Кто такой музыкальный исполнитель «${name}»? 3–5 предложений: жанр, откуда, с какого года, чем известен, известные песни. Если ты не знаешь этого исполнителя достоверно, ответь одним словом: НЕТ.`);
  const s=String(t||'').trim();return /^нет\.?$/i.test(s)||s.length<40?'':s.slice(0,1500)}

const MONTHS=['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
const wdDate=d=>!d?'':d.prec>=11&&d.m&&d.d?`${d.d} ${MONTHS[d.m-1]} ${d.y}`:String(d.y);
const uniq=a=>[...new Set(a.filter(Boolean).map(s=>String(s).trim()))];
const cap=s=>s?s[0].toUpperCase()+s.slice(1):s;

/* 6.1.6: Genius API (read-only client token) — artist bio, aliases, socials, exact song pages. Lyrics are not taken from Genius. */
const gTok=()=>(window.LAZZY_CONFIG||{}).geniusToken||'';
const gApi=(path,ttl=7*864e5)=>extGet('https://api.genius.com'+path+(path.includes('?')?'&':'?')+'access_token='+encodeURIComponent(gTok()),ttl).then(j=>j?.response||{});
async function geniusArtist(name){
  if(!gTok())return null;const r=await gApi('/search?per_page=10&q='+encQ(name));
  const a=(r.hits||[]).map(h=>h.result?.primary_artist).filter(Boolean).find(a=>similarity(name,cleanName(a.name))>.82||similarity(name,a.name.split(/\s*\(/)[0])>.82);if(!a)return null;
  const d=(await gApi('/artists/'+a.id+'?text_format=plain')).artist||a;
  let bio=String(d.description?.plain||'').trim();if(bio==='?'||bio.length<30)bio='';
  return {id:a.id,name:d.name,url:d.url,bio,alt:d.alternate_names||[],ig:d.instagram_name||'',tw:d.twitter_name||'',fb:d.facebook_name||'',verified:!!d.is_verified}}
async function geniusSong(t){
  if(!gTok())return null;const ti=typeof cleanTitle==='function'?cleanTitle(t.title):t.title,ar=typeof cleanArtist==='function'?cleanArtist(t.artist):t.artist;
  const r=await gApi('/search?per_page=8&q='+encQ(ar+' '+ti));
  const h=(r.hits||[]).map(h=>h.result).find(s=>s&&similarity(normalize(ti),normalize(s.title||''))>.75&&(!ar||similarity(normalize(ar),normalize(s.primary_artist?.name||''))>.6||similarity(normalize(ar),normalize(s.artist_names||''))>.6));
  return h?{url:h.url,date:h.release_date_for_display||'',title:h.full_title}:null}
async function artistInfo(name){
  const [wr,we,mb,gr]=await Promise.allSettled([wikiFind(name,'ru'),wikiFind(name,'en'),mbFind(name),geniusArtist(name)]);
  const W=wr.value||null,E=we.value||null,M=mb.value||null,G=gr.value||null;
  let qid=W?.qid||E?.qid||'';
  if(!qid&&M?.relations){const r=M.relations.find(r=>r.type==='wikidata');const m=r?.url?.resource?.match(/Q\d+$/);if(m)qid=m[0]}
  const D=await wdFacts(qid).catch(()=>null)||{};
  const links=[];const add=(label,url)=>{if(url&&/^https:\/\//.test(url)&&!links.some(l=>l.url===url))links.push({label,url})};
  if(W)add('Википедия',W.url);else if(E)add('Wikipedia',E.url);
  if(G){add('Genius',G.url);if(G.ig)add('Instagram','https://www.instagram.com/'+encodeURIComponent(G.ig));if(G.tw)add('X','https://x.com/'+encodeURIComponent(G.tw));if(G.fb)add('Facebook','https://www.facebook.com/'+encodeURIComponent(G.fb))}
  add('Сайт',D.site&&D.site.replace(/^http:/,'https:'));
  if(D.yandex)add('Яндекс Музыка','https://music.yandex.ru/artist/'+encodeURIComponent(D.yandex));
  if(D.spotify)add('Spotify','https://open.spotify.com/artist/'+encodeURIComponent(D.spotify));
  if(D.apple)add('Apple Music','https://music.apple.com/artist/'+encodeURIComponent(D.apple));
  if(D.youtube)add('YouTube','https://www.youtube.com/channel/'+encodeURIComponent(D.youtube));
  if(D.vk)add('VK','https://vk.com/'+encodeURIComponent(D.vk));
  if(D.telegram)add('Telegram','https://t.me/'+encodeURIComponent(D.telegram));
  if(D.instagram)add('Instagram','https://www.instagram.com/'+encodeURIComponent(D.instagram));
  if(D.twitter)add('X','https://x.com/'+encodeURIComponent(D.twitter));
  if(D.soundcloud)add('SoundCloud','https://soundcloud.com/'+encodeURIComponent(D.soundcloud));
  if(D.genius)add('Genius','https://genius.com/artists/'+encodeURIComponent(D.genius));
  if(D.bandcamp)add('Bandcamp','https://'+encodeURIComponent(D.bandcamp)+'.bandcamp.com');
  if(D.discogs)add('Discogs','https://www.discogs.com/artist/'+encodeURIComponent(D.discogs));
  if(D.lastfm)add('Last.fm','https://www.last.fm/music/'+encodeURIComponent(D.lastfm));
  const REL={'official homepage':'Сайт',youtube:'YouTube',bandcamp:'Bandcamp',soundcloud:'SoundCloud',discogs:'Discogs','last.fm':'Last.fm',songkick:'Songkick',vk:'VK',instagram:'Instagram',genius:'Genius',spotify:'Spotify','apple music':'Apple Music',deezer:'Deezer',telegram:'Telegram'};
  for(const r of M?.relations||[]){const u=r.url?.resource||'';let lab=REL[r.type];
    if(!lab&&r.type==='social network')lab=/vk\.com/.test(u)?'VK':/instagram/.test(u)?'Instagram':/t\.me/.test(u)?'Telegram':/twitter|x\.com/.test(u)?'X':/tiktok/.test(u)?'TikTok':'';
    if(!lab&&r.type==='streaming'||!lab&&r.type==='free streaming')lab=/spotify/.test(u)?'Spotify':/music\.yandex/.test(u)?'Яндекс Музыка':/music\.apple/.test(u)?'Apple Music':/deezer/.test(u)?'Deezer':/soundcloud/.test(u)?'SoundCloud':/youtube/.test(u)?'YouTube':'';
    if(lab&&!links.some(l=>l.label===lab))add(lab,u.replace(/^http:/,'https:'))}
  if(M?.id)add('MusicBrainz','https://musicbrainz.org/artist/'+M.id);
  const group=M?.type==='Group'||!!D.inception||!!D.members;
  const years=D.inception?`с ${wdDate(D.inception)}${D.dissolved?' по '+wdDate(D.dissolved):''}`:M?.['life-span']?.begin&&group?`с ${M['life-span'].begin.slice(0,4)}${M['life-span'].end?' по '+M['life-span'].end.slice(0,4):''}`:'';
  const born=D.born?wdDate(D.born):(!group&&M?.['life-span']?.begin?M['life-span'].begin.slice(0,4):'');
  const from=uniq([...(D.formedIn||[]),...(D.birthPlace||[])]).slice(0,2).join(', ')||M?.['begin-area']?.name||M?.area?.name||'';
  const country=uniq([...(D.country||[]),...(D.citizen||[])])[0]||'';
  const wg=D.genre||[],mg=[...(M?.genres||[]).sort((a,b)=>(b.count||0)-(a.count||0)).map(g=>g.name),...(M?.tags||[]).filter(t=>(t.count||0)>0).sort((a,b)=>b.count-a.count).map(t=>t.name)];const genres=uniq(wg.length>=2?wg:[...wg,...mg]).slice(0,6).map(cap);
  const facts=[
    ['Кто',cap(W?.desc||E?.desc||M?.disambiguation||(group?'Группа':''))],
    ['Жанры',genres.join(', ')],
    [group?'Годы':'Родился',group?years:born],
    ['Откуда',[from,country&&!from.includes(country)?country:''].filter(Boolean).join(', ')],
    ['Лейблы',(D.label||[]).slice(0,4).join(', ')],
    ['Состав',(D.members||[]).slice(0,8).join(', ')]
  ].filter(f=>f[1]);
  let bio=W?.text||'',bioSrc=W?'Википедия':'';
  if(G?.bio&&(!bio||/[а-яё]/i.test(G.bio)&&!/[а-яё]/i.test(bio))){bio=G.bio;bioSrc='Genius'}
  if(!bio&&E?.text){bio=E.text;bioSrc='Wikipedia (EN)'}
  if(G?.alt?.length)facts.push(['Также',G.alt.slice(0,5).join(', ')]);
  return {facts,bio,bioSrc,links,srcs:uniq([W||E?'Википедия':'',G?'Genius':'',Object.keys(D).length?'Wikidata':'',M?'MusicBrainz':''])}}

/* render into the artist page: replaces the 5.9 «Об исполнителе» block */
function aboutHTML(name,info,A,D){
  const facts=[...info.facts];
  const adbFacts=[['Жанры',A?.strGenre],['Откуда',A?.strCountry],['Годы',A?.intFormedYear&&+A.intFormedYear?'с '+A.intFormedYear:'']];
  for(const [k,v] of adbFacts)if(v&&!facts.some(f=>f[0]===k))facts.push([k,v]);
  if(D?.nb_fan)facts.push(['Deezer',compactNum(D.nb_fan)+' фанатов'+(D.nb_album?' · '+D.nb_album+' альб.':'')]);
  let bio=info.bio,src=info.bioSrc;
  const adb=(A?.strBiographyRU||'').trim()||(A?.strBiographyEN||'').trim();
  if(!bio&&adb){bio=adb;src='TheAudioDB'}else if(bio&&adb&&adb.length>bio.length*1.6&&!info.bio.includes(adb.slice(0,40))){bio=bio+'\n\n'+adb;src+=' · TheAudioDB'}
  const links=[...info.links];if(A?.strWebsite&&!links.some(l=>l.label==='Сайт'))links.unshift({label:'Сайт',url:'https://'+A.strWebsite.replace(/^https?:\/\//,'')});
  const srcs=uniq([...info.srcs,A?'TheAudioDB':'',D?'Deezer':'']).join(' · ');
  if(!facts.length&&!bio&&!links.length)return '';
  return `<div class="ext-about ai-about"><div class="shelf-head"><h2>Об исполнителе</h2><span class="shelf-sub">${esc(srcs)}</span></div>
    ${facts.length?`<dl class="ai-facts">${facts.map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`:''}
    ${bio?`<p class="ext-bio">${esc(bio)}</p><div class="ai-bio-foot"><button class="text-link ext-more">Читать полностью</button><small>${esc(src)}</small></div>`:`<div class="ai-bio-foot"><button class="chip" id="aiBioGen"><svg><use href="#i-spark"/></svg>Рассказать с помощью ИИ</button></div>`}
    ${links.length?`<div class="ai-links">${links.slice(0,16).map(l=>`<button class="chip ext-link" data-url="${esc(l.url)}"><svg><use href="#i-external"/></svg>${esc(l.label)}</button>`).join('')}</div>`:''}</div>`}
