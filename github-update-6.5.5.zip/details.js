'use strict';
/* Track notebook, device database and music-only radio. No cloud-login imitation. */
function isMusicStation(s){
 const text=String(s.name||'')+' '+String(s.tags||'');
 if(/news|politic|current affairs|talk|spoken|weather|traffic|sport|спорт|новост|политик|разговор|информаци|публицист|ток-шоу/i.test(text))return false;
 return /(^|[ ,;/])(music|pop|rock|jazz|lo-?fi|electro\w*|dance|house|techno|trance|classical|classic|chill\w*|ambient|hip[ -]?hop|rnb|r&b|soul|funk|disco|synth\w*|metal|blues|reggae|country|indie|instrumental|lounge|музыка|джаз|рок|классика)([ ,;/]|$)/i.test(String(s.tags||''));
}
$('#restoreRadio').onclick=()=>{RadioPrefs.blocked=[];store.set('radioBlocked',[]);loadRadioTag($('#radioTags .on')?.textContent||RADIO_TAGS[0]);toast('Скрытые станции снова доступны')};
function hideStation(t){if(!RadioPrefs.blocked.includes(t.id))RadioPrefs.blocked.push(t.id);store.set('radioBlocked',RadioPrefs.blocked);if(cur()?.id===t.id)audio.pause();closeSheet();renderRecent();if(view==='radio')loadRadioTag($('#radioTags .on')?.textContent||RADIO_TAGS[0]);if(view==='library')renderLib();toast('Станция скрыта')}
DB.collection('favorites').then(async record=>{if(localStorage.getItem('lumen.favs')!==null)await DB.saveCollection('favorites',S.favs);else if(Array.isArray(record?.items)){S.favs=record.items.filter(isUsableEntry);store.set('favs',S.favs);updateUI();if(view==='library')renderLib()}else await DB.saveCollection('favorites',S.favs)}).catch(()=>toast('БД избранного временно недоступна'));
$('#fullSourceLink').onclick=()=>{if(cur())openTrackInfo(cur())};
const mbPending=new Map();let mbQueue=Promise.resolve(),mbLast=0;
window.__lumenMusicBrainzResult=(id,payload)=>{const p=mbPending.get(id);if(!p)return;mbPending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.connectorError||j.error)throw new Error('MusicBrainz недоступен');p.resolve(j)}catch(e){p.reject(e)}};
function mbUrl(kind,value){
 if(kind==='search')return 'https://musicbrainz.org/ws/2/recording/?fmt=json&limit=5&query='+encodeURIComponent(value);
 if(!/^[0-9a-f-]{36}$/i.test(value))throw new Error('Некорректный MusicBrainz ID');
 if(kind==='recording')return 'https://musicbrainz.org/ws/2/recording/'+value+'?fmt=json&inc=artist-credits+releases+artist-rels+work-rels+genres+annotation';
 if(kind==='artist')return 'https://musicbrainz.org/ws/2/artist/'+value+'?fmt=json&inc=genres+annotation';throw new Error('Некорректный запрос');
}
function mbRequest(kind,value){const job=mbQueue.catch(()=>{}).then(async()=>{const delay=1100-(Date.now()-mbLast);if(delay>0)await new Promise(r=>setTimeout(r,delay));mbLast=Date.now();
 if(window.LumenNative?.musicBrainz)return new Promise((resolve,reject)=>{const id='mb-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{mbPending.delete(id);reject(new Error('MusicBrainz не ответил'))},13000);mbPending.set(id,{resolve,reject,timer});try{LumenNative.musicBrainz(kind,value,id)}catch(e){clearTimeout(timer);mbPending.delete(id);reject(e)}});
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),11000);try{const r=await fetch(mbUrl(kind,value),{signal:controller.signal,headers:{Accept:'application/json'}});if(!r.ok)throw new Error('MusicBrainz HTTP '+r.status);return await r.json()}finally{clearTimeout(timer)}
 });mbQueue=job;return job}
const plainTitle=t=>String(t).replace(/\s*[\[(](?:feat\.?|ft\.?|featuring)\s+.*?[\])]/ig,'').trim();
const credits=r=>(r['artist-credit']||[]).map(c=>c.artist?.name||c.name||'').filter(Boolean).join(', ');
function matchRecordings(j,t){const artist=normalize(t.artist),title=normalize(plainTitle(t.title));const words=artist.split(' ').filter(Boolean);const seen=new Set();return (j.recordings||[]).filter(r=>{const credit=normalize(credits(r));return (Number(r.score)||0)>=90&&normalize(plainTitle(r.title))===title&&words.length&&words.every(w=>credit.split(' ').includes(w))&&!seen.has(r.id)&&seen.add(r.id)})}
function factRow(label,value){return value?`<div class="fact-row"><span>${esc(label)}</span><b>${esc(value)}</b></div>`:''}
function factsHTML(r,artist){const releases=[...(r.releases||[])].filter(x=>x.date).sort((a,b)=>a.date.localeCompare(b.date));const first=releases[0];const annotations=typeof r.annotation==='string'?r.annotation:r.annotation?.text||'';const artistNote=typeof artist?.annotation==='string'?artist.annotation:artist?.annotation?.text||'';const participants=(r.relations||[]).filter(x=>x.artist&&['composer','lyricist','writer','producer','arranger'].includes(x.type)).slice(0,8).map(x=>x.artist.name+' — '+x.type).join('; ');const genres=(r.genres||[]).map(x=>x.name).slice(0,5).join(', ');
 return `<div class="info-label">Запись в MusicBrainz</div><div class="facts">${factRow('Исполнители',credits(r))}${factRow('Ранний релиз в базе',first?.title)}${factRow('Дата этого релиза',first?.date)}${factRow('Длительность записи',r.length?fmt(r.length/1000):'')}${factRow('Жанры',genres)}${factRow('Участники',participants)}${factRow('Уточнение',r.disambiguation)}</div>${annotations?`<h4>О записи</h4><p class="info-story">${esc(annotations.slice(0,2200))}</p>`:''}${artist?`<h4>Об исполнителе · ${esc(artist.name)}</h4><div class="facts">${factRow('Тип',artist.type)}${factRow('Страна',artist.country||artist.area?.name)}${factRow('Даты в базе',[artist['life-span']?.begin,artist['life-span']?.end].filter(Boolean).join(' — '))}${factRow('Жанры',(artist.genres||[]).map(g=>g.name).slice(0,5).join(', '))}</div>${artistNote?`<p class="info-story">${esc(artistNote.slice(0,1800))}</p>`:''}`:''}${!annotations&&!artistNote?'<p class="info-muted">История создания в найденных данных отсутствует. Вымышленные факты не добавляются.</p>':''}<a class="info-reference" href="https://musicbrainz.org/recording/${esc(r.id)}" target="_blank" rel="noopener">Открыть в MusicBrainz</a>`;
}
let infoGeneration=0;const infoCache=new Map();
async function openTrackInfo(t){
 const token=++infoGeneration;openSheet({title:t.title,sub:t.artist,tracks:[],cover:t});$('#sheet').dataset.mode='info';$('#sheetList').onclick=null;
 $('#sheetActions').innerHTML=`<div class="track-actions"><button class="chip" id="infoFav"><svg><use href="#i-heart"/></svg>${isFav(t)?'Сохранено':'В избранное'}</button>${isFullAudio(t)?'<button class="chip" id="infoNext"><svg><use href="#i-queue"/></svg>Следующим</button><button class="chip" id="infoQueue"><svg><use href="#i-plus"/></svg>В очередь</button>':''}${t.type==='radio'?'<button class="chip" id="infoHide">Скрыть станцию</button>':''}${t.type==='album'?'<button class="chip" id="infoAlbum">Открыть альбом</button>':''}</div>`;
 $('#infoFav').onclick=()=>{toggleFav(t);$('#infoFav').lastChild.textContent=isFav(t)?'Сохранено':'В избранное'};
 const enqueue=async next=>{if(!S.queue.length){await playTrack([t],0);toast('Трек запущен');return}const before=S.queue.slice(0,S.idx+1),after=S.queue.slice(S.idx+1).filter(x=>x.id!==t.id);S.queue=next?[...before,t,...after]:[...before,...after,t];toast(next?'Будет играть следующим':'Добавлен в очередь')};if($('#infoNext'))$('#infoNext').onclick=()=>enqueue(true);if($('#infoQueue'))$('#infoQueue').onclick=()=>enqueue(false);if($('#infoHide'))$('#infoHide').onclick=()=>hideStation(t);if($('#infoAlbum'))$('#infoAlbum').onclick=()=>openAlbum(t);
 const live=()=>token===infoGeneration&&$('#sheet').classList.contains('open')&&$('#sheet').dataset.mode==='info';
 const prefix=`<div class="track-summary"><span class="info-label">О треке</span><div class="facts">${factRow('Название',t.title)}${factRow('Исполнитель',t.artist)}${factRow(t.type==='radio'?'Формат':'Длительность файла',t.duration?fmt(t.duration):t.meta||'')}${t.type==='radio'?factRow('Страна',t.country)+factRow('Музыка / теги',t.tags):''}</div></div>`;
 if(t.type==='radio'||t.type==='album'){ $('#sheetList').innerHTML=prefix+(t.type==='radio'?'<p class="info-muted">Фильтр использует название и теги станции. Он не распознаёт содержимое прямого эфира.</p>':'<p class="info-muted">Открой альбом, чтобы увидеть его треки и сохранить релиз целиком.</p>');return;}
 $('#sheetList').innerHTML=prefix+'<div id="infoFacts"><p class="info-muted">Ищем сведения о записи…</p></div>';
 const target=()=>$('#infoFacts');const key=normalize(t.artist)+'|'+normalize(plainTitle(t.title));
 const show=html=>{if(live()&&target())target().innerHTML=html};
 const loadRecord=async record=>{show('<p class="info-muted">Загружаем сведения об этой версии…</p>');try{const full=await mbRequest('recording',record.id);let artist=null;const id=full['artist-credit']?.find(c=>c.artist?.id)?.artist?.id;if(id)try{artist=await mbRequest('artist',id)}catch{}const html=factsHTML(full,artist);infoCache.set(key,html);DB.saveCollection('facts:'+key,{saved:Date.now(),html}).catch(()=>{});show(html)}catch{show('<p class="info-muted">MusicBrainz сейчас недоступен. Попробуй открыть карточку позже.</p>')}};
 if(infoCache.has(key)){show(infoCache.get(key));return}
 try{const old=await DB.collection('facts:'+key);if(old?.items?.html&&Date.now()-old.items.saved<7*86400000){infoCache.set(key,old.items.html);show(old.items.html);return}if(!live())return;
 const quote=s=>'"'+String(s).replace(/[\\"+\-!():^\[\]{}~*?\/]/g,' ').slice(0,200)+'"';const j=await mbRequest('search','recording:'+quote(plainTitle(t.title))+' AND artist:'+quote(t.artist));if(!live())return;const matches=matchRecordings(j,t);
 if(!matches.length){show('<p class="info-muted">Точного совпадения в MusicBrainz нет. Сведения о другой песне вместо этой не показываются.</p>');return}
 if(matches.length===1){await loadRecord(matches[0]);return}
 show('<p class="info-muted">Найдено несколько версий. Выбери нужную запись:</p>'+matches.map((r,i)=>`<button class="recording-choice" data-recording="${i}"><b>${esc(r.title)}</b><span>${esc(r.disambiguation||r.releases?.[0]?.title||'Версия без уточнения')}</span><small>${esc(r.releases?.[0]?.date||'')} · ${r.length?fmt(r.length/1000):'длительность не указана'}</small></button>`).join(''));
 if(target())target().onclick=e=>{const b=e.target.closest('[data-recording]');if(b&&live()){target().onclick=null;loadRecord(matches[Number(b.dataset.recording)])}};
 }catch{show('<p class="info-muted">Сведения временно недоступны. Можно слушать музыку и пользоваться меню без них.</p>')}
}
