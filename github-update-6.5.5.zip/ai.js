'use strict';
/* Lazzy sound 3.0 — AI with the user's own API key.
   On Android the key is encrypted by AndroidKeyStore and requests are made natively (no CORS, key never returns to JS).
   In a plain browser (PWA/testing) the key stays in this browser's localStorage. AI only suggests what to search:
   it never invents playable links — everything it names is looked up in the real sources. */
const AI_DEFAULTS={openai:{model:'gpt-4o-mini',endpoint:'https://api.openai.com/v1'},anthropic:{model:'claude-haiku-5-5',endpoint:''},gemini:{model:'gemini-3.8-flash',endpoint:''}};
let AiConf={provider:'openai',endpoint:'',model:'',...store.get('ai',{})};
if(!AI_DEFAULTS[AiConf.provider])AiConf.provider='openai';
if(/^gemini-(1\.|2\.0|2\.5)/.test(AiConf.model||''))AiConf.model='';
const aiNative=()=>!!window.LumenNative?.aiRequest;
const aiHasKey=()=>{try{return aiNative()?!!LumenNative.hasAiKey():!!localStorage.getItem('lumen.aiKeyWeb')}catch{return false}};
const aiModel=()=>AiConf.model||(AiConf.provider==='gemini'&&store.get('gemModel',{}).m)||AI_DEFAULTS[AiConf.provider].model;
const aiEndpoint=()=>AiConf.provider==='openai'?(AiConf.endpoint||AI_DEFAULTS.openai.endpoint):'';
const aiFreeOn=()=>store.get('aiFree',true)!==false;
const aiReady=()=>aiHasKey()||aiFreeOn();
/* Free mode: Pollinations.ai anonymous tier — no key, about one reply per 30 s per device IP. */
const AiFree={nextAt:0,model:'openai-fast'};
function aiFreeWait(){return Math.max(0,Math.ceil((AiFree.nextAt-Date.now())/1000))}
function aiLimitError(sec){AiFree.nextAt=Date.now()+sec*1000;const e=new Error('Бесплатный ИИ освободится через '+sec+' с. Со своим ключом ограничений нет.');e.rateLimit=sec;return e}
async function aiFreeWeb(system,prompt){
  const c=new AbortController(),timer=setTimeout(()=>c.abort(),30000);
  try{const r=await fetch('https://text.pollinations.ai/openai',{method:'POST',signal:c.signal,credentials:'omit',headers:{'content-type':'application/json'},body:JSON.stringify({model:AiFree.model,temperature:.3,messages:[{role:'system',content:system},{role:'user',content:prompt}]})});
    const raw=await r.text();if(r.status===402||r.status===429){const m=raw.match(/retry after (\d+)/i);throw aiLimitError(m?+m[1]:30)}
    if(!r.ok)throw new Error('Бесплатный ИИ ответил HTTP '+r.status+'.');const j=JSON.parse(raw);return j.choices?.[0]?.message?.content||''}
  catch(e){if(e.name==='AbortError')throw new Error('Бесплатный ИИ слишком долго отвечает.');throw e}finally{clearTimeout(timer)}
}

const aiPending=new Map();
window.__lazzyAi=(id,payload)=>{const p=aiPending.get(id);if(!p)return;aiPending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.error)throw new Error(j.error);p.resolve(String(j.text||''))}catch(e){p.reject(e)}};

async function aiWebRequest(system,prompt){
  const key=localStorage.getItem('lumen.aiKeyWeb')||'';if(!key)throw new Error('Сначала добавь API‑ключ в настройках ИИ.');
  const c=new AbortController(),timer=setTimeout(()=>c.abort(),60000);
  try{let r,j;
    if(AiConf.provider==='anthropic'){r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal:c.signal,headers:{'content-type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01','anthropic-dangerous-direct-browser-access':'true'},body:JSON.stringify({model:aiModel(),max_tokens:1500,system,messages:[{role:'user',content:prompt}]})});j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error?.message||'Провайдер ИИ ответил HTTP '+r.status);return (j.content||[]).filter(x=>x.type==='text').map(x=>x.text).join('')}
    if(AiConf.provider==='gemini'){r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+encodeURIComponent(aiModel())+':generateContent',{method:'POST',signal:c.signal,headers:{'content-type':'application/json','x-goog-api-key':key},body:JSON.stringify({systemInstruction:{parts:[{text:system}]},contents:[{role:'user',parts:[{text:prompt}]}]})});j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error?.message||'Провайдер ИИ ответил HTTP '+r.status);return (j.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('')}
    let url=aiEndpoint().replace(/\/+$/,'');if(!url.endsWith('/chat/completions'))url+='/chat/completions';
    r=await fetch(url,{method:'POST',signal:c.signal,headers:{'content-type':'application/json',authorization:'Bearer '+key},body:JSON.stringify({model:aiModel(),temperature:.8,messages:[{role:'system',content:system},{role:'user',content:prompt}]})});j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error?.message||'Провайдер ИИ ответил HTTP '+r.status);return j.choices?.[0]?.message?.content||''
  }catch(e){if(e.name==='AbortError')throw new Error('ИИ слишком долго отвечает.');throw e}finally{clearTimeout(timer)}
}
function aiAsk(system,prompt){
  if(!aiHasKey()){
    if(!aiFreeOn())return Promise.reject(new Error('ИИ выключен. Включи бесплатный ИИ или добавь ключ: Профиль → ИИ.'));
    const wait=aiFreeWait();if(wait>0)return Promise.reject(aiLimitError(wait));
    AiFree.nextAt=Date.now()+4000;
    const done=p=>p.then(t=>{AiFree.nextAt=Date.now()+30000;return t});
    if(!aiNative())return done(aiFreeWeb(system,prompt));
    return done(new Promise((resolve,reject)=>{const id='ai-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{aiPending.delete(id);reject(new Error('Бесплатный ИИ слишком долго отвечает.'))},40000);
      aiPending.set(id,{resolve,reject:e=>{const m=/^FREE_LIMIT:(\d+)/.exec(e.message||'');reject(m?aiLimitError(+m[1]):e)},timer});
      try{LumenNative.aiRequest('free','',AiFree.model,system,prompt,id)}catch(e){clearTimeout(timer);aiPending.delete(id);reject(e)}}));
  }
  if(!aiNative())return aiWebRequest(system,prompt);
  return new Promise((resolve,reject)=>{const id='ai-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{aiPending.delete(id);reject(new Error('ИИ слишком долго отвечает.'))},70000);aiPending.set(id,{resolve,reject,timer});
    try{LumenNative.aiRequest(AiConf.provider,aiEndpoint(),aiModel(),system,prompt,id)}catch(e){clearTimeout(timer);aiPending.delete(id);reject(e)}});
}
function aiJSON(text){const m=String(text).match(/\{[\s\S]*\}|\[[\s\S]*\]/);if(!m)throw new Error('ИИ ответил не в том формате. Попробуй ещё раз.');try{return JSON.parse(m[0])}catch{throw new Error('ИИ ответил не в том формате. Попробуй ещё раз.')}}
const aiHistory=()=>S.recent.filter(t=>t.type!=='radio').slice(0,8).map(t=>`${t.artist} — ${t.title}`).join('; ');

/* ---------- Settings ---------- */
function aiStatus(text,state=''){const el=$('#aiStatus');el.textContent=text;el.dataset.state=state}
function syncAiSettings(){
  $$('#aiProvider button').forEach(b=>{const on=b.dataset.aiProvider===AiConf.provider;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  const open=AiConf.provider==='openai';$('#aiEndpoint').hidden=$('#aiEndpointLabel').hidden=!open;
  $('#aiEndpoint').value=AiConf.endpoint||'';$('#aiModel').value=AiConf.model||'';$('#aiModel').placeholder=AI_DEFAULTS[AiConf.provider].model;
  $('#aiKey').placeholder=aiHasKey()?'Ключ сохранён — вставь новый, чтобы заменить':'Вставь ключ';
  aiStatus(aiHasKey()?'Свой ключ сохранён. Провайдер: '+{openai:'OpenAI‑совместимый',anthropic:'Claude',gemini:'Gemini'}[AiConf.provider]+', модель '+aiModel()+'. Лимитов приложения нет.':aiFreeOn()?'Работает бесплатный ИИ (Pollinations.ai): без ключа, примерно один ответ в 30 секунд. Свой ключ снимает ограничение.':'ИИ выключен. Поиск всё равно исправляет опечатки по каталогу.',aiHasKey()||aiFreeOn()?'ok':'');
  if($('#aiFreeEnabled'))$('#aiFreeEnabled').checked=aiFreeOn();if($('#aiSearchEnabled'))$('#aiSearchEnabled').checked=store.get('aiSearch',true)!==false;
  $('#aiState').textContent=aiReady()?'Опиши настроение или оставь поле пустым — ИИ отталкнётся от истории':'Включи ИИ в профиле';
}
$$('#aiProvider button').forEach(b=>b.onclick=()=>{AiConf.provider=b.dataset.aiProvider;AiConf.model='';if(AiConf.provider!=='openai')AiConf.endpoint='';store.set('ai',AiConf);syncAiSettings()});
$('#aiSave').onclick=()=>{
  const endpoint=$('#aiEndpoint').value.trim(),model=$('#aiModel').value.trim(),key=$('#aiKey').value.trim();
  if(endpoint){try{const u=new URL(endpoint);if(u.protocol!=='https:'||u.username||u.password||u.search)throw 0}catch{aiStatus('Адрес API должен быть вида https://…, без логина и параметров.','error');return}}
  if(model&&!/^[A-Za-z0-9._:/@-]{1,120}$/.test(model)){aiStatus('Название модели без пробелов, например '+AI_DEFAULTS[AiConf.provider].model+'.','error');return}
  AiConf.endpoint=AiConf.provider==='openai'?endpoint:'';AiConf.model=model;store.set('ai',AiConf);
  if(key){let ok=false;try{ok=aiNative()?!!LumenNative.saveAiKey(key):(localStorage.setItem('lumen.aiKeyWeb',key),true)}catch{}if(!ok){aiStatus('Не удалось сохранить ключ в защищённом хранилище.','error');return}$('#aiKey').value=''}
  if(!aiHasKey()){aiStatus('Настройки сохранены. Осталось вставить API‑ключ.','error');return}
  syncAiSettings();toast('ИИ подключён');
};
if($('#aiSearchEnabled'))$('#aiSearchEnabled').onchange=e=>store.set('aiSearch',e.target.checked);
if($('#aiFreeEnabled'))$('#aiFreeEnabled').onchange=e=>{store.set('aiFree',e.target.checked);syncAiSettings()};
$('#aiRemove').onclick=()=>{try{aiNative()?LumenNative.saveAiKey(''):localStorage.removeItem('lumen.aiKeyWeb')}catch{}syncAiSettings();toast('Ключ удалён')};
$('#aiTest').onclick=async()=>{const b=$('#aiTest');b.disabled=true;aiStatus('Проверяем связь с провайдером…');try{const r=await aiAsk('Ты проверяешь подключение. Ответь одним словом.','Ответь словом «готово».');aiStatus('Работает. Ответ модели: '+r.trim().slice(0,80),'ok')}catch(e){aiStatus(e.message||'ИИ недоступен.','error')}finally{b.disabled=false}};
syncAiSettings();

/* ---------- Search: ideas from a mood description ---------- */
const IDEAS_SYSTEM='Ты музыкальный куратор в приложении-плеере. Отвечай только JSON без пояснений: {"ideas":[{"query":"поисковый запрос","reason":"почему подходит, до 90 символов"}]}. 5 идей. query — короткий запрос для поиска музыки: "Исполнитель Трек", "Исполнитель" или жанр на английском. Предлагай реально существующих исполнителей, разнообразно. reason — по-русски.';
async function runIdeas(){
  const query=$('#q').value.trim();
  if(!aiReady())throw new Error('Добавь API‑ключ: Профиль → ИИ.');
  const hist=aiHistory();
  const prompt=query.length>=2?`Запрос слушателя: «${query.slice(0,300)}».${hist?' Недавно слушал: '+hist+'.':''}`:`Слушатель не описал настроение. Предложи, что послушать дальше.${hist?' Недавно слушал: '+hist+'.':' Истории нет — предложи разнообразное.'}`;
  const j=aiJSON(await aiAsk(IDEAS_SYSTEM,prompt));
  const ideas=(Array.isArray(j)?j:j.ideas||[]).filter(x=>typeof x?.query==='string'&&x.query.trim().length>=2&&x.query.length<=150).slice(0,6).map(x=>({query:x.query.trim(),reason:String(x.reason||'').slice(0,180)}));
  if(!ideas.length)throw new Error('ИИ не предложил вариантов. Попробуй описать иначе.');return ideas;
}
$('#aiAlbums').onclick=async()=>{
  if(!aiReady()){toast('Включи ИИ в настройках');go('profile');if(typeof setProfileTab==='function')setProfileTab('ai');setTimeout(()=>$('#aiSettings').scrollIntoView({behavior:'smooth',block:'start'}),120);return}
  const b=$('#aiAlbums');if(b.classList.contains('busy'))return;b.classList.add('busy');$('#aiState').textContent='Подбираю…';
  try{const ideas=await runIdeas();
    $('#aiSuggestions').innerHTML=ideas.map((x,i)=>`<button class="idea-card stagger" style="--i:${i}" data-idea="${i}"><svg><use href="#i-spark"/></svg><span><b>${esc(x.query)}</b><small>${esc(x.reason||'Найти в источниках')}</small></span><svg class="chev"><use href="#i-chev"/></svg></button>`).join('');
    $$('[data-idea]').forEach(btn=>btn.onclick=()=>{$('#q').value=ideas[Number(btn.dataset.idea)].query;searchFilter='all';doSearch();$('#searchList').scrollIntoView({behavior:'smooth',block:'start'})});
    $('#aiState').textContent='Нажми на идею — найдём полные треки';
  }catch(e){$('#aiState').textContent=e.message||'ИИ недоступен. Обычный поиск работает.'}finally{b.classList.remove('busy')}
};

/* ---------- Player: similar tracks ---------- */
const SIMILAR_SYSTEM='Ты музыкальный куратор. Отвечай только JSON: {"tracks":[{"artist":"...","title":"...","why":"до 70 символов по-русски"}]}. 8 реально существующих треков, похожих по настроению и звучанию, от разных исполнителей. Не повторяй исходный трек.';
$('#aiSimilar').onclick=async()=>{
  const t=cur();if(!t){toast('Сначала включи трек');return}
  if(!aiReady()){toast('Включи ИИ в настройках');return}
  openSheet({title:'Похожее',sub:'ИИ подбирает к «'+t.title+'»',tracks:null,cover:t});$('#sheet').dataset.mode='ai';
  const token=Symbol();$('#aiSimilar').token=token;
  try{const what=t.type==='radio'?`радиостанция «${t.title}», теги: ${t.tags||t.artist}`:`«${t.title}» — ${t.artist}`;
    const j=aiJSON(await aiAsk(SIMILAR_SYSTEM,'Исходный трек: '+what));if($('#aiSimilar').token!==token||$('#sheet').dataset.mode!=='ai')return;
    const list=(Array.isArray(j)?j:j.tracks||[]).filter(x=>x&&typeof x.title==='string'&&typeof x.artist==='string').slice(0,10);
    if(!list.length)throw new Error('ИИ ничего не предложил.');
    $('#sheetSub').textContent='Нажми — найдём полную запись';
    $('#sheetActions').innerHTML='<p class="settings-help">Подборка ИИ. Наличие каждого трека проверяется поиском по подключённым источникам.</p>';
    $('#sheetList').innerHTML=list.map((x,i)=>`<button class="idea-card stagger" style="--i:${i};margin-bottom:8px" data-sim="${i}"><svg><use href="#i-note"/></svg><span><b>${esc(x.title)}</b><small>${esc(x.artist)}${x.why?' — '+esc(String(x.why).slice(0,90)):''}</small></span><svg class="chev"><use href="#i-chev"/></svg></button>`).join('');
    $('#sheetList').onclick=e=>{const b=e.target.closest('[data-sim]');if(!b)return;const x=list[Number(b.dataset.sim)];
      if(typeof chooseFullTrack==='function')chooseFullTrack({id:'ai:'+x.artist+'|'+x.title,type:'catalogTrack',title:x.title,artist:x.artist,duration:0,art:''});};
  }catch(e){if($('#aiSimilar').token===token)$('#sheetList').innerHTML=`<div class="empty"><b>Не получилось</b><span>${esc(e.message||'ИИ недоступен')}</span></div>`}
};

/* ---------- Track sheet: ask AI ---------- */
const baseTrackInfo=openTrackInfo;
openTrackInfo=function(t){
  const r=baseTrackInfo(t);
  if(t&&t.type!=='album'&&aiReady()){const row=$('#sheetActions .track-actions');if(row&&!$('#infoAi')){row.insertAdjacentHTML('beforeend','<button class="chip" id="infoAi"><svg><use href="#i-spark"/></svg>Спросить ИИ</button>');
    $('#infoAi').onclick=async()=>{const b=$('#infoAi');b.disabled=true;const box=document.createElement('div');box.className='ai-box';box.innerHTML='<div class="loader"><i></i><i></i><i></i></div>';$('#sheetList').prepend(box);
      try{const text=await aiAsk('Ты музыкальный эксперт. Отвечай по-русски, 4–6 коротких предложений, без markdown. Если не уверен в фактах о треке или исполнителе — честно скажи, что не знаешь, и опиши только жанр и настроение.',t.type==='radio'?`Расскажи о радиостанции «${t.title}» (${t.tags||t.artist}).`:`Расскажи о треке «${t.title}» исполнителя ${t.artist}: стиль, настроение, чем интересен исполнитель.`);
        box.innerHTML='<p class="ai-text">'+esc(text.trim())+'</p><small>Ответ ИИ — может содержать неточности.</small>'}catch(e){box.innerHTML='<p class="info-muted">'+esc(e.message||'ИИ недоступен')+'</p>'}finally{b.disabled=false}};}}
  return r;
};
/* ---------- 5.3: free API keys (presets) ---------- */
const AI_FREE_KEYS=[
  {id:'gemini',name:'Google Gemini',provider:'gemini',endpoint:'',model:'gemini-3.8-flash',url:'https://aistudio.google.com/apikey',note:'бесплатный тариф, видит картинки'},
  {id:'groq',name:'Groq',provider:'openai',endpoint:'https://api.groq.com/openai/v1',model:'qwen/qwen3.8-27b',url:'https://console.groq.com/keys',note:'бесплатно, очень быстро, видит картинки'},
  {id:'openrouter',name:'OpenRouter',provider:'openai',endpoint:'https://openrouter.ai/api/v1',model:'google/gemma-3-27b-it:free',url:'https://openrouter.ai/keys',note:'бесплатные модели «:free»'},
  {id:'mistral',name:'Mistral',provider:'openai',endpoint:'https://api.mistral.ai/v1',model:'mistral-small-latest',url:'https://console.mistral.ai/api-keys',note:'бесплатный тариф Experiment'},
  {id:'cerebras',name:'Cerebras',provider:'openai',endpoint:'https://api.cerebras.ai/v1',model:'llama-3.3-70b',url:'https://cloud.cerebras.ai',note:'бесплатно, только текст'}
];
(function freeKeyPresets(){
  const row=$('#aiProvider');if(!row||$('#aiFreeKeys'))return;
  const box=document.createElement('div');box.id='aiFreeKeys';
  box.innerHTML=`<p class="field-label">Бесплатный ключ — выбери сервис</p><div class="ai-presets">${AI_FREE_KEYS.map(p=>`<button class="chip glass" data-preset="${p.id}"><b>${p.name}</b><small>${p.note}</small></button>`).join('')}</div><p class="settings-help" id="aiPresetHelp" hidden></p>`;
  row.previousElementSibling?.before(box);
  box.onclick=e=>{const b=e.target.closest('[data-preset]');if(!b)return;const p=AI_FREE_KEYS.find(x=>x.id===b.dataset.preset);
    Object.assign(AiConf,{provider:p.provider,endpoint:p.endpoint,model:p.model,preset:p.id});store.set('ai',AiConf);syncAiSettings();
    $$('#aiFreeKeys [data-preset]').forEach(x=>x.classList.toggle('on',x===b));
    const h=$('#aiPresetHelp');h.hidden=false;h.innerHTML=`1. Открой <a href="${p.url}" target="_blank" rel="noopener">${p.url.replace('https://','')}</a> и войди. 2. Создай API‑ключ. 3. Вставь его в поле «API‑ключ» ниже и нажми «Сохранить». Модель и адрес уже заполнены.`;
    $('#aiKey')?.focus()};
  if(AiConf.preset)box.querySelector(`[data-preset="${AiConf.preset}"]`)?.classList.add('on');
})();
