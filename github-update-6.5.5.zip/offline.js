'use strict';
/* Lazzy sound 4.5 — offline library. Liked tracks and playlist tracks are downloaded to the phone (one at a time,
   Wi-Fi only by default) and played from the file; their lyrics are saved too. */
const Offline={map:store.get('offline',{}),fail:store.get('offlineFail',{}),queue:[],busy:false,pending:new Map(),
  on:store.get('offlineOn',true)!==false,wifi:store.get('offlineWifi',true)!==false};
const offlineNative=()=>!!window.LumenNative?.offlineSave;
const offlineUrl=t=>(window.LAZZY_OFFLINE_BASE||'https://appassets.androidplatform.net/offline/')+encodeURIComponent(t.id)+(window.LAZZY_OFFLINE_Q||'');
const isOffline=t=>!!(t&&Offline.map[t.id]);
window.__lazzyOffline=(id,payload)=>{const p=Offline.pending.get(id);if(!p)return;Offline.pending.delete(id);try{p(JSON.parse(payload))}catch{p({error:'bad'})}};
const offSave=()=>store.set('offline',Offline.map);
function offlineWanted(){
  const out=new Map();const add=t=>{if(t&&isFullAudio(t)&&!['local','radio','album'].includes(t.type)&&(t.type==='soundcloud'||/^https:/.test(t.src||''))&&!(window.isHitmoz?.(t)))out.set(t.id,t)};/* soundcloud links are resolved at download time */
  S.favs.forEach(add);if(typeof Library!=='undefined')Library.playlists.forEach(p=>p.tracks.forEach(add));
  return out;
}
async function saveLyricsOffline(t){
  try{if(await DB.collection('lyrics:'+t.id))return;const r=await findLyrics(t,()=>{},{useAi:false});if(r&&!r.missing)await DB.saveCollection('lyrics:'+t.id,r)}catch{}
}
function offlineSync(){
  if(!offlineNative()||!Offline.on)return;const want=offlineWanted();
  for(const [id,t] of want)if(!Offline.map[id]&&!Offline.queue.some(x=>x.id===id)&&!(Offline.fail[id]&&Date.now()-Offline.fail[id].at<30*60000))Offline.queue.push(t);
  pumpOffline();paintOffline();
}
async function pumpOffline(){
  if(Offline.busy||!Offline.queue.length||!navigator.onLine)return;
  try{if(Offline.wifi&&!Offline.forceCell&&LumenNative.isMetered()){paintOffline('Ждём Wi‑Fi');return}}catch{}
  Offline.busy=true;const t=Offline.queue.shift();paintOffline();
  try{
    if(LumenNative.offlineHas(t.id)){Offline.map[t.id]={size:0,at:Date.now(),title:t.title};offSave()}
    else{
      const save=url=>new Promise(res=>{const rid='off-'+Date.now();const tm=setTimeout(()=>{Offline.pending.delete(rid);res({error:'timeout'})},600000);Offline.pending.set(rid,r=>{clearTimeout(tm);res(r)});try{LumenNative.offlineSave(t.id,url,rid)}catch{Offline.pending.delete(rid);res({error:'bridge'})}});
      const urls=[];if(t.type==='soundcloud'){const u=await scResolve(t).catch(()=>'');if(u)urls.push(u)}else{const r1=typeof resolveStream==='function'?await resolveStream(t.src,4000):'';if(r1)urls.push(r1);if(t.src)urls.push(t.src)}
      let r={error:urls.length?'':'нет ссылки на аудио'};for(const u of [...new Set(urls)]){r=await save(u);if(r.ok)break}
      if(r.ok){Offline.map[t.id]={size:r.size,at:Date.now(),title:t.title};delete Offline.fail[t.id];offSave();markOffline()}
      else{t._offFails=(t._offFails||0)+1;if(t._offFails<3)Offline.queue.push(t);else{Offline.fail[t.id]={title:t.title,artist:t.artist||'',err:r.error||'ошибка',at:Date.now()};store.set('offlineFail',Offline.fail)}}
    }
    saveLyricsOffline(t);
  }finally{Offline.busy=false;paintOffline();setTimeout(pumpOffline,400)}
}
function offlineClear(){for(const id of Object.keys(Offline.map)){try{LumenNative.offlineRemove(id)}catch{}}Offline.map={};Offline.queue=[];offSave();markOffline();paintOffline()}
const fmtMB=b=>(b/1048576).toFixed(b>1e8?0:1).replace('.0','')+' МБ';

/* ---------- UI: Profile → Источники, plus a mark on downloaded rows ---------- */
function paintOffline(note){
  const host=$('#offlineSettings');if(!host)return;const n=Object.keys(Offline.map).length,size=Object.values(Offline.map).reduce((a,x)=>a+(x.size||0),0);
  const status=!offlineNative()?'Работает в установленном приложении.':Offline.busy?`Скачиваем… в очереди ${Offline.queue.length+1}`:note||(Offline.queue.length?`В очереди ${Offline.queue.length}`:'Всё скачано');
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-down"/></svg><h2>Офлайн</h2></div>
    <p class="settings-help">Любимые треки и треки из плейлистов сохраняются на телефон вместе с текстами — играют без интернета.</p>
    <label class="toggle-row"><span><b>Скачивать медиатеку</b><small>Избранное и плейлисты</small></span><input type="checkbox" id="offOn" ${Offline.on?'checked':''}></label>
    <label class="toggle-row"><span><b>Только по Wi‑Fi</b><small>Не тратить мобильный трафик</small></span><input type="checkbox" id="offWifi" ${Offline.wifi?'checked':''}></label>
    <p class="api-status">${n} ${plural(n,'трек','трека','треков').split(' ')[1]} · ${fmtMB(size)} · ${esc(status)}</p>
    ${(()=>{const want=offlineNative()?offlineWanted():new Map(),miss=[...want.keys()].filter(id=>!Offline.map[id]).length,f=Object.entries(Offline.fail).filter(([id])=>want.has(id));
      const hm=[...S.favs,...(typeof Library!=='undefined'?Library.playlists.flatMap(p=>p.tracks):[])].filter(x=>window.isHitmoz?.(x)).map(x=>x.id),nh=new Set(hm).size;
      return `<p class="settings-help">В медиатеке ${want.size} · скачано ${n}${nh?` · Hitmoz: ${nh} — недоступно офлайн`:''}${miss?` · осталось ${miss}`:''}${Offline.wifi&&miss?' · качается только по Wi‑Fi':''}</p>`+(f.length?`<p class="field-label">Не скачались (${f.length})</p><div class="imp-miss">${f.slice(0,30).map(([,x])=>`<p>${esc(x.artist?x.artist+' — ':'')}${esc(x.title)} <small>· ${esc(x.err)}</small></p>`).join('')}</div><button class="chip" id="offRetry">Повторить</button>`:'')})()}
    <div class="api-actions">${offlineNative()?'<button class="chip" id="offNow">Скачать сейчас</button>':''}${n?'<button class="text-link" id="offClear">Удалить скачанное</button>':''}</div>`;
  $('#offOn').onchange=e=>{Offline.on=e.target.checked;store.set('offlineOn',Offline.on);if(Offline.on)offlineSync();else Offline.queue=[];paintOffline()};
  $('#offWifi').onchange=e=>{Offline.wifi=e.target.checked;store.set('offlineWifi',Offline.wifi);pumpOffline();paintOffline()};
  if($('#offRetry'))$('#offRetry').onclick=()=>{Offline.fail={};store.set('offlineFail',{});offlineSync()};
  if($('#offNow'))$('#offNow').onclick=()=>{const w=Offline.wifi;let metered=false;try{metered=LumenNative.isMetered()}catch{}if(w&&metered){Offline.forceCell=true;toast('Качаем по мобильной сети')}offlineSync()};
  if($('#offClear'))$('#offClear').onclick=()=>{if(confirm('Удалить все скачанные треки с телефона?'))offlineClear()};
}
function markOffline(root=document){root.querySelectorAll('.item[data-id],.lib-row[data-id]').forEach(r=>{r.classList.toggle('is-offline',!!Offline.map[r.dataset.id]);r.classList.toggle('no-offline',/^hitmoz:/.test(r.dataset.id||''))})}
for(const id of ['libList','colList','searchList','recentList'])if($('#'+id))new MutationObserver(()=>markOffline($('#'+id))).observe($('#'+id),{childList:true});
paintOffline();
setTimeout(offlineSync,3000);setInterval(offlineSync,60000);
addEventListener('online',pumpOffline);document.addEventListener('visibilitychange',()=>{if(!document.hidden)offlineSync()});
