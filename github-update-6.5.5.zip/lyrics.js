'use strict';
/* Lazzy sound 3.9 — lyrics that move with the song, word by word.
   Finder (stops at the first hit): LRCLIB exact → LRCLIB search by artist+title → LRCLIB search by title →
   lyrics.ovh → AI works out which song it really is (typos, translit, remix/live/cover tags) and the chain runs
   again with its candidates. The AI only identifies the song; the text always comes from a lyrics service.
   Stage: full-screen over the player's background (particles included); synced lines light up and fill in time
   with the track, the view follows the current line, tap a line to jump there. */

/* ---------- Parsing ---------- */
function parseLRC(lrc){
  const out=[];for(const raw of String(lrc||'').split(/\r?\n/)){
    const stamps=[...raw.matchAll(/\[(\d{1,2}):(\d{1,2}(?:[.:]\d{1,3})?)\]/g)];if(!stamps.length)continue;
    const text=raw.replace(/\[[^\]]*\]/g,'').trim();
    for(const m of stamps)out.push({t:(+m[1])*60+parseFloat(m[2].replace(':','.')),text});
  }
  return out.sort((a,b)=>a.t-b.t);
}
const cleanTitle=s=>plainTitle(String(s||''))
  .replace(/\s*[\[(](?:official|lyric|lyrics|audio|video|hd|hq|mv|clip|live|remaster(?:ed)?|\d{4} remaster|radio edit|explicit|prod\.?[^)\]]*)[^)\]]*[\])]/ig,'')
  .replace(/\s+-\s+(?:official|lyric|audio|video|live|remaster).*$/i,'')
  /* uploads: "Title / label", "Title | channel", "Title // promo" — keep only the song name */
  .replace(/\s+(?:\/\/?|\||｜|•)\s+.*$/,'').replace(/\s*#\S+/g,'').replace(/\s{2,}/g,' ').trim();
const cleanArtist=s=>String(s||'').split(/\s*(?:,|&| x | feat\.?| ft\.?|featuring)\s*/i)[0].trim();

/* ---------- Finder ---------- */
const lyrMem=new Map();
const lyrStore={get:id=>(store.get('lyrCache',{})[id])||null,set(id,v){const c=store.get('lyrCache',{});c[id]=v;const keys=Object.keys(c);if(keys.length>40)delete c[keys[0]];try{store.set('lyrCache',c)}catch{}}};
const pack=(j,src)=>{const synced=parseLRC(j.syncedLyrics);const plain=String(j.plainLyrics||j.lyrics||'').replace(/\r/g,'').trim();
  if(j.instrumental)return {instrumental:true,src};if(!synced.length&&!plain)return null;return {synced,plain,src,title:j.trackName||'',artist:j.artistName||'',dur:+j.duration||0}};
async function lrcExact(title,artist,dur){
  if(!artist)return null;const p={track_name:title,artist_name:artist};if(dur>=1&&dur<=3600)p.duration=Math.round(dur);
  let j=await publicCatalog('lyrics',p).catch(()=>null);
  if((!j||j.missing)&&p.duration){delete p.duration;j=await publicCatalog('lyrics',p).catch(()=>null)}
  if(j&&!j.missing&&dur&&j.duration&&Math.abs(dur-j.duration)>25)return null;
  return j&&!j.missing?pack(j,'LRCLIB'):null;
}
/* LRCLIB search by fields: track name + artist (group), then the free-text query */
async function lrcFields(title,artist,dur){if(!artist)return null;const j=await publicCatalog('lyricsSearch',{track_name:title.slice(0,280),artist_name:artist.slice(0,280)}).catch(()=>null);return pickLrc(j?.results||[],title,artist,dur)}
async function lrcSearch(q,title,artist,dur){
  const j=await publicCatalog('lyricsSearch',{q:q.slice(0,280)}).catch(()=>null);return pickLrc(j?.results||[],title,artist,dur)}
function pickLrc(list,title,artist,dur){
  let best=null,bs=0;
  for(const r of list){
    const rt=cleanTitle(r.trackName||r.name||''),ts=Math.max(similarity(normalize(title),normalize(rt)),similarity(normalize(rt),normalize(title))),as=artist?artistSim(artist,r.artistName||''):.8;
    if(ts<.72||as<.5)continue;
    if(dur&&r.duration&&Math.abs(dur-r.duration)>3&&r.syncedLyrics)continue;
    if(dur&&r.duration&&Math.abs(dur-r.duration)>25)continue; /* 6.3.5: a different song with the same name */ /* timings of another edit would drift */
    let sc=ts*.6+as*.4+(r.syncedLyrics?.2:0);
    if(dur&&r.duration)sc-=Math.min(.25,Math.abs(dur-r.duration)/120);
    if(sc>bs){bs=sc;best=r}
  }
  return best?pack(best,'LRCLIB'):null;
}
async function ovh(title,artist){
  if(!artist)return null;const j=await publicCatalog('lyricsOvh',{artist,title}).catch(()=>null);
  return j&&!j.missing&&j.lyrics?pack({plainLyrics:j.lyrics},'lyrics.ovh'):null;
}
async function chain(title,artist,dur,say){
  say('Ищем в LRCLIB…');
  /* prefer a version with timings: a plain-text hit keeps looking for a synced one before settling */
  let plain=null;const ok=r=>{if(!r)return null;if(r.synced?.length>2||r.instrumental)return r;plain=plain||r;return null};
  return ok(await lrcExact(title,artist,dur))
    ||ok(await lrcFields(title,artist,dur))
    ||ok(await lrcSearch(`${artist} ${title}`,title,artist,dur))
    ||(say('Ищем по названию…'),ok(await lrcSearch(title,title,artist,dur)))
    ||plain
    ||(say('Проверяем lyrics.ovh…'),await ovh(title,artist));
}
/* uploads often look like "Artist - Title (slowed + reverb)" posted by someone else */
const TAGS=/\b(slowed|sped ?up|reverb|nightcore|8d|bass ?boosted|remix|cover|edit|version|mashup|instrumental|karaoke|lyrics?|official|audio|video|hd|hq|tiktok|phonk)\b/ig;
function lyrVariants(t){
  const out=[],add=(a,ti)=>{a=cleanArtist(a||'');ti=cleanTitle(ti||'');if(ti&&!out.some(v=>v.title===ti&&v.artist===a))out.push({artist:a,title:ti})};
  const raw=String(t.title||''),bare=raw.replace(/[\[(【][^\])】]*[\])】]/g,' ').replace(TAGS,' ').replace(/[|•~_]+/g,' ').replace(/\s{2,}/g,' ').trim();
  const m=bare.match(/^(.+?)\s+[-–—]\s+(.+)$/);
  if(m){add(m[1],m[2]);add(m[2],m[1])}
  add(t.artist,bare);
  /* Cyrillic names are often stored in Latin on LRCLIB (Кино → Kino) */
  if(typeof translit==='function')for(const v of [...out])if(/[а-яё]/i.test(v.artist+v.title))add(translit(v.artist),translit(v.title)),add(translit(v.artist),v.title);
  add('',bare);
  return out.slice(0,7);
}
/* song identification: the built-in Groq key (no waiting, no user key needed); the user's AI only as fallback */
async function lyrAi(sys,prompt){const groq=()=>aiVisionCall('groq','','qwen/qwen3.8-27b',sys,'/no_think\n'+prompt,'').then(r=>String(r).replace(/<think>[\s\S]*?<\/think>/gi,''));
  const hasGroq=typeof aiVisionCall==='function'&&!!(window.LAZZY_CONFIG||{}).groqKey;
  if(hasGroq){try{return await groq()}catch{}}return aiAsk(sys,prompt)}
async function aiCandidates(t){
  if(!(typeof aiVisionCall==='function'&&(window.LAZZY_CONFIG||{}).groqKey)&&(typeof aiAsk!=='function'||typeof aiReady!=='function'||!aiReady()))return [];
  const sys='Ты помогаешь музыкальному плееру найти текст песни. Отвечай только JSON. Никогда не пиши сам текст песни.';
  const prompt=`В плеере трек: «${t.title}» — ${t.artist||'неизвестный исполнитель'}${t.albumName?' (альбом «'+t.albumName+'»)':''}.
Название может быть с опечатками, транслитом, пометками remix/live/sped up/slowed, это может быть кавер или перезалив.
Определи оригинальную песню. Верни JSON {"candidates":[{"artist":"...","title":"..."}]} — до 3 вариантов, самые вероятные первыми, на языке оригинала.`;
  const j=aiJSON(await lyrAi(sys,prompt));
  return (Array.isArray(j.candidates)?j.candidates:[]).map(c=>({artist:String(c.artist||'').trim(),title:String(c.title||'').trim()})).filter(c=>c.title&&c.title.length<120).slice(0,3);
}
const SPEED_RE=/\b(slowed|sped ?up|speed ?up|nightcore|daycore|ускоренн|замедленн)/i;
const liveDur=t=>t.type==='youtube'?0:t.duration||(cur()?.id===t.id&&isFinite(audio.duration)&&audio.duration>20?audio.duration:0);
const splitArtists=s=>String(s||'').split(/\s*(?:,|&|\+| x | и | feat\.?| ft\.?|featuring|\/)\s*/i).map(x=>x.trim()).filter(Boolean);
function artistSim(a,b){let m=0;for(const x of splitArtists(a))for(const y of splitArtists(b))m=Math.max(m,similarity(normalize(x),normalize(y)));return m}
/* the found lyrics must belong to this song: title AND artist (any of the credited artists, or the "Artist - Title" upload form) */
function lyricsMatch(r,t){
  if(!r||r.missing||r.instrumental||r.viaAi||!r.title)return true;
  const titles=[cleanTitle(t.title),...lyrVariants(t).map(v=>v.title)],artists=[t.artist,...lyrVariants(t).map(v=>v.artist)].filter(Boolean);
  const rt=normalize(cleanTitle(r.title)),ts=Math.max(...titles.map(x=>Math.min(similarity(normalize(x),rt),similarity(rt,normalize(x)))));if(ts<.7)return false;
  if(!artists.length||!r.artist)return true;return Math.max(...artists.map(a=>artistSim(a,r.artist)))>=.5;
}
/* timings from another edit drift: same length ±3 s, or a slowed/sped-up upload whose tempo ratio is applied to the clock */
function fitDuration(r,t){
  if(!r||!(r.synced?.length>2)||!r.dur)return r;const d=liveDur(t);if(!d)return r;
  if(Math.abs(d-r.dur)<=3){delete r.scale;return r}
  const k=d/r.dur;if(SPEED_RE.test(t.title+' '+(t.albumName||''))&&k>.6&&k<1.6){r.scale=+k.toFixed(4);return r}
  return {...r,synced:[],plain:r.plain||r.synced.map(l=>l.text.replace(WORD_TAG,'').trim()).join('\n'),scale:undefined,otherEdit:true};
}
/* 6.1.5: real song name from Deezer / iTunes catalogues (uploads with messy titles, transliteration, typos) */
async function canonCands(t){
  const bare=cleanTitle(String(t.title||'').replace(/[\[(【][^\])】]*[\])】]/g,' ').replace(TAGS,' ')),q=(cleanArtist(t.artist)+' '+bare).trim().slice(0,120);if(q.length<3)return [];
  const words=normalize(q).split(/\s+/).filter(w=>w.length>1);const cover=x=>{const n=normalize(x);return words.length?words.filter(w=>n.includes(w)).length/words.length:0};
  const [dz,it]=await Promise.allSettled([typeof extGet==='function'?extGet('https://api.deezer.com/search?limit=6&q='+encodeURIComponent(q)):Promise.resolve({}),publicCatalog('songs',{q,country:/[а-яё]/i.test(q)?'RU':'US'})]);
  const out=[];const add=(a,ti)=>{a=cleanArtist(a);ti=cleanTitle(ti);if(!a||!ti||cover(a+' '+ti)<.6)return;if(!out.some(o=>normalize(o.artist)===normalize(a)&&normalize(o.title)===normalize(ti)))out.push({artist:a,title:ti})};
  for(const x of dz.value?.data||[])add(x.artist?.name,x.title_short||x.title);
  for(const x of it.value?.results||[])add(x.artistName,x.trackName);
  return out.filter(c=>!(normalize(c.title)===normalize(bare)&&normalize(c.artist)===normalize(cleanArtist(t.artist)))).slice(0,3)}
async function findLyrics(t,say,{useAi=true}={}){
  const good=r=>r&&lyricsMatch(r,t)&&!(r.synced?.length>2&&liveDur(t)&&r.dur&&Math.abs(liveDur(t)-r.dur)>3&&!r.scale)&&!(liveDur(t)&&r.dur&&Math.abs(liveDur(t)-r.dur)>25)&&(r.synced?.length>2||r.instrumental||r.v===2);
  const hit=lyrMem.get(t.id)||lyrStore.get(t.id);if(good(hit))return hit;
  try{const saved=await DB.collection('lyrics:'+t.id);if(saved?.items&&!saved.items.missing&&good(saved.items)){lyrMem.set(t.id,saved.items);return saved.items}}catch{}
  const title=cleanTitle(t.title),artist=cleanArtist(t.artist),dur=SPEED_RE.test(t.title)?0:liveDur(t);
  const ok=r=>r&&lyricsMatch(r,t)?r:null;
  let res=ok(await chain(title,artist,dur,say));
  if(!res)for(const v of lyrVariants(t)){if(v.title===title&&v.artist===artist)continue;res=ok(await chain(v.title,v.artist,dur,say));if(res)break}
  if(!res){say('Сверяем с каталогами…');for(const c of await canonCands(t).catch(()=>[])){res=ok(await chain(c.title,c.artist,dur,say))||await chain(c.title,c.artist,0,say);if(res){if(!lyricsMatch(res,t))res.viaAi=`${c.artist} — ${c.title}`;break}}}
  if(!res&&useAi){
    say('Спрашиваем ИИ, что это за песня…');
    let cands=[];
    for(let k=0;k<2;k++){try{cands=await aiCandidates(t);res=null;break}catch(e){if(e.rateLimit&&k===0&&e.rateLimit<=40){for(let w=e.rateLimit;w>0;w--){say(`ИИ занят, повтор через ${w} с…`);await new Promise(z=>setTimeout(z,1000))}continue}res={aiError:e.message||'ИИ не ответил'};break}}
    for(const c of cands){if(res&&!res.aiError)break;const r=await chain(cleanTitle(c.title),cleanArtist(c.artist),0,say);if(r){r.viaAi=`${c.artist} — ${c.title}`;res=r}}
    if(res&&res.aiError)res={missing:true,aiError:res.aiError};
  }
  if(!res)res={missing:true};
  res=fitDuration(res,t);
  if(!res.missing){res.v=2;lyrMem.set(t.id,res);lyrStore.set(t.id,res);if(typeof isOffline==='function'&&isOffline(t))DB.saveCollection('lyrics:'+t.id,res).catch(()=>{})}
  return res;
}

/* ---------- Stage UI ---------- */
const lyFull=$("#full");
lyFull.insertAdjacentHTML('beforeend',`<div class="lyrics-stage" id="lyricsStage" aria-hidden="true">
  <div class="ly-head"><div class="cover sm" id="lyCover"></div><div class="ly-meta"><b id="lyTitle"></b><span id="lyArtist"></span></div><button class="ibtn glass" id="lyClose" aria-label="Закрыть текст"><svg><use href="#i-down"/></svg></button></div>
  <div class="ly-scroll" id="lyScroll"><div class="ly-lines" id="lyLines"></div></div>
  <div class="ly-foot"><div class="ly-offset"><button class="ibtn" id="lyMinus" aria-label="Текст раньше">−</button><span id="lyOff">+0.00 с</span><button class="ibtn" id="lyPlus" aria-label="Текст позже">+</button></div><p class="ly-src" id="lySrc"></p><button class="ly-env" id="lyEnv" data-st="off"></button><div class="ly-ctrl"><button class="ibtn" id="lyPrev" aria-label="Предыдущий"><svg><use href="#i-prev"/></svg></button><button class="playbig ly-play" id="lyPlay" aria-label="Играть или пауза"><svg><use href="#i-play"/></svg></button><button class="ibtn" id="lyNext" aria-label="Следующий"><svg><use href="#i-next"/></svg></button></div><div class="ly-prog"><i id="lyProg"></i></div></div>
</div>`);
const stage=$('#lyricsStage'),scroller=$('#lyScroll'),linesEl=$('#lyLines');
/* clean modes need synced lines; plain text, messages and loading use the normal layout */
new MutationObserver(()=>stage.classList.toggle('ly-nosync',!Ly.synced)).observe(linesEl,{childList:true});
const Ly={open:false,id:'',lines:[],words:[],align:[],plan:null,wp:-1,wk:-1,synced:false,idx:-1,raf:0,userUntil:0,token:0,lastPlainAt:0};

function paintHead(){const t=cur();if(!t)return;setCover($('#lyCover'),t);$('#lyTitle').textContent=t.title;$('#lyArtist').textContent=t.artist||'';
  $('#lyPlay').innerHTML=`<svg><use href="#i-${audio.paused?'play':'pause'}"/></svg>`}
function setMessage(html){linesEl.innerHTML=`<div class="ly-msg">${html}</div>`;Ly.lines=[];Ly.synced=false;Ly.idx=-1}
function geniusUrl(t){return 'https://genius.com/search?q='+encodeURIComponent(cleanArtist(t.artist)+' '+cleanTitle(t.title))}
async function loadFor(t){
  const token=++Ly.token;Ly.id=t.id;paintHead();$('#lySrc').textContent='';
  if(t.type==='radio'){setMessage('<svg><use href="#i-radio"/></svg><b>Прямой эфир</b><span>У радио нет текста песен.</span>');return}
  setMessage('<span class="ly-spin" aria-hidden="true"><i></i><i></i><i></i></span><b id="lyStatus">Ищем текст…</b>');
  const say=m=>{if(token===Ly.token&&$('#lyStatus'))$('#lyStatus').textContent=m};
  let res;try{res=await findLyrics(t,say)}catch{res={missing:true}}
  if(token!==Ly.token)return;
  if(res.instrumental){setMessage('<svg><use href="#i-note"/></svg><b>Инструментал</b><span>В этом треке нет слов — просто слушай.</span>');return}
  if(res.missing){
    setMessage(`<svg><use href="#i-type"/></svg><b>Текст не нашли</b><span>${res.aiError?esc(res.aiError)+' ':''}Проверили LRCLIB, lyrics.ovh${res.aiError?'':' и спросили ИИ'}.</span>
      <div class="ly-actions"><a class="btn-accent" href="${esc(geniusUrl(t))}" target="_blank" rel="noopener"><svg><use href="#i-external"/></svg>Найти на Genius</a>${res.aiError?'<button class="chip" id="lyRetry">Ещё раз</button>':''}</div>`);
    $('#lyRetry')?.addEventListener('click',()=>loadFor(t));if(typeof asrApply==='function')asrApply(res,t);return;
  }
  if(t.type!=='youtube'&&!liveDur(t)&&(res.synced?.length>2||res.plain))await new Promise(z=>{const f=()=>{audio.removeEventListener('loadedmetadata',f);z()};audio.addEventListener('loadedmetadata',f);setTimeout(f,4000)});
  if(token!==Ly.token)return;
  res=fitDuration(res,t);
  render(estimateSynced(res,t));
}
/* plain lyrics without any timings: spread the lines over the song by syllables (blank lines = breaks), skipping a short
   intro and outro, so the text still follows the track; Whisper replaces this with real timings when it gets the audio */
function estimateSynced(res,t){
  if(res.synced?.length>2||!res.plain)return res;const dur=liveDur(t);if(!dur||dur<40)return res;
  const raw=res.plain.split('\n').map(x=>x.trim());const items=[];let gap=0;
  for(const x of raw){if(!x){gap++;continue}if(/^\[.*\]$/.test(x))continue;items.push({text:x,w:x.split(/\s+/).reduce((a,w)=>a+syllables(w),0)+1.5,gap:gap?3.5:0});gap=0}
  if(items.length<4)return res;
  const start=Math.min(18,dur*.07),end=dur-Math.min(12,dur*.05),total=items.reduce((a,b)=>a+b.w+b.gap,0),k=(end-start)/total;
  let at=start;const synced=items.map(it=>{at+=it.gap*k;const o={t:+at.toFixed(2),text:it.text};at+=it.w*k;return o});
  return {...res,synced,estimated:true};
}
/* ---------- Words: exact when the source has word tags (<mm:ss.xx>), otherwise spread over the line by syllables ---------- */
const WORD_TAG=/<(\d{1,2}):(\d{1,2}(?:\.\d{1,3})?)>/g;
const syllables=w=>Math.max(1,(w.match(/[aeiouyаеёиоуыэюяіїєáéíóúäöüàèìòùâêîôû]/gi)||[]).length);
function lineWords(text,t0,t1){
  const tagged=[...text.matchAll(WORD_TAG)];
  if(tagged.length){
    const out=[];let lastT=t0;const parts=text.split(WORD_TAG);
    // split() with 2 capture groups → [text, mm, ss, text, mm, ss, text…]
    let cur=parts[0];const segs=[{t:t0,text:cur}];
    for(let i=1;i<parts.length;i+=3)segs.push({t:(+parts[i])*60+parseFloat(parts[i+1]),text:parts[i+2]||''});
    segs.forEach((g,k)=>{const end=segs[k+1]?.t??t1;const ws=g.text.split(/\s+/).filter(Boolean);const step=(end-g.t)/Math.max(1,ws.length);
      ws.forEach((w,j)=>out.push({w,s:g.t+j*step,e:g.t+(j+1)*step}))});
    return {words:out.filter(x=>x.w),exact:true};
  }
  const ws=text.split(/\s+/).filter(Boolean);if(!ws.length)return {words:[],exact:false};
  const weight=ws.map(w=>syllables(w)+(/[,.;:!?…—-]$/.test(w)?.6:0)),total=weight.reduce((a,b)=>a+b,0);
  /* sing at a natural pace; spare time before the next line becomes a held last note */
  const avail=Math.max(.5,(t1-t0)*.94),natural=total*.24+.1,pace=Math.max(.5,Math.min(1.1,avail*.8/natural));let t=t0;
  const out=ws.map((w,i)=>{const d=(weight[i]*.3+(i?0:.15))*pace,o={w,s:t,e:t+d};t+=d;return o});
  if(t>t0+avail){const k=avail/(t-t0);out.forEach(o=>{o.s=t0+(o.s-t0)*k;o.e=t0+(o.e-t0)*k})}out[out.length-1].e=t0+avail;
  return {words:out,exact:false};
}
function render(res){
  Ly.est=!!res.estimated;Ly.asr=false;const synced=res.synced&&res.synced.length>2;Ly.synced=synced;Ly.idx=-1;Ly.wk=-1;Ly.words=[];
  let anyExact=false;Ly.wordExact=false;
  if(synced){
    Ly.lines=res.synced.map(l=>({t:l.t,text:l.text}));
    linesEl.innerHTML=Ly.lines.map((l,i)=>{
      const clean=l.text.replace(WORD_TAG,'').trim();
      if(!clean){Ly.words[i]=[];return `<p class="ly-line ly-gap" data-i="${i}"><span class="ly-dots"><i></i><i></i><i></i></span></p>`}
      const t1=Ly.lines[i+1]?.t??(l.t+5),wd=lineWords(l.text,l.t,t1);Ly.words[i]=wd.words;anyExact=anyExact||wd.exact;
      return `<p class="ly-line" data-i="${i}">${wd.words.map((w,k)=>`<span class="w" data-k="${k}" data-t="${esc(w.w)}">${esc(w.w)}</span>`).join(' ')}</p>`;
    }).join('')+'<div class="ly-pad"></div>';
  }else{
    Ly.lines=res.plain.split('\n');
    linesEl.innerHTML=Ly.lines.map(l=>l.trim()?`<p class="ly-line plain">${esc(l)}</p>`:'<p class="ly-break"></p>').join('')+'<div class="ly-pad"></div>';
  }
  Ly.wordExact=anyExact;linesEl.classList.toggle('is-plain',!synced);
  $('#lySrc').textContent=(synced?(res.estimated?'≈ Примерные тайминги по длине трека — подстрой кнопками ± если спешит или отстаёт':anyExact?'По словам — точные тайминги':'Строки по таймингам, слова — по ритму строки')+(res.scale?' · темп ×'+res.scale.toFixed(2):''):res.otherEdit?'Тайминги LRCLIB от другой версии трека — синхронизируем по звуку':'Без таймингов — прокручивается по ходу трека')+' · '+res.src+(res.viaAi?' · ИИ узнал: '+res.viaAi:'');
  scroller.scrollTop=0;Ly.align=[];Ly.plan=null;{const t0=cur();if(t0){loadForms(t0);initSync(t0,res);if(Env.id===t0.id&&Env.data){autoOffset();buildLyrEnv()}else Env.lyr=null}}sync(true);
  if(synced){const t1=cur();if(t1)aiStretch(t1)}
  if(synced){const t=cur();if(t&&t.type!=='radio'){const src=$('#lySrc'),tail=' · '+res.src;if(!Env.data||Env.id!==t.id)src.textContent='Анализируем звук трека…'+tail;
    loadEnvelope(t).then(d=>{if(Ly.open&&cur()?.id===t.id&&!Ly.asr)src.textContent=(d?'Слоги и протяжки — по звуку трека':Env.reason==='hitmoz'?'источник не дал файл — строки по таймингам':'Звук не проанализирован — слова по ритму строки')+tail})}}
}

/* ---------- Sync with the track ---------- */
function findIdx(time){const L=Ly.lines;let lo=0,hi=L.length-1,ans=-1;while(lo<=hi){const m=(lo+hi)>>1;if(L[m].t<=time){ans=m;lo=m+1}else hi=m-1}return ans}
function follow(el,instant){
  if(!el||Date.now()<Ly.userUntil)return;const top=el.offsetTop-scroller.clientHeight*.36+el.offsetHeight/2;
  scroller.scrollTo({top:Math.max(0,top),behavior:instant||reducedLy()?'instant':'smooth'});
}
const lyEstWords=()=>!Ly.wordExact&&!Ly.asr&&!store.get('lyGuessWords',true);
const reducedLy=()=>document.documentElement.dataset.motion==='reduce';
const lyStyle=()=>stage.dataset.lyStyle||'letters';
function syncWords(time,force){
  const Lw=Ly.words[Ly.idx],nx=Ly.lines[Ly.idx+1]?.t;if(Lw&&nx!=null&&!Lw._fit){const lim=nx-.3,t0=Ly.lines[Ly.idx].t,mx=Math.max(...Lw.map(w=>w.s));if(mx>lim){const k=(lim-t0)/Math.max(.01,mx-t0);Lw.forEach(w=>{w.s=t0+(w.s-t0)*k;w.e=Math.min(w.e,lim+.25)})}Lw._fit=1}
  const i=Ly.idx,ws=Ly.words[i];if(!ws||!ws.length)return;const el=linesEl.children[i];if(!el)return;
  let k=-1;for(let j=0;j<ws.length;j++){if(ws[j].s<=time+.1)k=j;else break}
  const spans=el.children;
  if(k!==Ly.wk||force){
    for(let j=0;j<spans.length;j++){const c=spans[j].classList;c.toggle('sung',j<k||(j===k&&time>=ws[j].e));c.toggle('now',j===k&&time<ws[j].e)}
    Ly.wk=k;
  }
  if(lyStyle()==='karaoke'&&k>=0&&spans[k]){const w=ws[k];{let f=Math.max(0,Math.min(1,(time-w.s)/Math.max(.05,w.e-w.s)));if(w.sy){const T=w.sy.t,C=w.sy.c;let q=0;while(q<T.length-1&&f>T[q])q++;const t0=q?T[q-1]:0,c0=q?C[q-1]:0;f=c0+(C[q]-c0)*Math.min(1,(f-t0)/Math.max(.001,T[q]-t0))}spans[k].style.setProperty('--wp',f.toFixed(3))}}
}
/* ---------- Clock: audio time → lyric time ----------
   • currentTime is interpolated between updates (smooth, no 250 ms steps);
   • tempo scale when the lyrics were timed on a version of a different length (LRCLIB duration vs this file);
   • auto offset: the shift that best lines the line starts up with vocal onsets in the analysed audio;
   • manual offset per track (± in the lyrics screen) and output latency (Bluetooth) from settings. */
/* one clock for every source: the <audio> element or the YouTube player */
const mYT=()=>{const y=window.__yt;return y&&y.on&&y.p&&y.p.getDuration?y:null};
function mDur(){const y=mYT();if(y)return y.p.getDuration()||cur()?.duration||0;return isFinite(audio.duration)?audio.duration:0}
function mPos(){const y=mYT();return y?(y.p.getCurrentTime()||0):(audio.currentTime||0)}
function mSeek(s){const y=mYT();if(y)y.p.seekTo(Math.max(0,s),true);else audio.currentTime=Math.max(0,s)}
const Clock={t:0,at:0};
audio.addEventListener('timeupdate',()=>{Clock.t=audio.currentTime;Clock.at=performance.now()});
audio.addEventListener('seeked',()=>{Clock.t=audio.currentTime;Clock.at=performance.now();Clock.out=audio.currentTime});
/* smooth monotonic clock: never steps backwards on coarse currentTime updates (that made karaoke "teleport"),
   converges gently to the real position, snaps only on a real seek/jump (>0.6 s) */
function playTime(){const c=audio.currentTime||0,now=performance.now();
  if(audio.paused||audio.seeking||audio.readyState<3){Clock.out=c;Clock.lc=c;Clock.lcAt=now;return c}
  if(c!==Clock.lc){Clock.lc=c;Clock.lcAt=now}
  /* currentTime itself, extrapolated only between its updates (max 0.3 s, so a stall never runs the lyrics ahead) */
  const est=Clock.lc+Math.min(.3,(now-(Clock.lcAt||now))/1000)*(audio.playbackRate||1);let o=Clock.out??c;
  if(Math.abs(est-o)>.25)o=est;else if(est>o)o+=(est-o)*.5;
  Clock.out=o;return o}
const Sync={scale:1,auto:0,manual:0,id:''};
const latency=()=>+store.get('lyLatency',0)||0;
function lyricTime(){return (playTime()-latency()-Sync.auto-Sync.manual)/Sync.scale}
function audioTimeOf(lt){return lt*Sync.scale+Sync.auto+Sync.manual+latency()}
function initSync(t,res){Sync.id=t.id;Sync.auto=0;Sync.manual=+(store.get('lyOffsets',{})[t.id]||0);Sync.scale=res?.scale>.6&&res.scale<1.6?res.scale:1;
  paintOffset()}
function autoOffset(){return;
  const d=Env.data;if(!d||!Ly.synced||Ly.asr)return;const starts=Ly.lines.filter(l=>l.text&&l.text.replace(WORD_TAG,'').trim()).map(l=>l.t*Sync.scale);if(starts.length<6)return;
  const f=new Float32Array(d.length);for(let i=3;i<d.length;i++)f[i]=Math.max(0,d[i]-d[i-3]);
  const score=off=>{let s=0;for(const t of starts){const c=Math.round((t+off)*100);let m=0;for(let k=c-6;k<=c+6;k++)if(k>0&&k<f.length&&f[k]>m)m=f[k];s+=m}return s};
  const base=score(0);let best=0,bs=base;for(let o=-3;o<=3.001;o+=.02){const sc=score(o);if(sc>bs){bs=sc;best=o}}
  if(Math.abs(best)>=.06&&bs>base*1.15){Sync.auto=+best.toFixed(2);paintOffset()}
}
/* the analysed envelope re-sampled onto the lyrics' clock, so alignment works in lyric time */
function buildLyrEnv(){const d=Env.data;if(!d){Env.lyr=null;return}const n=Math.ceil(d.length/Math.max(.5,Sync.scale))+300,out=new Uint8Array(n);
  for(let k=0;k<n;k++){const a=Math.round(((k/100)*Sync.scale+Sync.auto+Sync.manual)*100);out[k]=a>=0&&a<d.length?d[a]:0}Env.lyr=out}
function paintOffset(){const el=$('#lyOff');if(!el)return;const tot=Sync.manual+Sync.auto;el.textContent=(tot>=0?'+':'')+tot.toFixed(2)+' с'+(Sync.auto?' · авто':'')}
function nudge(dv){Sync.manual=+(Sync.manual+dv).toFixed(2);const all=store.get('lyOffsets',{});if(Sync.manual)all[Sync.id]=Sync.manual;else delete all[Sync.id];store.set('lyOffsets',all);paintOffset();if(Env.data){buildLyrEnv();Ly.align=[];Ly.plan=null;renderAligned()}Ly.gLine=-1;Ly.wk=-2;sync(true)}
function sync(force=false){
  if(!Ly.open)return;
  if(!$('#lyProg').parentElement.classList.contains('drag')){const d=mDur();$('#lyProg').style.transform=`scaleX(${d?Math.min(1,Math.max(0,mPos()/d)).toFixed(4):0})`}
  if(!Ly.lines.length)return;const time=lyricTime();
  if(Ly.synced){
    const i=findIdx(time+.15);
    if(i!==Ly.idx||force){
      const els=linesEl.children;
      if(Ly.idx>=0&&els[Ly.idx]){els[Ly.idx].classList.remove('on');els[Ly.idx].classList.add('past')}
      if(force)[...els].forEach((e,k)=>{e.classList.toggle('past',k<i);e.classList.remove('on')});
      els[Ly.idx]?.classList.remove('echo');
      Ly.idx=i;Ly.wk=-2;if(force)Ly.gLine=-1;const el=els[i];
      if(el){el.classList.add('on');el.classList.remove('past');
        if(lyStyle()==='lines'){const L=Ly.lines,dur=Math.max(.6,((L[i+1]?.t)??(L[i].t+4))-L[i].t);
          el.style.setProperty('--dur',dur+'s');el.style.setProperty('--off',-(time-L[i].t)+'s');el.classList.remove('sweep');void el.offsetWidth;el.classList.add('sweep')}
        follow(el,force)}
    }
    /* without real word timings a per-word guess runs on a steady rhythm, not the voice: light the whole line instead */
    const est=lyEstWords();if(lyStyle()==='letters')syncLetters(est?1e9:time);else if(lyStyle()!=='lines')syncWords(est?1e9:time,force);
  }else if(isFinite(audio.duration)&&audio.duration>0&&Date.now()-Ly.lastPlainAt>700&&Date.now()>=Ly.userUntil&&!Ly.noAuto){
    Ly.lastPlainAt=Date.now();const max=scroller.scrollHeight-scroller.clientHeight;
    const target=Math.max(0,(time/audio.duration)*max*1.04-scroller.clientHeight*.12);
    if(Math.abs(target-scroller.scrollTop)>2)scroller.scrollTo({top:target,behavior:force?'instant':'smooth'});
  }
}
function loop(){Ly.raf=0;if(!Ly.open||audio.paused||document.hidden)return;sync();Ly.raf=requestAnimationFrame(loop)}
const kick=()=>{if(Ly.open&&!Ly.raf&&!audio.paused)Ly.raf=requestAnimationFrame(loop)};
audio.addEventListener('play',()=>{paintHead();kick()});audio.addEventListener('pause',paintHead);
audio.addEventListener('seeked',()=>{Ly.userUntil=0;sync(true)});audio.addEventListener('timeupdate',()=>{if(audio.paused)sync()});
document.addEventListener('visibilitychange',kick);
audio.addEventListener('loadstart',()=>{const t=cur();if(Ly.open&&t&&t.id!==Ly.id)loadFor(t)});

/* user scrolling pauses auto-follow for a moment */
for(const ev of ['touchstart','wheel'])scroller.addEventListener(ev,()=>{Ly.userUntil=Date.now()+3500},{passive:true});
linesEl.addEventListener('click',e=>{const p=e.target.closest('.ly-line[data-i]');if(!p||!Ly.synced)return;const l=Ly.lines[+p.dataset.i];if(l&&isFinite(audio.duration)){audio.currentTime=Math.max(0,audioTimeOf(l.t)-.05);Ly.userUntil=0;if(audio.paused)audio.play().catch(()=>{});sync(true)}});

/* ---------- Open / close ---------- */
function openLyrics(){
  const t=cur();if(!t){toast('Сначала включи трек');return}
  Ly.open=true;lyFull.scrollTop=0;lyFull.classList.add('lyrics-open');stage.setAttribute('aria-hidden','false');$('#lyricsBtn').classList.add('on');
  if(Ly.id!==t.id||!Ly.lines.length)loadFor(t);else{paintHead();sync(true)}
  kick();
}
function closeLyrics(){Ly.open=false;lyFull.classList.remove('lyrics-open');stage.setAttribute('aria-hidden','true');$('#lyricsBtn').classList.remove('on');cancelAnimationFrame(Ly.raf);Ly.raf=0}
$('#lyricsBtn').onclick=()=>Ly.open?closeLyrics():openLyrics();
$('#lyClose').onclick=closeLyrics;
$('#lyMinus').onclick=()=>nudge(-.1);$('#lyPlus').onclick=()=>nudge(.1);$('#lyOff').onclick=()=>{Sync.manual=0;nudge(0)};
$('#lyPlay').onclick=()=>toggle();$('#lyPrev').onclick=()=>prev();$('#lyNext').onclick=()=>next();
new MutationObserver(()=>{if(!lyFull.classList.contains('open')&&Ly.open)closeLyrics()}).observe(lyFull,{attributes:true,attributeFilter:['class']});
const backBefore=window.lazzyBack;window.lazzyBack=()=>{if(Ly.open){closeLyrics();return true}return backBefore?backBefore():false};

/* ---------- Style: Profile → Вид → Текст песен ---------- */
const LY_STYLES={letters:{label:'По буквам',hint:'Буквы заливаются по звуку трека, протяжки тянутся, эхо затухает'},words:{label:'По словам',hint:'Слова загораются, когда их поют'},karaoke:{label:'Караоке',hint:'Каждое слово заливается цветом, текст по центру'},lines:{label:'Строки',hint:'Вся строка заливается целиком — вариант Lazzy'},focus:{label:'Фокус',hint:'Видна только текущая строка, крупно'}};
const LY_SIZES={s:'Мелкий',m:'Средний',l:'Крупный'};
/* ---------- Stretched words: AI (knows how the recording is sung), manual (long-press a word), or by audio ---------- */
const STRETCH_MODES={ai:'ИИ',audio:'По звуку',off:'Выкл'};
const stretchMode=()=>{const m=store.get('lyStretch','ai');return STRETCH_MODES[m]?m:'ai'};
const Forms={id:'',ai:{},manual:{}};
function loadForms(t){Forms.id=t.id;Forms.ai=(store.get('lyAiForms',{})[t.id])||{};Forms.manual=(store.get('lyForms',{})[t.id])||{}}
function stretchForm(i,wi,word){
  const k=i+':'+wi,m=Forms.manual[k];if(m!=null)return m&&m.toLowerCase()!==word.toLowerCase()?m:null;
  if(stretchMode()!=='ai')return null;const a=Forms.ai[k];return a&&a.toLowerCase()!==word.toLowerCase()&&a.length<=word.length+10?a:null;
}
const keepForm=(form,word)=>{/* a form must contain every original letter in order and only add repeats */let j=0;const lo=word.toLowerCase();for(const c of form.toLowerCase())if(j<lo.length&&c===lo[j])j++;return j===lo.length&&/^[\p{L}'’\-,.!?…]+$/u.test(form)};
async function aiStretch(t){
  if(stretchMode()!=='ai'||!Ly.synced||typeof aiAsk!=='function'||typeof aiReady!=='function'||!aiReady())return;
  const cache=store.get('lyAiForms',{});if(cache[t.id])return;
  const lines=Ly.lines.map((l,i)=>l.text?`${i}: ${l.text.replace(WORD_TAG,'').trim()}`:'').filter(Boolean).slice(0,120).join('\n');
  const sys='Ты знаешь, как исполняются песни. Отвечай только JSON.';
  const prompt=`Песня: «${t.title}» — ${t.artist}. Ниже строки текста с номерами.
Отметь слова, которые в оригинальной записи заметно тянутся (протяжные ноты, как «you never wanna loooose»). Только уверенные случаи, не больше 25.
Пиши протяжку повтором главной гласной: lose → loooose, play → plaaay, me → meee. Остальные буквы слова не меняй.
Верни JSON {"stretch":[{"line":номер,"word":"слово как в строке","sung":"протяжная форма"}]}.
${lines}`;
  try{
    const j=aiJSON(await aiAsk(sys,prompt));const out={};
    for(const x of (Array.isArray(j.stretch)?j.stretch:[])){const i=+x.line,L=Ly.lines[i];if(!L||!x.word||!x.sung)continue;
      const words=L.text.replace(WORD_TAG,'').trim().split(/\s+/),wi=words.findIndex(w=>w.toLowerCase().replace(/[^\p{L}']/gu,'')===String(x.word).toLowerCase().replace(/[^\p{L}']/gu,''));
      if(wi<0)continue;const sung=String(x.sung).trim();const word=words[wi];const punct=word.match(/[^\p{L}']+$/u)?.[0]||'';const form=sung.replace(/[^\p{L}']+$/u,'')+punct;
      if(keepForm(form,word))out[i+':'+wi]=form}
    cache[t.id]=out;const keys=Object.keys(cache);if(keys.length>80)delete cache[keys[0]];store.set('lyAiForms',cache);
    if(Forms.id===t.id){Forms.ai=out;Ly.plan=null;renderAligned();if(Ly.open)sync(true)}
    const n=Object.keys(out).length;if(n&&Ly.open)toast('✦︎ ИИ отметил протяжки: '+n);
  }catch(e){if(e?.rateLimit)setTimeout(()=>{if(cur()?.id===t.id)aiStretch(t)},(e.rateLimit+1)*1000)}
}
/* long-press a word in the lyrics to write how it is sung */
(function(){let timer=0,start=null;
  linesEl.addEventListener('pointerdown',e=>{const w=e.target.closest('.ly-line[data-i] .w');if(!w)return;start=[e.clientX,e.clientY];clearTimeout(timer);
    timer=setTimeout(async()=>{const line=+w.closest('.ly-line').dataset.i,wi=+w.dataset.k,word=(Ly.words[line]||[])[wi]?.w;if(!word)return;
      Ly.userUntil=Date.now()+8000;const cur0=stretchForm(line,wi,word)||word;
      const v=await askText('Как поётся «'+word+'» (пусто — как в тексте)',cur0);if(v==null)return;const t=cur();if(!t)return;
      const all=store.get('lyForms',{});const m=all[t.id]||{};const val=v.trim();
      if(!val||val.toLowerCase()===word.toLowerCase())delete m[line+':'+wi];else if(keepForm(val,word))m[line+':'+wi]=val;else{toast('Оставь все буквы слова — можно только добавлять повторы');return}
      all[t.id]=m;store.set('lyForms',all);Forms.manual=m;Ly.plan=null;renderAligned();sync(true);toast('Сохранено для этого трека')},550)},{passive:true});
  const cancel=e=>{if(!start)return;if(e.type==='pointermove'&&Math.hypot(e.clientX-start[0],e.clientY-start[1])<10)return;clearTimeout(timer);start=null};
  for(const ev of ['pointerup','pointercancel','pointermove'])linesEl.addEventListener(ev,cancel,{passive:true});
  linesEl.addEventListener('contextmenu',e=>{if(e.target.closest('.ly-line .w'))e.preventDefault()});
})();
function applyLyStyle(){const st=store.get('lyStyle','letters'),sz=store.get('lySize','m');stage.dataset.lyStyle=LY_STYLES[st]?st:'letters';stage.dataset.lySize=LY_SIZES[sz]?sz:'m';Ly.wk=-2;if(Ly.synced&&Ly.plan)try{renderAligned()}catch{};
  linesEl.querySelectorAll('.sweep').forEach(e=>e.classList.remove('sweep'));if(Ly.open)sync(true)}
function renderLyricsSettings(){
  const host=$('#lyricsSettings');if(!host)return;const st=stage.dataset.lyStyle,sz=stage.dataset.lySize;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-type"/></svg><h2>Текст песен</h2></div>
    <div class="ly-styles" id="lyStyles">${Object.entries(LY_STYLES).map(([k,v])=>`<button data-ly="${k}" class="${k===st?'on':''}"><span class="ly-prev ly-prev-${k}" aria-hidden="true"><i>Под</i> <i>луной</i> <i>горят</i><br><i>огни</i></span><b>${v.label}</b><small>${v.hint}</small></button>`).join('')}</div>
    <p class="field-label">Протяжки слов</p><div class="choice-row" id="lyStretchRow">${Object.entries(STRETCH_MODES).map(([k,v])=>`<button data-lyst="${k}" class="${k===stretchMode()?'on':''}">${v}</button>`).join('')}</div>
    <p class="settings-help">ИИ отмечает протяжные слова по знанию песни. Свой вариант — удерживай слово в тексте и впиши, как оно поётся («loooose»).</p>
    <label class="toggle-row"><span><b>Слова по ритму</b><small>Если у песни нет пословных таймингов, слова загораются по оценке (может не совпадать с голосом). Выкл — строка загорается целиком, точно по времени.</small></span><input type="checkbox" id="lyGuess" ${store.get('lyGuessWords',true)?'checked':''}></label>
    <p class="field-label">Задержка звука</p><div class="choice-row" id="lyLat">${[[0,'Нет'],[.12,'0,12 с'],[.25,'Bluetooth 0,25 с']].map(([v,l])=>`<button data-lat="${v}" class="${+store.get('lyLatency',0)===v?'on':''}">${l}</button>`).join('')}</div>
    <p class="settings-help">Текст сверяется со звуком автоматически (смещение по атакам голоса, разная длина версий). Точная подстройка — кнопки ± на экране текста, запоминается для трека.</p>
    <p class="field-label">Размер</p><div class="choice-row" id="lySizes">${Object.entries(LY_SIZES).map(([k,v])=>`<button data-lys="${k}" class="${k===sz?'on':''}">${v}</button>`).join('')}</div>
    <p class="settings-help">Точно по словам — когда у песни есть пословные тайминги; иначе строки идут точно, а слова распределяются по ритму строки.</p>`;
  $('#lyStyles').onclick=e=>{const b=e.target.closest('[data-ly]');if(!b)return;store.set('lyStyle',b.dataset.ly);applyLyStyle();renderLyricsSettings()};
  $('#lyStretchRow').onclick=e=>{const b=e.target.closest('[data-lyst]');if(!b)return;store.set('lyStretch',b.dataset.lyst);renderLyricsSettings();const t=cur();if(t&&Ly.synced){Ly.plan=null;renderAligned();if(Ly.open)sync(true);aiStretch(t)}};
  $('#lyGuess').onchange=e=>{store.set('lyGuessWords',e.target.checked);Ly.gLine=-1;Ly.wk=-2;if(Ly.open)sync(true)};
  $('#lyLat').onclick=e=>{const b=e.target.closest('[data-lat]');if(!b)return;store.set('lyLatency',+b.dataset.lat);renderLyricsSettings();Ly.gLine=-1;if(Ly.open)sync(true)};
  $('#lySizes').onclick=e=>{const b=e.target.closest('[data-lys]');if(!b)return;store.set('lySize',b.dataset.lys);applyLyStyle();renderLyricsSettings()};
}
applyLyStyle();renderLyricsSettings();

/* ---------- 4.1: letters timed to the audio ----------
   The track's 10 ms loudness envelope (vocal band, decoded natively once and cached) gives syllable onsets inside each
   synced line, which syllables are held (energy stays up with no new onset → the vowel is stretched on screen) and the
   reverb/echo tail after the voice stops (the line keeps glowing and fades with it). It follows what is audible in the
   mix — no vocal separation — so busy instrumentals can pull a syllable early; line starts always stay exact. */
const VOWELS='aeiouyаеёиоуыэюяіїєáéíóúäöüàèìòùâêîôû';
const isVowel=c=>VOWELS.includes(c.toLowerCase());
const SYL_RE=new RegExp(`[^${VOWELS}]*[${VOWELS}]+(?:[^${VOWELS}]*$)?`,'gi');
const syllabify=w=>{const p=w.match(SYL_RE);if(!p)return [w];const j=p.join('');if(j.length<w.length)p[p.length-1]+=w.slice(j.length);
  /* English silent final e ("lose", "time") belongs to the syllable before it */
  if(p.length>1&&/^[a-z]+$/i.test(w)&&/^[^aeiouy]+e[^a-z]*$/i.test(p[p.length-1])&&!/le$/i.test(w))p.splice(-2,2,p[p.length-2]+p[p.length-1]);
  return p};
/* which letter a singer stretches: the main vowel of the syllable — "loooose", "plaaay", "youuu", "niiight" */
function stretchIndex(part,isLastSyl){
  const vow=k=>{const c=part[k];if(!c||!isVowel(c))return false;if(/y/i.test(c)){if(k===0)return false;if(isVowel(part[k+1]||''))return false}return true};
  let end=part.length-1;if(isLastSyl&&/^[a-z]+$/i.test(part)&&/[^aeiouy]e$/i.test(part)&&part.length>2)end=part.length-2;
  let gEnd=-1;for(let k=end;k>=0;k--)if(vow(k)){gEnd=k;break}if(gEnd<0)return -1;
  let gStart=gEnd;while(gStart>0&&vow(gStart-1))gStart--;
  const groupEndsWord=gEnd===part.length-1;
  if(groupEndsWord){for(let k=gEnd;k>=gStart;k--)if(!/y/i.test(part[k]))return k;return gEnd}
  return gStart;
}
const Env={id:'',data:null,pending:new Map()};
window.__lazzyEnv=(id,payload)=>{const p=Env.pending.get(id);if(!p)return;Env.pending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.src){p.resolve({src:j.src});return}if(j.error){p.resolve({error:String(j.error)});return}const bin=atob(j.data),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);p.resolve(a)}catch{p.resolve(null)}};
function envFromBuffer(buf){
  const rate=buf.sampleRate,hop=Math.max(1,Math.round(rate/100)),c0=buf.getChannelData(0),c1=buf.numberOfChannels>1?buf.getChannelData(1):null;
  const dt=1/rate,rcH=1/(2*Math.PI*150),rcL=1/(2*Math.PI*4000),aH=rcH/(rcH+dt),aL=dt/(rcL+dt);
  const out=new Uint8Array(Math.floor(c0.length/hop));let hp=0,px=0,lp=0,acc=0,n=0,k=0;
  for(let i=0;i<c0.length&&k<out.length;i++){const x=c1?(c0[i]+c1[i])/2:c0[i];const h=aH*(hp+x-px);px=x;hp=h;lp+=aL*(h-lp);acc+=lp*lp;
    if(++n>=hop){out[k++]=Math.max(0,Math.min(255,Math.round((20*Math.log10(Math.sqrt(acc/n)+1e-6)+60)*255/60)));acc=0;n=0}}
  return out;
}
function envStatus(st){Env.st=st;const el=$('#lyEnv');if(!el)return;el.dataset.st=st;el.textContent={wait:'Анализ звука…',ok:'Синхронизация по звуку',fail:'Звук не проанализирован · повторить',off:''}[st]||''}
async function decodeToEnv(buf){const C=window.OfflineAudioContext||window.webkitOfflineAudioContext;const ctx=new C(1,1,16000);
  const ab=await new Promise((res,rej)=>{const p=ctx.decodeAudioData(buf,res,rej);if(p&&p.then)p.then(res,rej)});return envFromBuffer(ab)}
const u8b64=a=>{let s='';for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode.apply(null,a.subarray(i,i+8192));return btoa(s)};
const b64u8=b=>{const s=atob(b),a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return a};
const nativeCall=(fn,args,ms)=>new Promise(res=>{const rid='env-'+Date.now()+Math.random().toString(36).slice(2,6);const timer=setTimeout(()=>{Env.pending.delete(rid);res(null)},ms);Env.pending.set(rid,{resolve:res,timer});try{LumenNative[fn](...args,rid)}catch{clearTimeout(timer);Env.pending.delete(rid);res(null)}});
async function decodeUrl(u){const r=await fetch(u,{credentials:'omit'});if(!r.ok)throw new Error('HTTP '+r.status);return decodeToEnv(await r.arrayBuffer())}
/* order: cache → same-origin file (offline / native download) decoded by Web Audio → native MediaCodec → direct fetch */
async function loadEnvelope(t,force=false){
  if(Env.id===t.id&&!force&&(Env.p||Env.data||Date.now()-(Env.failAt||0)<20000))return Env.p||Env.data;
  Env.id=t.id;Env.data=null;Env.lyr=null;const id=t.id;let data=null;let done;Env.p=new Promise(r=>done=r);envStatus('wait');
  const N=window.LumenNative,save=d=>{try{N?.envPut?.(t.id,u8b64(d))}catch{}};
  try{
    if(t.type==='local'){const rec=await DB.get(t.id);if(rec&&rec.blob.size<60e6)data=await decodeToEnv(await rec.blob.arrayBuffer())}
    else{
      try{const c=N?.envCached?.(t.id);if(c)data=b64u8(c)}catch{}
      let url=cur()?.id===t.id&&/^https?:\/\//.test(audio.currentSrc||'')?audio.currentSrc:'';
      if(!url&&typeof isOffline==='function'&&isOffline(t))url=offlineUrl(t);
      if(!url&&/^https:\/\//.test(t.src||''))url=(typeof resolveStream==='function'?await resolveStream(t.src,4000):'')||t.src;
      if(!url&&t.type==='soundcloud'&&typeof scResolve==='function')url=await scResolve(t).catch(()=>'');
      Env.reason='';if(url&&window.isHitmoz?.(t,url)&&window.altSourceUrl){const alt=await altSourceUrl(t).catch(()=>'');if(alt)url=alt}
      if(!data&&url&&new URL(url,location.href).origin===location.origin){try{data=await decodeUrl(url);save(data)}catch{}}
      if(!data&&url&&N?.fetchAudio){const ru=window.hitmozAlt?.(url);let r=null;if(ru){r=await nativeCall('fetchAudio',[ru],120000);if(!r?.src&&N.webFetchAudio)r=await nativeCall('webFetchAudio',[ru],160000)}if(!r?.src)r=await nativeCall('fetchAudio',[url],120000);if(!r?.src&&N.webFetchAudio){const w=await nativeCall('webFetchAudio',[url],160000);if(w?.src)r=w}if(!r?.src&&window.freshTrackUrl){const f=await freshTrackUrl(t,url);if(f)r=await nativeCall('fetchAudio',[f],120000)}if(!r?.src&&window.altSourceUrl){const f=await altSourceUrl(t);if(f)r=await nativeCall('fetchAudio',[f],120000)}if(r?.src){try{data=await decodeUrl(r.src);save(data)}catch{}finally{try{N.envDone?.(r.src.split('/').pop())}catch{}}}}
      if(!data&&url&&N?.analyzeAudio){const r=await nativeCall('analyzeAudio',[url,t.id],150000);if(r instanceof Uint8Array)data=r;else if(r?.src){try{data=await decodeUrl(r.src);save(data)}catch{}finally{try{N.envDone?.(r.src.split('/').pop())}catch{}}}}
      if(!data&&url){try{data=await decodeUrl(url);save(data)}catch{}}
    }
  }catch{data=null}
  if(data&&data.length<100)data=null;
  if(Env.id===id){Env.data=data;Env.p=null;Env.failAt=data?0:Date.now();envStatus(data?'ok':Env.reason==='hitmoz'?'off':'fail');if(!Ly.asr){Ly.align=[];if(data&&Ly.synced){autoOffset();buildLyrEnv();Ly.align=[];Ly.plan=null;renderAligned();if(Ly.open)sync(true)}}}
  done(data);return data;
}
function onsetsIn(a,b){
  const d=Env.lyr,i0=Math.max(3,Math.floor(a*100)),i1=Math.min(d.length-2,Math.ceil(b*100));if(i1-i0<4)return [];
  const f=[];let sum=0,sq=0;for(let i=i0;i<i1;i++){const v=Math.max(0,d[i]-d[i-3]);f.push(v);sum+=v;sq+=v*v}
  const m=sum/f.length,sd=Math.sqrt(Math.max(0,sq/f.length-m*m)),thr=m+.55*sd,out=[];
  for(let j=1;j<f.length-1;j++){const i=i0+j;if(f[j]<thr||d[i]<45)continue;let peak=true;for(let k=Math.max(0,j-6);k<=Math.min(f.length-1,j+6);k++)if(f[k]>f[j]){peak=false;break}if(peak&&(!out.length||i/100-out[out.length-1].t>.09))out.push({t:i/100,v:f[j]})}
  return out;
}
function alignLine(i){
  const L=Ly.lines[i],d=Env.lyr;if(!d||!L)return null;const text=L.text.replace(WORD_TAG,'').trim();if(!text)return null;
  const t0=L.t,t1=Math.min(Ly.lines[i+1]?.t??t0+7,t0+12),words=text.split(/\s+/),syl=[];
  words.forEach((w,wi)=>{let at=0;for(const p of syllabify(w)){syl.push({wi,from:at,to:at+p.length});at+=p.length}});
  const N=syl.length;let pk=onsetsIn(t0-.12,t1-.05);
  let times;
  /* expected moment of every syllable from the line's natural rhythm; an onset is used only near its own syllable,
     so loud drum hits can't pull the whole line into its first half-second */
  const ws0=Ly.words[i]||[],exp=syl.map(sy=>{const w=ws0[sy.wi],ss=syl.filter(x=>x.wi===sy.wi),k=ss.indexOf(sy);if(!w)return t0;return w.s+(w.e-w.s)*k/ss.length});
  times=[];let prevT=-1;const used=new Set();
  exp.forEach((e,j)=>{let best=null,bd=.32;for(const p of pk){if(used.has(p)||p.t<=prevT+.08)continue;const dd=Math.abs(p.t-e);if(dd<bd){bd=dd;best=p}}
    let t=e;if(t<=prevT+.06)t=prevT+.06;times.push(t);prevT=t});
  if(times[0]>t0+.3)times[0]=t0;
  const i0=Math.floor(t0*100),i1=Math.min(d.length-1,Math.floor(t1*100));let mx=0;for(let k=i0;k<i1;k++)mx=Math.max(mx,d[k]);
  let voice=Math.floor(times[N-1]*100),tail=voice;for(let k=voice;k<i1;k++){if(d[k]>=mx-25)voice=k;if(d[k]>=mx-75)tail=k}
  const voiceEnd=Math.max(times[N-1]+.15,voice/100),tailEnd=Math.max(voiceEnd,tail/100);
  /* a note counts as held only with evidence: a real onset, the line clearly sung, and loudness staying up */
  const real=new Set(pk.map(p=>p.t)),reliable=mx>=90&&pk.length>=Math.ceil(N*.5);
  syl.forEach((s,j)=>{s.s=times[j];s.e=j<N-1?times[j+1]:voiceEnd;s.holdFrom=s.s+Math.min(.3,(s.e-s.s)*.4);s.held=false;
    if(reliable&&real.has(s.s)&&s.e-s.s>.5){const a=Math.floor((s.s+.12)*100),b=Math.floor((s.e-.05)*100);let pkv=0,up=0;for(let k=a;k<b;k++)pkv=Math.max(pkv,d[k]);for(let k=a;k<b;k++)if(d[k]>=pkv-22)up++;s.held=b>a&&up/(b-a)>=.7}});
  /* syllables of one word sung apart (a clear dip between attacks) get a generated hyphen: "to‑night" */
  if(reliable)for(let j=1;j<N;j++){const a=syl[j-1],b=syl[j];if(a.wi!==b.wi||b.s-a.s<.35||!real.has(b.s))continue;let lo=255,pv=0;
    for(let k=Math.floor((a.s+.08)*100);k<Math.floor((b.s-.03)*100);k++){lo=Math.min(lo,d[k]);pv=Math.max(pv,d[k])}b.sep=pv-lo>=40}
  const ws=Ly.words[i];if(ws)ws.forEach((w,wi)=>{const ss=syl.filter(s=>s.wi===wi);if(ss.length){w.s=ss[0].s;w.e=ss[ss.length-1].e}});
  return {syl,voiceEnd,tailEnd:Math.min(tailEnd,t1)};
}
/* «По буквам»: everything is pre-generated once the audio is analysed — held vowels are written out ("ooooon") in the
   layout from the start, so nothing reflows while the song plays; only the fill (--wp) and classes change. */
/* Glyph plan: every letter gets the moment it is sung. Held vowels get *generated* extra letters (revealed one by one
   while the note lasts), syllables sung apart get a generated hyphen — they appear in the line as the singer makes them. */
function wordPlan(i){
  const plan=wordPlanRaw(i),L=Ly.lines[i];if(!L||!plan.length)return plan;
  /* every letter must light while its line is on screen: fit the line's glyphs inside [line start, next line − 0.3 s]
     (the line switches 0.15 s early), keep them in order with a minimum spacing */
  const t0=L.t,limit=Math.max(t0+.4,(Ly.lines[i+1]?.t??(t0+8))-.3);
  const all=plan.flatMap(p=>p.g);let mx=-1e9;for(const x of all)mx=Math.max(mx,x.t);
  const k=mx>limit?(limit-t0)/Math.max(.01,mx-t0):1;let prev=t0-1;
  for(const x of all){x.t=t0+Math.max(0,x.t-t0)*k;if(x.t<prev+.012)x.t=prev+.012;prev=x.t}
  plan.forEach(p=>{p.t0=p.g[0]?.t??p.t0;p.t1=p.g[p.g.length-1]?.t??p.t1});
  return plan;
}
function wordPlanRaw(i){
  const ws=Ly.words[i]||[],A=Ly.align[i]||null;
  return ws.map((w,wi)=>{
    const g=[],ss=A?A.syl.filter(s=>s.wi===wi):[];
    const spread=(txt,t0,t1)=>{const n=txt.length;for(let k=0;k<n;k++)g.push({c:txt[k],t:t0+(t1-t0)*(k/Math.max(1,n))})};
    const form=stretchForm(i,wi,w.w);
    if(form){
      /* AI / manual sung form: original letters keep their order, the rest are generated letters timed over the hold */
      const nextW=ws[wi+1],lineEnd=(Ly.lines[i+1]?.t??(w.e+3))-.15,s0=ss.length?ss[0].s:w.s;
      const holdEnd=Math.max(s0+.5,Math.min(nextW?nextW.s-.05:Math.min(lineEnd,(A?A.voiceEnd:w.e)+1.2),s0+4));
      const holdStart=s0+Math.min(.28,(holdEnd-s0)*.3);
      const marks=[];let j=0;const lo=w.w.toLowerCase();for(const c of form){if(j<lo.length&&c.toLowerCase()===lo[j]){marks.push({c,x:0});j++}else marks.push({c,x:1})}
      const firstX=marks.findIndex(m=>m.x),lastX=marks.length-1-[...marks].reverse().findIndex(m=>m.x),nx=marks.filter(m=>m.x).length;
      let xi=0;marks.forEach((m,k)=>{let t;
        if(k<firstX)t=s0+(holdStart-s0)*(k/Math.max(1,firstX));
        else if(m.x){xi++;t=holdStart+(holdEnd-.12-holdStart)*xi/(nx+1)}
        else if(k<lastX)t=holdStart+(holdEnd-.12-holdStart)*(xi+.5)/(nx+1);
        else t=holdEnd-.12+(k-lastX)*.04;
        g.push({c:m.c,t,x:m.x})});
      return {g,t0:g[0].t,t1:g[g.length-1].t};
    }
    if(!ss.length)spread(w.w,w.s,Math.min(w.e,w.s+Math.max(.25,w.w.length*.07)));
    for(const sy of ss){
      const part=w.w.slice(sy.from,sy.to);
      if(sy.sep)g.push({c:'‑',t:sy.s-.02,x:1,sep:1});
      const v=sy.held&&stretchMode()==='audio'?stretchIndex(part,sy.to===w.w.length):-1;
      if(sy.held&&v>=0){
        spread(part.slice(0,v+1),sy.s,sy.holdFrom);
        const n=Math.max(2,Math.min(7,Math.round((sy.e-sy.holdFrom)/.16))),ch=part[v].toLowerCase();
        for(let k=1;k<=n;k++)g.push({c:ch,t:sy.holdFrom+(sy.e-sy.holdFrom)*k/(n+1),x:1});
        spread(part.slice(v+1),sy.e-.08,sy.e);
      }else spread(part,sy.s,Math.min(sy.e,sy.s+Math.max(.18,part.length*.08)));
    }
    return {g,t0:g.length?g[0].t:w.s,t1:g.length?g[g.length-1].t:w.e};
  });
}
function renderAligned(){
  if(!Ly.synced)return;const els=linesEl.children,cur0=els[Ly.idx],before=cur0?cur0.offsetTop-scroller.scrollTop:null;
  Ly.plan=[];
  for(let i=0;i<Ly.lines.length;i++){
    if(!Ly.words[i]||!Ly.words[i].length){Ly.plan[i]=null;continue}
    if(Env.lyr&&Ly.align[i]===undefined)Ly.align[i]=alignLine(i)||false;
    const plan=wordPlan(i);Ly.plan[i]=plan;
    const el=els[i];if(!el)continue;const glyphs=lyStyle()==='letters';
    const sig=(glyphs?'g:':'w:')+plan.map(p=>p.g.map(x=>(x.x?'+':'')+x.c).join('')).join(' ');
    if(el.dataset.sig!==sig){el.dataset.sig=sig;el.style.minHeight='';
      el.innerHTML=glyphs?plan.map((p,k)=>`<span class="w" data-k="${k}">${p.g.map(x=>`<i class="g${x.x?' x':''}${x.sep?' sep':''}">${esc(x.c)}</i>`).join('')}</span>`).join(' ')
        :Ly.words[i].map((w,k)=>`<span class="w" data-k="${k}" data-t="${esc(w.w)}">${esc(w.w)}</span>`).join(' ');
      if(i===Ly.idx)Ly.wk=-2}
    plan.glyphs=null;
  }
  const cur1=els[Ly.idx];if(cur1&&before!=null)scroller.scrollTop=cur1.offsetTop-before;
  Ly.wk=-2;Ly.gi=-1;Ly.gLine=-1;
}
/* reserve the height the line will have once every generated letter is in, so nothing below it moves */
function reserve(el){el.classList.add('measure');const h=el.offsetHeight;el.classList.remove('measure');el.style.minHeight=h+'px'}
function glyphsOf(i){const plan=Ly.plan[i],el=linesEl.children[i];if(!plan||!el)return null;if(!plan.glyphs){const nodes=el.querySelectorAll('i.g'),list=[];let n=0;plan.forEach(p=>p.g.forEach(x=>list.push({el:nodes[n++],t:x.t})));plan.glyphs=list}return plan.glyphs}
function syncLetters(time){
  const i=Ly.idx,el=linesEl.children[i];if(!el)return;if(!Ly.plan)renderAligned();const plan=Ly.plan[i];if(!plan)return;
  const G=glyphsOf(i);if(!G)return;
  if(Ly.gLine!==i){
    /* entering a line (or seeking): settle every line — past fully generated, future clean */
    const els=linesEl.children;
    for(let k=0;k<els.length;k++){if(k===i)continue;const gs=els[k].querySelectorAll('i.g');const on=k<i;for(const g of gs)g.classList.toggle('lit',on);els[k].classList.toggle('gen',on)}
    for(const g of G)g.el.classList.remove('lit');reserve(el);el.classList.add('gen');Ly.gLine=i;Ly.gi=-1;
  }
  while(Ly.gi+1<G.length&&G[Ly.gi+1].t<=time+.02){Ly.gi++;G[Ly.gi].el?.classList.add('lit')}
  if(Ly.gi>=0&&G[Ly.gi].t>time+.3){for(const g of G)g.el?.classList.toggle('lit',g.t<=time+.02);Ly.gi=G.filter(g=>g.t<=time+.02).length-1}
  const A=Ly.align[i];const echo=!!A&&time>=A.voiceEnd&&time<A.tailEnd&&A.tailEnd-A.voiceEnd>.2;
  if(echo!==el.classList.contains('echo')){if(echo)el.style.setProperty('--tail',(A.tailEnd-A.voiceEnd).toFixed(2)+'s');el.classList.toggle('echo',echo)}
}

$('#lyEnv').onclick=()=>{const t=cur();if(t&&Env.st==='fail')loadEnvelope(t,true)};
