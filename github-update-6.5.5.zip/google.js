'use strict';
/* Lazzy sound 3.2 — Google account instead of a database.
   Sign-in: OAuth 2.0 for installed apps in the system browser (PKCE + loopback), done natively in MainActivity.
   Sync: favourites, playlists and followed artists live in ONE json file in the user's own Google Drive,
   in the hidden app folder (scope drive.appdata) — the app has no server and no database of its own. */
const GCFG=window.LAZZY_CONFIG||{};
const Google={profile:null,syncing:false,timer:0,lastSync:store.get('gLastSync',0),pending:new Map()};
const gNative=()=>!!window.LumenNative?.googleSignIn;
function gClient(){const c=store.get('googleClient',{});return {id:(c.id||GCFG.googleClientId||'').trim(),secret:(c.secret||GCFG.googleClientSecret||'').trim()}}
window.__lazzyGoogle=(id,payload)=>{const p=Google.pending.get(id);if(!p)return;Google.pending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.error)throw new Error(j.error);p.resolve(j)}catch(e){p.reject(e)}};
function gCall(id,fn,ms){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{Google.pending.delete(id);reject(new Error('Google не ответил'))},ms);Google.pending.set(id,{resolve,reject,timer});try{fn()}catch(e){clearTimeout(timer);Google.pending.delete(id);reject(e)}})}
async function googleAccessToken(){if(!gNative())throw new Error('Вход через Google работает в приложении');const id='tok-'+Date.now()+'-'+Math.random().toString(36).slice(2);const j=await gCall(id,()=>LumenNative.googleToken(id),20000);return j.accessToken}
function loadProfile(){try{const raw=gNative()?LumenNative.googleProfile():'';Google.profile=raw?JSON.parse(raw):null}catch{Google.profile=null}}

/* ---------- Drive appData file ---------- */
const FILE='lazzy-library.json';
async function drive(path,{method='GET',body,headers={},raw=false}={}){
  const token=await googleAccessToken();
  const r=await fetch('https://www.googleapis.com'+path,{method,body,headers:{Authorization:'Bearer '+token,...headers},credentials:'omit'});
  if(r.status===401)throw new Error('Сессия Google истекла — войди снова');
  if(r.status===403)throw new Error('Нет доступа к Google Диску. Проверь, что в проекте включён Google Drive API.');
  if(!r.ok)throw new Error('Google Диск ответил HTTP '+r.status);
  return raw?r.text():r.status===204?null:r.json();
}
async function driveFind(){const q=encodeURIComponent(`name='${FILE}'`);const j=await drive(`/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id,modifiedTime)&pageSize=5`);return j.files?.[0]||null}
async function driveRead(id){const t=await drive(`/drive/v3/files/${id}?alt=media`,{raw:true});try{return JSON.parse(t)}catch{return null}}
async function driveWrite(id,data){
  const json=JSON.stringify(data);
  if(id)return drive(`/upload/drive/v3/files/${id}?uploadType=media`,{method:'PATCH',body:json,headers:{'Content-Type':'application/json'}});
  const boundary='lazzy'+Date.now();const body=`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify({name:FILE,parents:['appDataFolder']})}\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${json}\r\n--${boundary}--`;
  return drive('/upload/drive/v3/files?uploadType=multipart',{method:'POST',body,headers:{'Content-Type':'multipart/related; boundary='+boundary}});
}

/* ---------- Merge: union with tombstones, newest edit wins ---------- */
const syncable=t=>t&&t.type!=='local'&&isUsableEntry(t);
function snapshot(){return {v:1,updatedAt:Date.now(),favs:S.favs.filter(syncable),playlists:(Library.playlists||[]).map(p=>({...p,tracks:p.tracks.filter(syncable)})),follows:Library.follows||[],tomb:store.get('tomb',{})}}
function mergeById(local,remote,tomb,stamp=x=>0){
  const out=new Map();for(const x of remote||[])if(x?.id)out.set(x.id,x);
  for(const x of local||[]){if(!x?.id)continue;const r=out.get(x.id);if(!r||stamp(x)>=stamp(r))out.set(x.id,x)}
  for(const [id,at] of Object.entries(tomb))if(out.has(id)&&stamp(out.get(id))<at)out.delete(id);
  return [...out.values()];
}
async function googleSync(){
  if(Google.syncing||!Google.profile||!gNative())return;Google.syncing=true;gStatus('Синхронизируем с Google Диском…');
  try{
    const file=await driveFind();const remote=file?await driveRead(file.id):null;
    const tomb={...(remote?.tomb||{}),...store.get('tomb',{})};
    const locals=S.favs.filter(t=>t.type==='local');
    S.favs=[...mergeById(S.favs.filter(syncable),remote?.favs,tomb,x=>x.savedAt||0),...locals];
    Library.playlists=mergeById(Library.playlists,remote?.playlists,tomb,x=>x.updatedAt||0);
    Library.follows=mergeById(Library.follows,remote?.follows,tomb,x=>x.followedAt||0);
    const cutoff=Date.now()-90*86400000;for(const k of Object.keys(tomb))if(tomb[k]<cutoff)delete tomb[k];store.set('tomb',tomb);
    store.set('favs',S.favs);DB.saveCollection('favorites',S.favs).catch(()=>{});Library.save(false);
    await driveWrite(file?.id,snapshot());
    Google.lastSync=Date.now();store.set('gLastSync',Google.lastSync);
    updateUI();if(view==='library')renderLib();if(typeof refreshProfile==='function')refreshProfile();
    gStatus('Синхронизировано: '+new Date(Google.lastSync).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}),'ok');
  }catch(e){gStatus(e.message||'Синхронизация не удалась','error')}finally{Google.syncing=false}
}
function scheduleSync(){if(!Google.profile)return;clearTimeout(Google.timer);Google.timer=setTimeout(googleSync,2500)}
window.LazzySync={schedule:scheduleSync,tombstone(id){const t=store.get('tomb',{});t[id]=Date.now();store.set('tomb',t);scheduleSync()}};
/* app.js calls this on every like/unlike */
window.cloudFavoriteChanged=(t,enabled)=>{if(enabled){const f=S.favs.find(x=>x.id===t.id);if(f)f.savedAt=Date.now()}else LazzySync.tombstone(t.id);scheduleSync()};

/* ---------- UI ---------- */
function gStatus(text,state=''){const el=$('#gStatus');if(el){el.textContent=text;el.dataset.state=state}}
const G_LOGO='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5a5.6 5.6 0 0 1-2.4 3.6v3h3.9c2.2-2.1 3.5-5.1 3.5-8.8z"/><path fill="#34A853" d="M12 24c3.2 0 6-1.1 8-2.9l-3.9-3c-1.1.7-2.5 1.2-4.1 1.2-3.1 0-5.8-2.1-6.7-5H1.3v3.1A12 12 0 0 0 12 24z"/><path fill="#FBBC05" d="M5.3 14.3a7.2 7.2 0 0 1 0-4.6V6.6h-4a12 12 0 0 0 0 10.8z"/><path fill="#EA4335" d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4A12 12 0 0 0 1.3 6.6l4 3.1c.9-2.9 3.6-4.9 6.7-4.9z"/></svg>';
function renderAccount(){
  const el=$('#profile-account');if(!el)return;const p=Google.profile;
  el.innerHTML=p&&store.get('fbRefresh','')?`<div class="glass settings-group"><div class="setting-title"><svg><use href="#i-cloud"/></svg><h2>Синхронизация</h2></div><p class="settings-help">Любимое и плейлисты синхронизируются через скрытую папку приложения на Google Диске ${esc(p.email||'')}.</p><p class="api-status" id="gStatus" role="status">${Google.lastSync?'Последняя синхронизация: '+new Date(Google.lastSync).toLocaleString('ru-RU'):'Ещё не синхронизировано'}</p><div class="api-actions"><button class="chip" id="gSync">Синхронизировать</button></div></div>`:'';
  if($('#gSync'))$('#gSync').onclick=googleSync;
}
async function signIn(){
  if(!gNative()){gStatus('Вход через Google доступен в приложении','error');return}
  const c=gClient(),b=$('#gIn')||{};b.disabled=true;gStatus('Открываем Google в браузере… Вернись сюда после входа.');
  try{const j=await gCall('signin',()=>LumenNative.googleSignIn(c.id,c.secret),250000);Google.profile=j.profile;applyGoogleProfile();renderAccount();toast('Привет, '+(j.profile.name||'слушатель')+'!');googleSync();window.onGoogleSignedIn?.()}
  catch(e){gStatus(e.message||'Вход не удался','error');b.disabled=false}
}
function applyGoogleProfile(){
  const p=Google.profile;document.body.classList.toggle('g-signed',!!p);
  const badge=$('.profile-badge');if(badge)badge.textContent=p?'Google':'Локально';
  const sub=$('.profile-card p');if(sub)sub.textContent=p?p.email:'Профиль на этом устройстве';
  for(const sel of ['.profile-avatar','.profile-shortcut']){const el=$(sel);if(!el)continue;let img=el.querySelector('img.g-pic');if(p?.picture){if(!img){img=document.createElement('img');img.className='g-pic';img.alt='';img.referrerPolicy='no-referrer';el.appendChild(img)}img.src=p.picture}else img?.remove()}
  if(p&&!Prefs.name.trim()){$('#profileDisplayName').textContent=p.name||'Слушатель'}
}
loadProfile();applyGoogleProfile();renderAccount();
if(Google.profile)setTimeout(googleSync,1500);
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&Google.profile&&Date.now()-Google.lastSync>10*60000)googleSync()});
