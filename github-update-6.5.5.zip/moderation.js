'use strict';
/* Lazzy sound 5.1 — profile moderation: local word filter (names/handles/bio, any script, leetspeak) + AI vision check
   of avatars/banners (all frames of animated images are sampled) and texts in one free request. */
const MOD_TR={а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ё:'e',ж:'zh',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'c',ч:'ch',ш:'sh',щ:'sch',ъ:'',ы:'y',ь:'',э:'e',ю:'yu',я:'ya',і:'i',ї:'i',є:'e'};
const MOD_LEET={'0':'o','1':'i','!':'i','|':'i','3':'e','4':'a','@':'a','5':'s','$':'s','7':'t','8':'b','9':'g'};
const MOD_BAD=['fuck','fuk','cunt','nigg','fagg','faggot','whore','slut','bitch','porn','rape','pedo','pedofil','pedophil','hitler','heil','nazi','kkk','isis','swastik','siegheil','1488',
  'huy','huj','huev','huil','huesos','pizd','pisd','ebat','eban','ebal','eblan','ebuch','blyad','blyat','blya','suka','suchk','mudak','mudil','pidor','pidar','pidr','gandon','zalup','dolboeb','shlyuh','shluh','gnida','churk','zhid','negr'];
const MOD_STAFF=['admin','moder','support','official','lazzy','staff','system'];
/* the Lazzy team: only these accounts may use staff words in the @handle (also enforced by firestore.rules) */
const MOD_ADMINS=['mastermya@mail.ru','titer5249@gmail.com'];
const isStaffUser=()=>{const e=String((typeof Soc!=='undefined'&&Soc.email)||store.get('fbEmail','')||(typeof Google!=='undefined'&&Google.profile?.email)||'').trim().toLowerCase();return MOD_ADMINS.includes(e)};
function modNorm(s){
  let o='';for(const ch of String(s||'').toLowerCase().normalize('NFC'))o+=MOD_TR[ch]??MOD_LEET[ch]??ch;
  o=o.normalize('NFKD').replace(/[\u0300-\u036f]/g,'');
  return {plain:o.replace(/[^a-z0-9]/g,''),squeezed:o.replace(/[^a-z]/g,'').replace(/(.)\1+/g,'$1').replace(/x/g,'h')};
}
function modTextLocal(fields,{handle=''}={}){
  for(const [k,v] of Object.entries(fields)){const n=modNorm(v);
    for(const w of MOD_BAD){const ww=w.replace(/(.)\1+/g,'$1');if(n.plain.includes(w)||(ww.length>3&&n.squeezed.includes(ww)))return k==='bio'?'В описании есть запрещённые слова':'Недопустимое '+(k==='handle'?'имя пользователя':'имя')}}
  const h=modNorm(handle).plain;if(h&&!isStaffUser()&&MOD_STAFF.some(w=>h.includes(w)))return 'Слова admin, moder, support, official, lazzy, staff, system в нике доступны только команде Lazzy';
  if(/(\+?\d[\s()-]*){9,}/.test(Object.values(fields).join(' ')))return 'Не публикуй номера телефонов';
  return '';
}
/* ---------- images ---------- */
async function modFrames(file,max=4){
  if('ImageDecoder' in window&&/gif|webp|png|avif/.test(file.type)){
    try{const dec=new ImageDecoder({data:await file.arrayBuffer(),type:file.type});await dec.tracks.ready;const n=dec.tracks.selectedTrack?.frameCount||1;
      const idx=[...new Set(Array.from({length:Math.min(max,n)},(_,i)=>Math.floor(i*(n-1)/Math.max(1,Math.min(max,n)-1))))];
      const frames=[];for(const i of idx)frames.push((await dec.decode({frameIndex:i})).image);return {frames,count:n}}catch{}
  }
  const url=URL.createObjectURL(file);const img=new Image();img.src=url;await img.decode();return {frames:[img],count:/gif/.test(file.type)?2:1};
}
const modSize=s=>[s.displayWidth||s.naturalWidth||s.width,s.displayHeight||s.naturalHeight||s.height];
function modCover(src,w,h,type='image/webp',q=.84){const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');const [sw,sh]=modSize(src),k=Math.max(w/sw,h/sh);x.drawImage(src,(w-sw*k)/2,(h-sh*k)/2,sw*k,sh*k);let d=c.toDataURL(type,q);if(!d.startsWith('data:'+type))d=c.toDataURL('image/jpeg',q);return d}
function modSheet(frames){
  const n=Math.min(8,frames.length),cols=Math.min(4,n),rows=Math.ceil(n/cols),S=256,c=document.createElement('canvas');c.width=cols*S;c.height=rows*S;const x=c.getContext('2d');x.fillStyle='#808080';x.fillRect(0,0,c.width,c.height);
  frames.slice(0,n).forEach((f,i)=>{const [w,h]=modSize(f),k=Math.min(S/w,S/h);x.drawImage(f,(i%cols)*S+(S-w*k)/2,Math.floor(i/cols)*S+(S-h*k)/2,w*k,h*k)});
  return c.toDataURL('image/jpeg',.72);
}
const fileDataUrl=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)});
/* ---------- animated media: GIF/WebP/APNG kept as is when small; bigger ones and videos are re-encoded to a short WebM/MP4 loop ---------- */
const MEDIA_BOX={avatar:{w:400,h:400,aw:320,ah:320,limit:400e3,bps:[260e3,150e3]},banner:{w:1200,h:400,aw:960,ah:320,limit:600e3,bps:[480e3,260e3]}};
const isVideoSrc=src=>/^data:video\//.test(src||'');
function mediaTag(src,alt=''){return isVideoSrc(src)?`<video src="${esc(src)}" autoplay muted loop playsinline disablepictureinpicture></video>`:`<img src="${esc(src)}" alt="${esc(alt)}" referrerpolicy="no-referrer">`}
function drawCoverTo(x,src,w,h){const [sw,sh]=src.videoWidth?[src.videoWidth,src.videoHeight]:modSize(src);if(!sw||!sh)return;const k=Math.max(w/sw,h/sh);x.drawImage(src,(w-sw*k)/2,(h-sh*k)/2,sw*k,sh*k)}
function snapCanvas(src,w=256,h=256){const c=document.createElement('canvas');c.width=w;c.height=h;drawCoverTo(c.getContext('2d'),src,w,h);return c}
function recMime(){if(!window.MediaRecorder||!HTMLCanvasElement.prototype.captureStream)return '';return ['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm','video/mp4;codecs=avc1','video/mp4'].find(m=>{try{return MediaRecorder.isTypeSupported(m)}catch{return false}})||''}
async function recordLoop(w,h,dur,bps,draw,onSnap){
  const mime=recMime();if(!mime)throw new Error('Это устройство не умеет сжимать анимацию — выбери файл поменьше');
  const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#000';x.fillRect(0,0,w,h);
  const rec=new MediaRecorder(c.captureStream(30),{mimeType:mime,videoBitsPerSecond:bps}),chunks=[];rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  const stopped=new Promise(r=>rec.onstop=r);rec.start(200);const t0=performance.now(),snaps=[0,.25,.5,.75].map(f=>f*dur);
  await new Promise(res=>{const tick=()=>{const t=performance.now()-t0;draw(x,Math.min(t,dur));while(snaps.length&&t>=snaps[0]){snaps.shift();onSnap(snapCanvas(c,256,Math.round(256*h/w)))}if(t>=dur)res();else requestAnimationFrame(tick)};tick()});
  rec.stop();await stopped;return new Blob(chunks,{type:mime.split(';')[0]});
}
async function transcode(file,kind,onStep){
  const B=MEDIA_BOX[kind];let player,dur,cleanup=()=>{};
  if(/^video\//.test(file.type)){
    const v=document.createElement('video');v.muted=true;v.playsInline=true;v.loop=true;v.src=URL.createObjectURL(file);
    await new Promise((res,rej)=>{v.onloadeddata=res;v.onerror=()=>rej(new Error('Видео не открылось'))});await v.play().catch(()=>{});
    dur=Math.min(6000,(v.duration||6)*1000);player=(x,t)=>drawCoverTo(x,v,B.aw,B.ah);cleanup=()=>{v.pause();URL.revokeObjectURL(v.src)};
  }else{
    if(!('ImageDecoder' in window))throw new Error(`Анимация больше ${Math.round(B.limit/1000)} КБ — сожми файл`);
    const dec=new ImageDecoder({data:await file.arrayBuffer(),type:file.type});await dec.tracks.ready;const n=Math.min(180,dec.tracks.selectedTrack?.frameCount||1);
    const frames=[],starts=[];let acc=0;for(let i=0;i<n;i++){const f=(await dec.decode({frameIndex:i})).image;starts.push(acc);acc+=Math.max(20,(f.duration||100000)/1000);frames.push(f);if(acc>6000)break}
    const total=acc;dur=Math.min(6000,Math.max(total,1500));
    player=(x,t)=>{const tt=t%total;let k=0;while(k+1<starts.length&&starts[k+1]<=tt)k++;x.clearRect(0,0,B.aw,B.ah);drawCoverTo(x,frames[k],B.aw,B.ah)};cleanup=()=>frames.forEach(f=>f.close?.());
  }
  try{
    for(const bps of B.bps){onStep?.('Сжимаем анимацию…');const snaps=[];const blob=await recordLoop(B.aw,B.ah,dur,bps,player,c=>snaps.push(c));
      if(blob.size<=B.limit&&blob.size>2000)return {full:await fileDataUrl(blob),thumb:kind==='avatar'?modCover(snaps[0],96,96,'image/webp',.8):'',animated:true,frames:snaps}}
    throw new Error('Не получилось сжать — выбери анимацию короче');
  }finally{cleanup()}
}
/* kind: 'avatar' | 'banner' → {full, thumb, animated, frames} */
async function prepareProfileImage(file,kind,onStep){
  const B=MEDIA_BOX[kind];
  if(/^video\//.test(file.type))return transcode(file,kind,onStep);
  if(!/^image\//.test(file.type))throw new Error('Нужна картинка, GIF или короткое видео');
  const {frames,count}=await modFrames(file);
  if(count<=1){let q=.84,full=modCover(frames[0],B.w,B.h,'image/webp',q);while(full.length>450e3&&q>.4){q-=.12;full=modCover(frames[0],B.w,B.h,'image/webp',q)}if(full.length>450e3)full=modCover(frames[0],Math.round(B.w*.7),Math.round(B.h*.7),'image/jpeg',.6);
    return {full,thumb:kind==='avatar'?modCover(frames[0],96,96,'image/webp',.8):'',animated:false,frames}}
  if(file.size<=B.limit&&/gif|webp|png/.test(file.type)){const full=await fileDataUrl(file),thumb=kind==='avatar'?modCover(frames[0],96,96,'image/webp',.8):'';return {full,thumb,animated:true,frames:frames.map(f=>{const c=snapCanvas(f);f.close?.();return c})}}
  return transcode(file,kind,onStep);
}
/* ---------- AI check (one request: texts + contact sheet of all frames) ---------- */
const MOD_SYS=`You moderate public profiles in a music app. Be precise, not paranoid.
IMAGES — block only clear: nudity/sexual content, anything sexualizing minors, gore, hate or extremist symbols (swastika, SS runes, Totenkopf, KKK, ISIS/terrorist flags), drug promotion.
TEXT (name, handle, bio) — block only if it clearly contains: profanity or slurs (any language, also obfuscated: "x у й", "p1zd@", "fvck", "n1gg"), sexual words, hate/extremist slogans or numbers like 1488 used as hate code, threats, phone numbers. Never block for job-like or self-describing words (developer, creator, producer, dj, artist, team, dev) — staff words are checked separately by the app.
ALWAYS ALLOW gamer tags and nicknames with numbers or leetspeak that are not offensive: e.g. "s1xrus", "xXdarkXx", "n00b_master", "1337", "S1xrus1337", "ghost_42", "rus", "dev". Country or city names are fine. If unsure, ALLOW.
Reply with ONLY JSON: {"allow":true|false,"confidence":"high"|"low","reason":"short reason in Russian if blocked"}`;
function aiVisionCall(provider,endpoint,model,system,prompt,image){
  return new Promise((resolve,reject)=>{
    if(window.LumenNative?.aiVision){const id='mod-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{aiPending.delete(id);reject(new Error('timeout'))},70000);
      aiPending.set(id,{resolve,reject,timer});try{LumenNative.aiVision(provider,endpoint||'',model,system,prompt,image||'',id)}catch(e){clearTimeout(timer);aiPending.delete(id);reject(e)}return}
    if(provider==='groq'){const k=(window.LAZZY_CONFIG||{}).groqKey;const content=[{type:'text',text:prompt}];if(image)content.push({type:'image_url',image_url:{url:image}});
      fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'content-type':'application/json',authorization:'Bearer '+k},body:JSON.stringify({model,temperature:0,messages:[{role:'system',content:system},{role:'user',content}]})})
        .then(async r=>{const t=await r.text();if(r.status===429)throw new Error('FREE_LIMIT:20');if(!r.ok)throw new Error('HTTP '+r.status);return JSON.parse(t).choices?.[0]?.message?.content||''}).then(resolve,reject);return}
    if(provider!=='free'){reject(new Error('no native'));return}
    const content=[{type:'text',text:prompt}];if(image)content.push({type:'image_url',image_url:{url:image}});
    fetch('https://text.pollinations.ai/openai',{method:'POST',credentials:'omit',headers:{'content-type':'application/json'},body:JSON.stringify({model,temperature:0,messages:[{role:'system',content:system},{role:'user',content}]})})
      .then(async r=>{const t=await r.text();if(r.status===402||r.status===429){const m=t.match(/retry after (\d+)/i);throw new Error('FREE_LIMIT:'+(m?m[1]:30))}if(!r.ok)throw new Error('HTTP '+r.status);return JSON.parse(t).choices?.[0]?.message?.content||''}).then(resolve,reject);
  });
}
const modVerdict=raw=>{const t=String(raw||'').replace(/<think>[\s\S]*?<\/think>/gi,'').replace(/```(?:json)?/gi,'');
  const objs=t.match(/\{[^{}]*\}/g)||[];for(let i=objs.length-1;i>=0;i--){try{const j=JSON.parse(objs[i]);if(typeof j.allow==='boolean')return j}catch{}}
  try{const j=JSON.parse((t.match(/\{[\s\S]*\}/)||['{}'])[0]);return typeof j.allow==='boolean'?j:null}catch{return null}};
/* Throws Error (blocked, .blocked) or Error(.unavailable, .retryIn seconds). Own key first (no limits), then free models. */
async function moderateProfile({texts={},frames=[]},{patient=false}={}){
  const local=modTextLocal(texts,{handle:texts.handle});if(local)throw Object.assign(new Error(local),{blocked:true});
  const prompt=(isStaffUser()?'This account belongs to the official Lazzy sound team: staff words (admin, moderator, support, official, lazzy) in the name or handle are allowed.\n':'')+'Profile fields:\n'+(Object.entries(texts).filter(([,v])=>v).map(([k,v])=>`${k}: ${JSON.stringify(String(v).slice(0,300))}`).join('\n')||'(none)')+(frames.length?'\nThe image is a contact sheet of the avatar/banner (animated images: several frames).':'\nNo images.');
  const image=frames.length?modSheet(frames):'';let last='',retryIn=0;
  const routes=[];
  /* Groq vision (built-in key): Llama 4 Scout was shut down 17 Jul 2026 — Qwen first, the rest as fallbacks */
  if((window.LAZZY_CONFIG||{}).groqKey)for(const m of ['qwen/qwen3.8-27b','qwen/qwen3.6-27b','meta-llama/llama-4-scout-17b-16e-instruct'])routes.push(['groq','',m]);
  if(typeof aiHasKey==='function'&&aiHasKey())routes.push([AiConf.provider,aiEndpoint(),aiModel()]);
  for(const m of ['openai','openai-fast','openai-large'])routes.push(['free','',m]);
  for(const [prov,ep,model] of routes){
    for(let attempt=0;attempt<(patient?3:1);attempt++){
      try{const v=modVerdict(await aiVisionCall(prov,ep,model,MOD_SYS,(/qwen/i.test(model)?'/no_think\n':'')+prompt,image));
        if(v?.allow===true||(v?.allow===false&&v.confidence==='low'&&!image))return true;if(v?.allow===false)throw Object.assign(new Error(v.reason?'Модерация: '+v.reason:'Модерация не пропустила'),{blocked:true});
        last='непонятный ответ';break}
      catch(e){if(e.blocked)throw e;const m=/FREE_LIMIT:(\d+)/.exec(e.message||'');
        if(m){retryIn=Math.max(retryIn,+m[1]||30);if(patient&&attempt<2){await new Promise(z=>setTimeout(z,Math.min(60,+m[1]+1)*1000));continue}last='лимит бесплатного ИИ';break}
        last=e.message||'нет связи';break}
    }
  }
  throw Object.assign(new Error('ИИ-проверка недоступна ('+last+')'),{unavailable:true,retryIn:retryIn||60});
}
/* frames of a stored avatar/banner (data URL) for a later re-check */
async function framesFromSrc(src){
  if(isVideoSrc(src)){const v=document.createElement('video');v.muted=true;v.playsInline=true;v.src=src;await new Promise((r,j)=>{v.onloadeddata=r;v.onerror=j});
    const out=[];for(const f of [0.05,.35,.65,.95]){v.currentTime=(v.duration||1)*f;await new Promise(r=>{v.onseeked=r;setTimeout(r,1500)});out.push(snapCanvas(v))}return out}
  const blob=await (await fetch(src)).blob();const {frames}=await modFrames(new File([blob],'x',{type:blob.type}));return frames.map(f=>{const c=snapCanvas(f);f.close?.();return c});
}
