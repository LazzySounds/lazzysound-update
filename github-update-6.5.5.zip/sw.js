const C = 'lazzy-v6.5.5';
const SHELL = ['./', 'index.html', 'style.css', 'config.js', 'logos.js', 'app.js', 'skins.js', 'memory.js', 'perf.js', 'connections.js', 'soundcloud.js', 'extapis.js', 'artinfo.js', 'yt.js', 'lylib.js', 'details.js', 'studio.js', 'ai.js', 'smartsearch.js', 'player.js', 'library.js', 'home.js', 'wave.js', 'ambient.js', 'backdrop.js', 'tabs.js', 'fit.js', 'lyrics.js', 'lycustom.js', 'asr.js', 'gemsync.js', 'offline.js', 'importer.js', 'nettune.js', 'hscroll.js', 'update.js', 'yandex.js', 'native-web.js', 'google.js', 'moderation.js', 'social.js', 'brand.js', 'motion.js', 'fonts/inter.woff', 'manifest.webmanifest', 'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(C).then(c => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(r => { if (r.ok) { const c = r.clone(); caches.open(C).then(x => x.put(e.request, c)); } return r; }).catch(() => caches.match(e.request)));
});
