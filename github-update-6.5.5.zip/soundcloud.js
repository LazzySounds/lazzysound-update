'use strict';
/* Lazzy sound 4.6 — SoundCloud via its public API with the listener's own client_id (Профиль → Источники).
   Only full, freely streamable tracks are used: policy ALLOW/MONETIZE with a progressive MP3 stream; previews
   ("SNIP"), blocked and Go+-only tracks are skipped. Stream links are signed and short-lived, so they are fetched at play time. */
const SC={id:store.get('scClientId',''),pending:new Map()};
window.__lazzySC=(id,payload)=>{const p=SC.pending.get(id);if(!p)return;SC.pending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.connectorError)throw new Error(j.connectorError==='auth'?'SoundCloud не принял Client ID':'SoundCloud не ответил');p.resolve(j)}catch(e){p.reject(e)}};
function scGet(url){
  if(window.LumenNative?.soundcloudGet)return new Promise((resolve,reject)=>{const id='sc-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{SC.pending.delete(id);reject(new Error('SoundCloud не ответил'))},15000);SC.pending.set(id,{resolve,reject,timer});LumenNative.soundcloudGet(url,id)});
  return bounded(fetch(url,{credentials:'omit'}).then(r=>{if(r.status===401||r.status===403)throw new Error('SoundCloud не принял Client ID');if(!r.ok)throw new Error('SoundCloud HTTP '+r.status);return r.json()}),12000);
}
const scQ=o=>Object.entries(o).map(([k,v])=>k+'='+encodeURIComponent(v)).join('&');
function mapSC(list){
  return (list||[]).filter(t=>t&&t.kind==='track'&&t.streamable!==false&&!['SNIP','BLOCK'].includes(t.policy)).map(t=>{
    const tr=(t.media?.transcodings||[]).find(x=>x.format?.protocol==='progressive'&&!x.snipped&&/^https:\/\/api-v2\.soundcloud\.com\/media\//.test(x.url||''));if(!tr)return null;
    const art=(t.artwork_url||t.user?.avatar_url||'');const sec=Math.round((t.full_duration||t.duration||0)/1000);
    return {id:'sc:'+t.id,type:'soundcloud',title:t.title||'Без названия',artist:t.user?.username||'SoundCloud',duration:sec,meta:fmt(sec)+(t.playback_count?' · ▶︎ '+compactNum(t.playback_count):''),
      art:/^https:/.test(art)?art.replace('-large.','-t500x500.'):'',artSm:/^https:/.test(art)?art:'',src:tr.url,auth:t.track_authorization||'',genre:t.genre||'',plays:t.playback_count||0,
      sourceUrl:/^https:\/\/soundcloud\.com\//.test(t.permalink_url||'')?t.permalink_url:'https://soundcloud.com',fullStream:true};
  }).filter(Boolean);
}
async function searchSoundCloud(q){if(!SC.id)return [];const j=await scGet('https://api-v2.soundcloud.com/search/tracks?'+scQ({q:q.slice(0,120),limit:30,client_id:SC.id}));return mapSC(j.collection)}
async function scResolve(t){const u=t.src+'?'+scQ(t.auth?{client_id:SC.id,track_authorization:t.auth}:{client_id:SC.id});const j=await scGet(u);if(!/^https:\/\//.test(j.url||''))throw new Error('Поток SoundCloud недоступен');return j.url}

/* settings card */
function renderSCSettings(){
  const host=$('#scSettings');if(!host)return;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-cloud"/></svg><h2>SoundCloud</h2></div>
    <p class="settings-help">Полные треки SoundCloud в общем поиске. Нужен твой Client ID приложения SoundCloud (soundcloud.com/you/apps). Превью и платные треки пропускаются.</p>
    <label class="field-label" for="scId">SoundCloud Client ID</label><input class="settings-input" id="scId" maxlength="64" autocomplete="off" spellcheck="false" placeholder="Client ID" value="${esc(SC.id)}">
    <div class="api-actions"><button class="btn-accent" id="scSave">Сохранить</button><button class="chip" id="scTest">Проверить</button>${SC.id?'<button class="text-link" id="scOff">Отключить</button>':''}</div>
    <p class="api-status" id="scStatus" role="status">${SC.id?'Подключён':'Не подключён'}</p>`;
  $('#scSave').onclick=()=>{const v=$('#scId').value.trim();if(!/^[A-Za-z0-9]{10,64}$/.test(v)){$('#scStatus').textContent='Client ID — 10–64 латинских букв и цифр';return}SC.id=v;store.set('scClientId',v);renderSCSettings();toast('SoundCloud подключён')};
  $('#scTest').onclick=async()=>{const st=$('#scStatus');st.textContent='Проверяем…';try{const r=await searchSoundCloud('lofi');st.textContent=r.length?`Работает: найдено ${r.length} полных треков`:'Ответ пришёл, но полных треков нет'}catch(e){st.textContent=e.message}};
  if($('#scOff'))$('#scOff').onclick=()=>{SC.id='';store.set('scClientId','');renderSCSettings()};
}
renderSCSettings();
