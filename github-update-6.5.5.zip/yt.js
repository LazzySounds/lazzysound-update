'use strict';
/* 5.9.1 YouTube: search via YouTube Data API v3 (key), playback only through the official IFrame player (visible, ≥200 px, foreground) */
const YTS=window.__yt={key:store.get('ytKey','')||(window.LAZZY_CONFIG||{}).youtubeKey||'',p:null,ready:null,on:false,playing:false,timer:0,tid:''};
const ytArtist=s=>String(s||'').replace(/\s*-\s*Topic$/i,'').replace(/VEVO$/i,'').trim();
/* drop video noise from titles so lyrics are found: (Official Video), [Клип], | Lyrics, 4K, Премьера… */
const YT_NOISE=/official|video|music|lyric|audio|visuali[sz]er|клип|премьера|текст|mood|hd|4k|remaster|live|mv|m\/v|оф/i;
const ytClean=s=>String(s).replace(/[\[(【]([^\])】]*)[\])】]/g,(a,x)=>/^(feat|ft)\.?\s/i.test(x)||!YT_NOISE.test(x)?a:'').replace(/\s*[|｜/]\s*(official|lyric|клип|премьера|текст|audio)[^|]*$/i,'').replace(/\s*#\S+/g,'').replace(/\s+(?:\/\/?|｜|•)\s+.*$/,'').replace(/[«»"]/g,'').replace(/\s{2,}/g,' ').trim();
const unent=s=>{const d=document.createElement('textarea');d.innerHTML=s||'';return d.value};
const isoSec=s=>{const m=/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(s||'');return m?(+m[1]||0)*3600+(+m[2]||0)*60+(+m[3]||0):0};
async function ytApi(path,params){if(!YTS.key)throw new Error('Нет ключа YouTube');const u=new URL('https://www.googleapis.com/youtube/v3/'+path);Object.entries({...params,key:YTS.key}).forEach(([k,v])=>u.searchParams.set(k,v));
  const r=await bounded(fetch(u.href,{credentials:'omit'}),10000);const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j?.error?.errors?.[0]?.reason==='quotaExceeded'?'Лимит поиска YouTube на сегодня исчерпан':'YouTube: '+(j?.error?.message||r.status));return j}
/* videos whose owner forbids embedding (errors 101/150) are remembered and replaced by another upload — usually the label's "Artist - Topic" audio */
if(store.get('ytBlockedV',0)!==2){store.set('ytBlocked',[]);store.set('ytBlockedV',2)}
const ytBlocked=new Set(store.get('ytBlocked',[]));
const ytBlock=id=>{ytBlocked.add(id);store.set('ytBlocked',[...ytBlocked].slice(-400))};
async function ytAlternative(t){const q=(t.artist?t.artist+' ':'')+t.title;let list=[];try{list=await searchYouTube(q)}catch{}
  if(!list.some(x=>!ytBlocked.has(x.yt)&&x.topic)){try{list=list.concat(await searchYouTube(q+' topic'))}catch{}}
  const ok=list.filter(x=>!ytBlocked.has(x.yt)&&x.yt!==t.yt&&similarity(t.title,x.title)>.6&&(!t.artist||similarity(t.artist,x.artist)>.45));
  return ok.find(x=>x.topic)||ok[0]||null}
async function searchYouTube(q){
  const ck='yt4:'+normalize(q),all=store.get('ytCache',{}),c=all[ck];if(c&&Date.now()-c.t<3*86400e3)return c.items;
  const s=await ytApi('search',{part:'snippet',type:'video',videoCategoryId:'10',videoEmbeddable:'true',maxResults:'20',q:q.slice(0,120)});
  const ids=(s.items||[]).map(x=>x.id?.videoId).filter(Boolean);if(!ids.length)return [];
  const v=await ytApi('videos',{part:'contentDetails,status',id:ids.join(',')}).catch(()=>({items:[]}));const det=new Map((v.items||[]).map(x=>[x.id,x]));
  const items=(s.items||[]).flatMap(x=>{const id=x.id?.videoId,d=det.get(id);if(!id||d&&d.status?.embeddable===false||ytBlocked.has(id))return [];const sn=x.snippet||{};let title=unent(sn.title),artist=ytArtist(unent(sn.channelTitle));
    title=ytClean(title);const m=/^(.+?)\s+[-–—|]\s+(.+)$/.exec(title);if(m&&!/topic$/i.test(sn.channelTitle||'')){artist=m[1].trim();title=m[2].trim()}else artist=artist.replace(/\s*(official|music|records|tv|channel|vevo)\s*$/i,'').trim()||artist;
    const sec=isoSec(d?.contentDetails?.duration);if(sec&&(sec<45||sec>1200))return [];
    return [{id:'yt:'+id,type:'youtube',yt:id,src:'yt:'+id,title:title.slice(0,300),artist:artist.slice(0,200),art:'https://i.ytimg.com/vi/'+id+'/mqdefault.jpg',duration:sec,meta:(sec?fmt(sec)+' · ':'')+'YouTube',topic:/topic$/i.test(sn.channelTitle||''),sourceUrl:'https://www.youtube.com/watch?v='+id,fullStream:true}]});
  items.sort((a,b)=>(b.topic?1:0)-(a.topic?1:0));all[ck]={t:Date.now(),items};const ks=Object.keys(all);if(ks.length>150)delete all[ks[0]];store.set('ytCache',all);return items}

/* ---------- player ---------- */
function ytLoadApi(){return YTS.ready||(YTS.ready=new Promise((res,rej)=>{setTimeout(()=>{if(!window.YT?.Player){YTS.ready=null;rej(new Error('Плеер YouTube не загрузился — проверь интернет'))}},12000);if(window.YT?.Player)return res();const prev=window.onYouTubeIframeAPIReady;window.onYouTubeIframeAPIReady=()=>{prev?.();res()};const s=document.createElement('script');s.src='https://www.youtube.com/iframe_api';document.head.appendChild(s)}))}
/* the video area is never covered: our controls live in a bar above it (YouTube's own overlay stays clear) */
const YT_BAR=30,YT_H=200;let YT_W=Math.min(innerWidth-20,356);addEventListener('resize',()=>{YT_W=Math.min(innerWidth-20,356)});
function ytBox(){let b=$('#ytBox');if(b)return b;document.body.insertAdjacentHTML('beforeend',`<div id="ytBox" class="yt-box" hidden><div class="yt-bar"><i class="yt-grip" aria-hidden="true"></i><button class="yt-corner" aria-label="В угол">⇲</button>${window.LumenNative?.enterPip?'<button class="yt-pip" aria-label="Мини-окно">⧉</button>':''}<button class="yt-src" aria-label="Открыть в приложении YouTube">▶ YouTube</button></div><div id="ytFrameHost"></div></div>`);b=$('#ytBox');
  b.querySelector('.yt-corner').onclick=()=>{const k=((YTS.corner??-1)+1)%4;YTS.corner=k;const top=k<2,left=k%2===1;YTS.drag={x:left?10:innerWidth-YT_W-10,y:top?Math.max(80,(innerHeight*.1)|0):innerHeight-YT_H-YT_BAR-170};ytPlace()};
  b.querySelector('.yt-src').onclick=()=>{const t=cur();if(!t?.yt)return;const s=Math.floor(YTS.p?.getCurrentTime?.()||0);try{YTS.p?.pauseVideo?.()}catch{}window.open('https://www.youtube.com/watch?v='+encodeURIComponent(t.yt)+(s>3?'&t='+s+'s':''),'_blank','noopener')};
  const pb=b.querySelector('.yt-pip');if(pb)pb.onclick=()=>{try{LumenNative.enterPip()}catch{}};
  /* drag by the bar */
  const g=b.querySelector('.yt-bar');let o=null;g.addEventListener('pointerdown',e=>{if(e.target.closest('button')||b.classList.contains('in-full')||b.classList.contains('in-ly'))return;const r=b.getBoundingClientRect();o={dx:e.clientX-r.left,dy:e.clientY-r.top};g.setPointerCapture(e.pointerId);e.preventDefault()});
  g.addEventListener('pointermove',e=>{if(!o)return;YTS.drag={x:Math.max(0,Math.min(innerWidth-YT_W,e.clientX-o.dx)),y:Math.max(0,Math.min(innerHeight-YT_H-YT_BAR,e.clientY-o.dy))};ytPlace()});
  g.addEventListener('pointerup',()=>{o=null});return b}
function ytPlace(){const b=$('#ytBox');if(!b||b.hidden)return;b.classList.remove('in-full','in-ly');
  if(document.body.classList.contains('pip')){Object.assign(b.style,{left:'0',top:'0',right:'0',bottom:'0',width:'100%',height:'100%'});return}
  const full=document.body.classList.contains('full-open'),c=$('#fullCover');
  if(full&&$('#full')?.classList.contains('lyrics-open')){b.classList.add('in-ly');Object.assign(b.style,{left:Math.round((innerWidth-YT_W)/2)+'px',right:'auto',top:'calc(64px + env(safe-area-inset-top))',bottom:'auto',width:YT_W+'px',height:(YT_H+YT_BAR)+'px'});if(!YTS.lyF){YTS.lyF=1;setTimeout(()=>{YTS.lyF=0;try{Ly.gLine=-1;sync(true)}catch{}},120)}return}
  if(full&&c){const r=c.getBoundingClientRect();if(r.width>=200){const h=Math.max(YT_H,r.width*9/16)+YT_BAR;Object.assign(b.style,{left:r.left+'px',top:(r.top+(r.height-h)/2)+'px',width:r.width+'px',height:h+'px',right:'auto',bottom:'auto'});b.classList.add('in-full');return}}
  const d=YTS.drag;Object.assign(b.style,{top:d?d.y+'px':'auto',left:d?d.x+'px':Math.round((innerWidth-YT_W)/2)+'px',right:'auto',bottom:d?'auto':'calc(176px + env(safe-area-inset-bottom))',width:YT_W+'px',height:(YT_H+YT_BAR)+'px'})}
const ytTick=()=>{const p=YTS.p;if(!p?.getCurrentTime)return;const c=p.getCurrentTime()||0,d=p.getDuration()||cur()?.duration||0,pc=d?c/d*100:0;
  $('#miniProg').style.transform='scaleX('+(pc/100).toFixed(4)+')';
  if(document.body.classList.contains('full-open')&&!seeking){$('#seek').value=Math.round(pc*10);$('#seek').style.setProperty('--p',pc+'%');$('#tCur').textContent=fmt(c);$('#tDur').textContent=fmt(d)}
  if($('#lyCur')){$('#lyCur').textContent=fmt(c);$('#lyDur').textContent=fmt(d)}};
function ytState(playing){YTS.playing=playing;try{paintHead()}catch{}try{window.LumenNative?.setPip?.(!!YTS.on);window.LumenNative?.setPipPlaying?.(!!playing)}catch{}updateUI()}
window.__lazzyPipAct=c=>{if(c==='toggle')toggle();else if(c==='next')next();else if(c==='prev')prev()};
window.__lazzyPip=on=>{document.body.classList.toggle('pip',!!on);ytPlace()};
async function ytPlay(t){
  try{window.LumenNative?.setPip?.(true)}catch{}if(typeof Ly!=='undefined'&&Ly.open&&Ly.id!==t.id)setTimeout(()=>{try{loadFor(t)}catch{}},0);
  const b=ytBox();b.hidden=false;document.body.classList.add('yt-on');ytPlace();YTS.on=true;YTS.tid=t.id;
  audio.pause();audio.removeAttribute('src');try{audio.load()}catch{}$('#miniProg').style.transform='scaleX(0)';
  try{await ytLoadApi()}catch(e){toast(e.message);return}if(YTS.tid!==t.id)return;
  if(YTS.p?.loadVideoById){YTS.p.loadVideoById(t.yt);return}
  const host=$('#ytFrameHost');host.innerHTML=`<iframe id="ytFrame" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" src="https://www.youtube.com/embed/${encodeURIComponent(t.yt)}?enablejsapi=1&autoplay=1&playsinline=1&rel=0&origin=${encodeURIComponent(location.origin)}"></iframe>`;
  YTS.p=new YT.Player('ytFrame',{events:{
    onReady:e=>{e.target.setVolume(Math.round(audio.volume*100));e.target.playVideo()},
    onStateChange:e=>{if(e.data===1)ytState(true);else if(e.data===2)ytState(false);else if(e.data===0){ytState(false);if(S.repeat==='one'){e.target.seekTo(0);e.target.playVideo()}else next(true)}},
    onError:async e=>{const t=cur();if(!t||t.type!=='youtube')return;const code=e.data;
      if([101,150].includes(code)){ytBlock(t.yt);t.tries=(t.tries||0)+1;
        if(t.tries<=2){toast('Владелец запретил встраивание этого ролика — ищем другую загрузку…');const alt=await ytAlternative(t);
          if(alt&&cur()===t){t.yt=alt.yt;t.src=alt.src;t.sourceUrl=alt.sourceUrl;t.art=t.art||alt.art;try{YTS.p.loadVideoById(alt.yt)}catch{}return}}}
      toast(code===152||code===153?'YouTube отклонил встроенный плеер (ошибка '+code+')':code===100?'Ролик удалён или закрыт (100) · следующий':'YouTube не даёт играть этот ролик ('+code+') · следующий');if(code===152||code===153)return;setTimeout(()=>next(true),1200)}}});
  clearInterval(YTS.timer);YTS.timer=setInterval(ytTick,500)}
function ytStop(){if(!YTS.on)return;YTS.on=false;YTS.playing=false;YTS.tid='';try{YTS.p?.stopVideo?.()}catch{}const b=$('#ytBox');if(b)b.hidden=true;document.body.classList.remove('yt-on');clearInterval(YTS.timer);try{window.LumenNative?.setPip?.(false)}catch{}}

const baseLoad591=load;
load=async function(){const t=cur();if(t?.type==='youtube'){if(!navigator.onLine){toast('Нет сети');return}
  await ytPlay(t);S.recent=[t,...S.recent.filter(r=>r.id!==t.id)].slice(0,30);store.set('recent',S.recent);updateUI();renderRecent?.();if(typeof playerContextChanged==='function')playerContextChanged();return}
  ytStop();return baseLoad591()};
const baseToggle591=toggle;
toggle=function(){if(YTS.on&&YTS.p?.getPlayerState){YTS.playing?YTS.p.pauseVideo():YTS.p.playVideo();return}return baseToggle591()};
const basePrev591=prev;
prev=function(){if(YTS.on&&YTS.p?.getCurrentTime&&YTS.p.getCurrentTime()>3){YTS.p.seekTo(0,true);return}return basePrev591()};
const baseUpdateUI591=updateUI;
updateUI=function(){baseUpdateUI591();if(!YTS.on)return;const pl=YTS.playing;document.body.classList.toggle('paused-all',!pl);document.body.classList.toggle('is-playing',pl);
  const ic=`<svg><use href="#i-${pl?'pause':'play'}"/></svg>`;$('#miniPlay').innerHTML=ic;$('#playBtn').innerHTML=ic;$('#full').classList.toggle('paused',!pl)};
$('#seek').addEventListener('change',e=>{if(YTS.on&&YTS.p?.seekTo){const d=YTS.p.getDuration()||0;if(d)YTS.p.seekTo(e.target.value/1000*d,true)}});
$('#vol').addEventListener('input',e=>{if(YTS.on)YTS.p?.setVolume?.(+e.target.value)});
/* foreground only (YouTube terms): pause when the app is hidden */
document.addEventListener('visibilitychange',()=>{if(document.hidden&&YTS.on&&YTS.playing&&!document.body.classList.contains('pip'))YTS.p?.pauseVideo?.()});
{const mo=new MutationObserver(()=>{for(const ms of [60,350,700])setTimeout(ytPlace,ms)});mo.observe(document.body,{attributes:true,attributeFilter:['class']});const f=$('#full');if(f)mo.observe(f,{attributes:true,attributeFilter:['class']})}
/* lyrics follow the YouTube clock */
if(typeof paintHead==='function'){const bph=paintHead;paintHead=function(){bph();if(YTS.on&&$('#lyPlay'))$('#lyPlay').innerHTML=`<svg><use href="#i-${YTS.playing?'pause':'play'}"/></svg>`}}
if(typeof playTime==='function'){const basePlayTime594=playTime;playTime=function(){if(YTS.on&&YTS.p?.getCurrentTime){const c=YTS.p.getCurrentTime()||0;if(!YTS.playing)return c;const now=performance.now();if(c!==YTS.lc){YTS.lc=c;YTS.lcAt=now}return c+Math.min(.6,(now-(YTS.lcAt||now))/1000)}return basePlayTime594()}}
(function ytLyr(){requestAnimationFrame(ytLyr);if(YTS.on&&YTS.playing&&typeof Ly!=='undefined'&&Ly.open&&!document.hidden)try{sync()}catch{}})();
/* «Свернуть приложение»: picture-in-picture for YouTube, otherwise to the background (music keeps playing) */
if(window.LumenNative?.minimize){const top=$('#full .full-top');if(top&&!$('#appMin')){$('#queueBtn').insertAdjacentHTML('beforebegin','<button class="ibtn glass" id="appMin" aria-label="Свернуть приложение">⧉</button>');$('#appMin').onclick=()=>{try{LumenNative.minimize()}catch{}}}}addEventListener('resize',ytPlace);
['play','playing'].forEach(ev=>audio.addEventListener(ev,()=>{if(YTS.on&&cur()?.type!=='youtube')ytStop()}));

/* ---------- search + labels ---------- */
const baseSourceJobs591=sourceJobs;
/* 6.3.3: the YouTube key has ~100 searches a day for everyone together — don't spend them on half-typed words:
   while typing, YouTube waits until the query has stayed the same for 2 s; a quota error is told once */
let ytQuotaToast=0;
sourceJobs=function(q,o){const jobs=baseSourceJobs591(q,o);if(YTS.key)jobs.push(['youtube',async()=>{
    const typing=document.activeElement===$('#q')&&$('#q').value.trim()===q;if(typing){await new Promise(r=>setTimeout(r,2000));if($('#q').value.trim()!==q)throw new Error('skip')}
    try{return await searchYouTube(q)}catch(e){if(/Лимит/.test(e.message)&&Date.now()-ytQuotaToast>600000){ytQuotaToast=Date.now();toast('Лимит поиска YouTube на сегодня исчерпан — завтра снова заработает')}throw e}}]);return jobs};
Object.assign(PROVIDER_LABELS,{youtube:'YouTube'});
/* search: YouTube results only in their own block under the main list */
function renderYtResults(){let host=$('#ytResults');if(!host){$('#searchList').insertAdjacentHTML('afterend','<section id="ytResults" class="yt-results" hidden></section>');host=$('#ytResults')}
  const yl=(searchFilter==='all'||searchFilter==='audio')&&$('#q').value.trim()?mergedResults.filter(t=>t.type==='youtube'):[];host.hidden=!yl.length;if(!yl.length){host.innerHTML='';return}
  host.innerHTML=`<div class="yt-plate glass"><span class="yt-logo" aria-hidden="true">▶</span><span><b>Треки с YouTube</b><small>${plural(yl.length,'трек','трека','треков')} · играют в плеере YouTube, видео на экране</small></span></div><div class="list" id="ytList"></div>`;
  renderList($('#ytList'),yl,{onOpen:t=>playTrack(yl,yl.findIndex(x=>x.id===t.id))})}
const baseClearSearch593=clearSearch;clearSearch=function(){baseClearSearch593();const h=$('#ytResults');if(h){h.hidden=true;h.innerHTML=''}};

/* ---------- settings ---------- */
function renderYTSettings(){let host=$('#ytSettings');if(!host){$('#scSettings')?.insertAdjacentHTML('afterend','<div class="settings-group api-settings" id="ytSettings"></div>');host=$('#ytSettings')}if(!host)return;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-search"/></svg><h2>YouTube</h2></div>
    <p class="settings-help">Музыка с YouTube в общем поиске. Играет через официальный плеер YouTube: видео видно на экране, в фоне не играет. Нужен ключ YouTube Data API v3 (console.cloud.google.com).</p>
    <label class="field-label" for="ytKey">API-ключ</label><input class="settings-input" id="ytKey" maxlength="80" autocomplete="off" spellcheck="false" placeholder="AIza…" value="${esc(store.get('ytKey',''))}">
    <div class="api-actions"><button class="btn-accent" id="ytSave">Сохранить</button><button class="chip" id="ytTest">Проверить</button></div>
    <p class="api-status" id="ytStatus" role="status">${YTS.key?'Подключён':'Не подключён'}</p>`;
  $('#ytSave').onclick=()=>{const v=$('#ytKey').value.trim();if(v&&!/^AIza[\w-]{30,}$/.test(v)){$('#ytStatus').textContent='Ключ начинается с AIza…';return}store.set('ytKey',v);YTS.key=v||(window.LAZZY_CONFIG||{}).youtubeKey||'';renderYTSettings();toast(YTS.key?'YouTube подключён':'YouTube отключён')};
  $('#ytTest').onclick=async()=>{const st=$('#ytStatus');st.textContent='Проверяем…';try{const all=store.get('ytCache',{});delete all['yt4:'+normalize('кино группа крови')];store.set('ytCache',all);const r=await searchYouTube('кино группа крови');st.textContent=r.length?'Работает: найдено '+r.length:'Ответ есть, но пусто'}catch(e){st.textContent=e.message}}}
renderYTSettings();

/* keep the video exactly over the cover while the full player animates or scrolls */
(function ytFollow(){requestAnimationFrame(ytFollow);if(!YTS.on||!document.body.classList.contains('full-open')||$('#full')?.classList.contains('lyrics-open'))return;const c=$('#fullCover'),b=$('#ytBox');if(!c||!b||b.hidden)return;const r=c.getBoundingClientRect(),k=r.left+'|'+r.top+'|'+r.width;if(k!==YTS.fk){YTS.fk=k;ytPlace()}})();

/* lyrics for YouTube tracks: the usual sources, then the lyrics often posted in the video description */
async function ytDescLyrics(id){const j=await ytApi('videos',{part:'snippet',id});const d=String(j.items?.[0]?.snippet?.description||'');
  const blocks=d.split(/\n\s*\n/).map(b=>b.split('\n').map(x=>x.trim()).filter(Boolean)).filter(b=>b.length>=2);
  const ok=l=>l.length>=2&&l.length<=90&&!/https?:|www\.|@|#|©|℗|prod|mix|master|lyrics by|текст:|музыка:|слова:|подпис|subscribe|instagram|vk\.com|t\.me|spotify|apple|яндекс|boosty|donat/i.test(l);
  const keep=blocks.map(b=>b.filter(ok)).filter(b=>b.length>=2);const lines=keep.flatMap((b,i)=>i?['',...b]:b);
  return lines.filter(Boolean).length>=8?lines.join('\n'):''}
if(typeof findLyrics==='function'){const baseFind596=findLyrics;findLyrics=async function(t,say,o){const r=await baseFind596(t,say,o);
  if(t?.type==='youtube'&&r?.missing&&YTS.key){try{say?.('Ищем текст в описании видео…');const plain=await ytDescLyrics(t.yt);if(plain)return {plain,synced:[],src:'Описание видео YouTube',v:2,title:t.title,artist:t.artist}}catch{}}
  return r}}

/* the <audio> clock (empty while YouTube plays) must not overwrite the progress bars */
audio.addEventListener('timeupdate',()=>{if(YTS.on)ytTick()});
