'use strict';
/* Optional personal JadeMusic server. No server address, secret or access bypass bundled. */
function publicHttps(value){
  try{const u=new URL(String(value).trim());const h=u.hostname.toLowerCase();if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||!h.includes('.')||h==='localhost'||/^\d+\.\d+\.\d+\.\d+$/.test(h)||h.includes(':')||/\.(localhost|local|internal|lan|test|invalid|example)$/.test(h)||/[^a-z0-9.-]/.test(h)||h.endsWith('.'))return null;return u}catch{return null}
}
function jadeEndpoint(value){
 const u=publicHttps(value);if(!u||u.search||u.hash)throw new Error('Нужен публичный HTTPS-адрес без логина, токенов и параметров.');
 if(/(^|\.)(github\.com|raw\.githubusercontent\.com|hitmoz\.com|vk\.com|vk\.ru)$/.test(u.hostname))throw new Error('Это сайт, а не адрес развёрнутого JadeMusic API.');
 let path=u.pathname.replace(/\/+$/,'');if(path.endsWith('/api/v1/track/get')){}else if(path.endsWith('/api/v1'))path+='/track/get';else path+='/api/v1/track/get';u.pathname=path+'/';return u.href;
}
let savedJade='';try{const v=store.get('jadeEndpoint','');if(v)savedJade=jadeEndpoint(v)}catch{store.set('jadeEndpoint','')}
const savedJamendo=String(store.get('jamendoId',''));
const Connections={hitmozEnabled:store.get('hitmozEnabled',true)!==false,jadeEndpoint:savedJade,jamendoId:/^[a-zA-Z0-9_-]{4,80}$/.test(savedJamendo)?savedJamendo:''};
const jadePending=new Map();
window.__lumenJadeResult=(id,payload)=>{const p=jadePending.get(id);if(!p)return;jadePending.delete(id);clearTimeout(p.timer);try{const data=JSON.parse(payload);if(data.connectorError)throw new Error(data.connectorError);p.resolve(data)}catch(e){p.reject(e)}};
async function jadeRequest(endpoint,query){
 endpoint=jadeEndpoint(endpoint);
 if(window.LumenNative?.searchJade)return new Promise((resolve,reject)=>{const id='jade-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{jadePending.delete(id);reject(new Error('Сервер не ответил вовремя.'))},13000);jadePending.set(id,{resolve,reject,timer});try{LumenNative.searchJade(endpoint,String(query).slice(0,200),id)}catch(e){clearTimeout(timer);jadePending.delete(id);reject(e)}});
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),11000);
 try{const u=new URL(endpoint);u.searchParams.set('q',String(query).slice(0,200));u.searchParams.set('page','1');const r=await fetch(u.href,{signal:controller.signal,credentials:'omit',redirect:'error',headers:{Accept:'application/json'}});if(!r.ok)throw new Error('Сервер вернул HTTP '+r.status);const text=await r.text();if(text.length>2000000)throw new Error('Слишком большой ответ API.');return JSON.parse(text)}finally{clearTimeout(timer)}
}
function jadeTracks(j,endpoint){
 const rows=j?.data?.tracks??j?.tracks??(Array.isArray(j?.data)?j.data:null);
 if(!Array.isArray(rows))throw new Error('Ответ не соответствует JadeMusic: нужен массив data.tracks.');
 return rows.slice(0,100).flatMap(row=>{const d=row?.data&&typeof row.data==='object'?row.data:row;if(!d||typeof d!=='object')return [];
 const raw=d.url||d.src||d.audio||'',u=publicHttps(raw);if(!u||/\.(html?|php)$/i.test(u.pathname)||!u.pathname||u.pathname==='/')return [];
 if(d.isPreview===true||d.is_preview===true||d.preview===true||d.is_full===false||d.is_full_track===false||d.is_stream_gated===true||d.is_available===false||d.access?.stream===false||/(^|[\W_])(preview|snippet|teaser|excerpt)([\W_]|$)/i.test((d.full_title||d.title||'')+' '+u.pathname))return [];
 let title=String(d.title||''),artist=String(d.artist||'');const full=String(d.full_title||'');if(!title&&full){const n=full.indexOf(' - ');if(n>=0){artist=full.slice(0,n);title=full.slice(n+3)}else title=full}if(!title)return [];
 const duration=typeof d.duration==='number'?d.duration:/^\d+:\d{2}$/.test(d.duration||'')?String(d.duration).split(':').reduce((n,x)=>n*60+Number(x),0):0;
 const art=publicHttps(d.art||d.image||d.img||'');const src=u.href;
 return [{id:'jade:'+endpoint+'|'+src,type:'jade',title:title.slice(0,300),artist:artist.slice(0,200)||'Твой API',src,art:art?art.href:'',meta:duration?fmt(duration):'',duration,sourceUrl:new URL(endpoint).origin,fullStream:true}];
 });
}
async function searchJade(query,endpoint=Connections.jadeEndpoint){if(!endpoint)return [];return jadeTracks(await jadeRequest(endpoint,query),endpoint)}
function jadeStatus(text,state=''){const el=$('#jadeStatus');el.textContent=text;el.dataset.state=state}
function resetJadeSearch(){searchGeneration++;searchCache.clear();clearSearch();$('#searchHint').textContent='Источники обновлены. Повтори поиск.'}
$('#jadeUrl').value=Connections.jadeEndpoint;
if(Connections.jadeEndpoint)jadeStatus('Адрес сохранён. Доступность сервера ещё не проверена.');
$('#jadeUrl').oninput=()=>{try{$('#jadeEndpointHint').textContent='Метод: '+jadeEndpoint($('#jadeUrl').value)}catch{$('#jadeEndpointHint').textContent='Метод: /api/v1/track/get/'}};
$('#jadeSave').onclick=()=>{try{const endpoint=jadeEndpoint($('#jadeUrl').value);Connections.jadeEndpoint=endpoint;store.set('jadeEndpoint',endpoint);$('#jadeUrl').value=endpoint;resetJadeSearch();jadeStatus('Сохранён для общего поиска. Нажми «Проверить», чтобы проверить ответ.');toast('Адрес API сохранён')}catch(e){jadeStatus(e.message,'error')}};
let jadeCheckToken=0;
$('#jadeTest').onclick=async()=>{const token=++jadeCheckToken;let endpoint;try{endpoint=jadeEndpoint($('#jadeUrl').value)}catch(e){jadeStatus(e.message,'error');return}const button=$('#jadeTest');button.disabled=true;jadeStatus('Проверяем ответ сервера…');try{const query=$('#q').value.trim()||'jazz';const tracks=await searchJade(query,endpoint);if(token!==jadeCheckToken)return;jadeStatus('Формат ответа корректен. Аудиоссылок: '+tracks.length+'. '+(endpoint===Connections.jadeEndpoint?'Источник сохранён.':'Для подключения нажми «Сохранить».')+' Воспроизведение каждой ссылки отдельно не проверялось.','ok')}catch(e){if(token===jadeCheckToken)jadeStatus(e.name==='AbortError'?'Сервер не ответил вовремя.':'Не удалось проверить: '+(e.message||'ошибка сети')+'. Проверь адрес и работу парсера на сервере.','error')}finally{if(token===jadeCheckToken)button.disabled=false}};
$('#jadeDisable').onclick=()=>{jadeCheckToken++;$('#jadeTest').disabled=false;Connections.jadeEndpoint='';store.set('jadeEndpoint','');$('#jadeUrl').value='';$('#jadeEndpointHint').textContent='Метод: /api/v1/track/get/';resetJadeSearch();jadeStatus('Не подключён. Встроенные источники работают.');toast('Твой API отключён')};
/* Official Jamendo full-track audio. Public client ID is not a client secret. */
function jamendoId(value){const id=String(value).trim();if(!/^[a-zA-Z0-9_-]{4,80}$/.test(id))throw new Error('Укажи Client ID из кабинета Jamendo, не URL и не Client Secret.');return id}
const jamendoPending=new Map();
window.__lumenJamendoResult=(id,payload)=>{const p=jamendoPending.get(id);if(!p)return;jamendoPending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.connectorError)throw new Error(j.connectorError);p.resolve(j)}catch(e){p.reject(e)}};
async function jamendoRequest(query,id){
 id=jamendoId(id);
 if(window.LumenNative?.searchJamendo)return new Promise((resolve,reject)=>{const requestId='jm-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{jamendoPending.delete(requestId);reject(new Error('Jamendo не ответил вовремя.'))},13000);jamendoPending.set(requestId,{resolve,reject,timer});try{LumenNative.searchJamendo(id,String(query).slice(0,200),requestId)}catch(e){clearTimeout(timer);jamendoPending.delete(requestId);reject(e)}});
 const url=new URL('https://api.jamendo.com/v3.0/tracks/');for(const [k,v] of Object.entries({client_id:id,format:'json',limit:'40',audioformat:'mp32',type:'single albumtrack',search:String(query).slice(0,200)}))url.searchParams.set(k,v);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),11000);try{const r=await fetch(url.href,{signal:controller.signal,credentials:'omit'});if(!r.ok)throw new Error('Jamendo HTTP '+r.status);const text=await r.text();if(text.length>2000000)throw new Error('Слишком большой ответ.');return JSON.parse(text)}finally{clearTimeout(timer)}
}
function jamendoTracks(j){
 if(j?.headers?.status!=='success'||!Array.isArray(j.results))throw new Error('Jamendo не подтвердил запрос. Проверь Client ID и лимит API.');
 return j.results.slice(0,100).flatMap(t=>{const u=publicHttps(t.audio);if(!u||!t.name||/(^|[\W_])(preview|snippet|teaser)([\W_]|$)/i.test(t.name+' '+u.pathname)||t.is_preview===true||t.isPreview===true||t.is_full===false)return [];const page=publicHttps(t.shareurl),art=publicHttps(t.image||t.album_image);return [{id:'jamendo:'+t.id,type:'jamendo',title:String(t.name).slice(0,300),artist:String(t.artist_name||'Jamendo').slice(0,200),src:u.href,art:art?.href||'',duration:Number(t.duration)||0,meta:fmt(Number(t.duration)||0),sourceUrl:page?.href||'https://www.jamendo.com/track/'+encodeURIComponent(String(t.id)),license:String(t.license_ccurl||''),fullStream:true}]});
}
async function searchJamendo(query,id=Connections.jamendoId){return id?jamendoTracks(await jamendoRequest(query,id)):[]}
function jamendoStatus(text,state=''){const el=$('#jamendoStatus');el.textContent=text;el.dataset.state=state}
$('#jamendoId').value=Connections.jamendoId;if(Connections.jamendoId)jamendoStatus('Client ID сохранён. Ответ сервиса ещё не проверен.');
$('#jamendoSave').onclick=()=>{try{Connections.jamendoId=jamendoId($('#jamendoId').value);store.set('jamendoId',Connections.jamendoId);$('#jamendoId').value=Connections.jamendoId;resetJadeSearch();jamendoStatus('Сохранён для общего поиска. Нажми «Проверить».')}catch(e){jamendoStatus(e.message,'error')}};
let jamendoCheckToken=0;
$('#jamendoTest').onclick=async()=>{const token=++jamendoCheckToken;let id;try{id=jamendoId($('#jamendoId').value)}catch(e){jamendoStatus(e.message,'error');return}const b=$('#jamendoTest');b.disabled=true;jamendoStatus('Проверяем Jamendo…');try{const tracks=await searchJamendo($('#q').value.trim()||'jazz',id);if(token!==jamendoCheckToken)return;jamendoStatus('Ответ корректен. Аудиоссылок: '+tracks.length+'. '+(id===Connections.jamendoId?'Источник сохранён.':'Нажми «Сохранить», чтобы подключить.')+' Воспроизведение каждой ссылки отдельно не проверялось.','ok')}catch(e){if(token===jamendoCheckToken)jamendoStatus(e.name==='AbortError'?'Jamendo не ответил вовремя.':e.message||'Ошибка сети.','error')}finally{if(token===jamendoCheckToken)b.disabled=false}};
$('#jamendoDisable').onclick=()=>{jamendoCheckToken++;$('#jamendoTest').disabled=false;Connections.jamendoId='';store.set('jamendoId','');$('#jamendoId').value='';resetJadeSearch();jamendoStatus('Не подключён. Нужен свой Client ID.')};
/* User-specified public Hitmoz Parser. Search availability is not an audio access guarantee. */
const hitmozPending=new Map();
window.__lumenHitmozResult=(id,payload)=>{const p=hitmozPending.get(id);if(!p)return;hitmozPending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.connectorError)throw new Error(j.connectorError);p.resolve(j)}catch(e){p.reject(e)}};
async function hitmozRequest(query){
 if(window.LumenNative?.searchHitmoz)return new Promise((resolve,reject)=>{const id='hm-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{hitmozPending.delete(id);reject(new Error('Hitmoz не ответил'))},13000);hitmozPending.set(id,{resolve,reject,timer});try{LumenNative.searchHitmoz(String(query).slice(0,200),id)}catch(e){clearTimeout(timer);hitmozPending.delete(id);reject(e)}});
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),11000);try{const r=await fetch('https://bakha.me/?search='+encodeURIComponent(String(query).slice(0,200)),{signal:controller.signal,credentials:'omit',headers:{Accept:'application/json'}});if(!r.ok)throw new Error('Hitmoz HTTP '+r.status);const text=await r.text();if(text.length>2000000)throw new Error('Слишком большой ответ Hitmoz');return JSON.parse(text)}finally{clearTimeout(timer)}
}
function hitmozTracks(j){
 if(j?.success!==true||!Array.isArray(j.songs))throw new Error('Hitmoz не вернул список треков');
 return j.songs.slice(0,120).flatMap(t=>{const url=publicHttps(t.download);if(!url||!t.title||!t.artist||!/\.mp3$/i.test(url.pathname)||t.isPreview===true||t.is_preview===true||t.is_full===false||/(^|[\W_])(preview|snippet|teaser|excerpt)([\W_]|$)/i.test(t.title+' '+url.pathname))return [];const art=publicHttps(t.cover),link=publicHttps(t.link);const duration=/^\d+:\d{2}$/.test(t.duration||'')?String(t.duration).split(':').reduce((n,x)=>n*60+Number(x),0):0;return [{id:'hitmoz:'+(link?.href||url.href),type:'hitmoz',title:String(t.title).slice(0,300),artist:String(t.artist).slice(0,200),src:url.href,art:art?.href||'',sourceUrl:link?.href||'https://bakha.me/hitmoz.php',duration,meta:duration?fmt(duration):'',audioVerified:false,fullStream:true}]});
}
/* Hitmoz files are also served from the main site ru.hitmoz.org (same path) — downloads try it first */
const hitmozAlt=u=>'';const hitmozAltUnused=u=>/^https?:\/\/[^/]*hitmoz\.[a-z]+\//i.test(u||'')&&!/^https:\/\/ru\.hitmoz\.org\//i.test(u)?String(u).replace(/^https?:\/\/[^/]+/i,'https://ru.hitmoz.org'):'';
window.hitmozAlt=hitmozAlt;
const isHitmoz=(t,u)=>t?.type==='hitmoz'||/^https?:\/\/[^/]*hitmoz\./i.test(u||t?.src||'');window.isHitmoz=isHitmoz;
async function searchHitmoz(query){return hitmozTracks(await hitmozRequest(query))}
function syncHitmoz(){const enabled=Connections.hitmozEnabled;$('#hitmozEnabled').checked=enabled;$('#hitmozStatus').textContent=enabled?'Поиск подключён. Доступ к MP3 может быть ограничен источником.':'Hitmoz выключен. Остальные источники работают.'}
$('#hitmozEnabled').onchange=e=>{Connections.hitmozEnabled=e.target.checked;store.set('hitmozEnabled',Connections.hitmozEnabled);resetJadeSearch();syncHitmoz()};syncHitmoz();
