'use strict';
/* 6.5.4: the app updates itself — new screens/features download from the site in the background;
   a new Android part = one tap «Обновить» in the system dialog; the website updates by itself anyway. */
(function(){
  const N=window.LumenNative;if(!N||typeof N.webUpdate!=='function')return;
  /* 6.5.5 mirrors: GitHub via jsDelivr → GitHub raw → Netlify; the first that answers wins (every file is checked by SHA-256) */
  const C=window.LAZZY_CONFIG||{},repo=String(C.updateRepo||'').trim(),br=C.updateBranch||'main';
  const BASES=[...(repo?['https://cdn.jsdelivr.net/gh/'+repo+'@'+br+'/','https://raw.githubusercontent.com/'+repo+'/'+br+'/']:[]),...[].concat(C.updateBase||'https://lazzysound.netlify.app/')];
  const pend=new Map();
  window.__lazzyUpdate=(id,p)=>{const f=pend.get(id);if(f){pend.delete(id);try{f(JSON.parse(p))}catch{f({error:'?'})}}};
  const call=(m,a)=>new Promise(res=>{const id='up'+Date.now()+Math.random().toString(36).slice(2,6);pend.set(id,res);setTimeout(()=>{if(pend.delete(id))res({error:'timeout'})},300000);try{N[m](...a,id)}catch(e){pend.delete(id);res({error:e.message})}});
  const started=Date.now();let busy=false,told='';
  function sheetApk(r){
    openSheet({title:'Новая версия '+r.v,sub:'Обновление приложения',tracks:[],cover:{title:'↑'}});$('#sheet').dataset.mode='ask';$('#sheetList').innerHTML='';
    $('#sheetActions').innerHTML=`<div class="wave-tune"><p class="settings-help">Всё сохранится: избранное, плейлисты и настройки. Android попросит один раз нажать «Обновить».</p><div class="api-actions"><button class="btn-accent" id="upGo">Обновить</button><button class="chip" id="upLater">Позже</button></div><p class="api-status" id="upSt"></p></div>`;
    $('#upLater').onclick=()=>{store.set('upSkip',r.v);closeSheet()};
    $('#upGo').onclick=async()=>{const st=$('#upSt'),b=$('#upGo');b.disabled=true;st.textContent='Скачиваем…';
      const x=await call('installApk',[r.apk]);b.disabled=false;
      st.textContent=x.started?'Подтверди установку в окне Android':x.allow?'Разреши установку для Lazzy sound и нажми «Обновить» ещё раз':'Не получилось: '+(x.error||'?')};
  }
  async function check(manual){
    if(busy)return;busy=true;
    try{let r={error:'no mirror'};for(const b of BASES){r=await call('webUpdate',[b]);if(!r.error)break}
      if(r.updated){
        if(Date.now()-started<90000&&(typeof audio==='undefined'||audio.paused)){toast('Lazzy sound обновлён до '+r.v);setTimeout(()=>location.reload(),1500)}
        else if(told!==r.v){told=r.v;toast('Обновление '+r.v+' готово — применится при следующем запуске')}
      }else if(r.needApk&&r.apk&&typeof N.installApk==='function'){if(manual||store.get('upSkip','')!==r.v)sheetApk(r)}
      else if(r.needPc){if(manual||store.get('upSkip','')!==r.v){store.set('upSkip',r.v);const t=(window.LAZZY_CONFIG||{}).ownerTelegram;toast('Вышла новая версия для ПК '+r.v+(t?' — ссылка в нашем Telegram':''))}}
      else if(manual)toast(r.latest?'У тебя последняя версия'+(r.v?' '+r.v:''):'Не удалось проверить обновления');
    }finally{busy=false}
  }
  window.lazzyCheckUpdate=()=>check(true);
  setTimeout(()=>check(false),6000);setInterval(()=>check(false),6*3600e3);
  /* «Проверить обновления» under the version line */
  const v=document.querySelector('.profile-version');
  if(v&&!document.getElementById('upCheck')){v.insertAdjacentHTML('afterend','<div class="api-actions" style="justify-content:center"><button class="chip" id="upCheck">Проверить обновления</button></div>');$('#upCheck').onclick=()=>check(true)}
})();
