'use strict';
/* Lazzy sound 5.0 — window.LumenNative for PC / iPhone: the same bridge, served by desktop/server.js over HTTP. */
(function(){
  if(window.LumenNative||location.host==='appassets.androidplatform.net'||!/^https?:$/.test(location.protocol))return;
  const lzToast=m=>{try{if(typeof toast==='function')toast(m)}catch{}};
  let key='';try{const q=new URLSearchParams(location.search).get('k');if(q){localStorage.setItem('lazzyKey',q);history.replaceState(null,'',location.pathname)}key=localStorage.getItem('lazzyKey')||''}catch{}
  function sync(m,a){const x=new XMLHttpRequest();x.open('POST','/__bridge',false);x.setRequestHeader('Content-Type','application/json');x.setRequestHeader('X-Lazzy-Key',key);x.send(JSON.stringify({m,a}));if(x.status!==200)throw new Error('bridge '+x.status);return JSON.parse(x.responseText).v}
  let ping=null;try{ping=sync('ping',[])}catch{}
  if(!ping)return;
  window.LAZZY_HOST={platform:ping.platform,auth:ping.auth};
  if(ping.desktop){const m=document.createElement('meta');m.name='referrer';m.content='no-referrer';document.head.appendChild(m)}
  if(!ping.auth){document.addEventListener('DOMContentLoaded',()=>setTimeout(()=>lzToast('Открой ссылку с ключом, которую показывает Lazzy sound на ПК'),1500));}
  window.LAZZY_OFFLINE_BASE=location.origin+'/offline/';window.LAZZY_OFFLINE_Q='?k='+encodeURIComponent(key);
  const post=(m,a)=>fetch('/__bridge',{method:'POST',headers:{'Content-Type':'application/json','X-Lazzy-Key':key},body:JSON.stringify({m,a})}).then(r=>r.json()).then(j=>j.p).catch(()=>'{"error":"Нет связи с Lazzy sound на ПК","connectorError":"unavailable"}');
  const N={};
  const ASYNC={webUpdate:'__lazzyUpdate',publicCatalog:'__lazzyCatalog',musicBrainz:'__lumenMusicBrainzResult',searchAudius:'__lumenAudiusResult',searchHitmoz:'__lumenHitmozResult',searchJamendo:'__lumenJamendoResult',searchJade:'__lumenJadeResult',searchCcMixter:'__lumenCcMixterResult',
    googleToken:'__lazzyGoogle',googleIdToken:'__lazzyGoogle',audiusGet:'__lazzyAudius',resolveStream:'__lazzyResolved',soundcloudGet:'__lazzySC',spotifySignIn:'__lazzySpotify',spotifyToken:'__lazzySpotify',offlineSave:'__lazzyOffline',aiRequest:'__lazzyAi',aiVision:'__lazzyAi',asrWords:'__lazzyAsr',lrclibPost:'__lazzyLrc',yandexApi:'__lazzyYM'};
  for(const [m,cb] of Object.entries(ASYNC))N[m]=(...a)=>{const id=a[a.length-1];post(m,a.slice(0,-1)).then(p=>{try{window[cb]?.(id,p)}catch(e){console.error(e)}})};
  N.googleSignIn=(...a)=>{lzToast('Вход через Google откроется в браузере на ПК');post('googleSignIn',a).then(p=>window.__lazzyGoogle?.('signin',p))};
  for(const m of ['googleProfile','googleSignOut','spotifySignOut','isMetered','offlineHas','offlineRemove','saveAiKey','hasAiKey','saveYandexToken','hasYandexToken','saveAsrKey','hasAsrKey','deviceInfo','getAppIcon','setAppIcon'])N[m]=(...a)=>sync(m,a);
  N.setAppearance=()=>{};N.setRefreshMode=()=>{};N.mediaState=ping.desktop?k=>{post('mediaState',[k])}:()=>{};
  N.shareText=(title,text)=>{if(navigator.share)navigator.share({title,text}).catch(()=>{});else navigator.clipboard?.writeText(text).then(()=>lzToast('Скопировано'))};
  /* 10 ms vocal-band envelope (same filter as Android EnvAcc), decoded with Web Audio via the host proxy */
  let ctx=null;
  async function envelope(url){
    const buf=await (await fetch(url.startsWith(location.origin)?url:'/__proxy?url='+encodeURIComponent(url)+'&k='+encodeURIComponent(key))).arrayBuffer();
    ctx=ctx||new (window.AudioContext||window.webkitAudioContext)();
    const ab=await new Promise((res,rej)=>{const p=ctx.decodeAudioData(buf,res,rej);if(p&&p.then)p.then(res,rej)});
    const rate=ab.sampleRate,ch=ab.numberOfChannels,data=[];for(let c=0;c<ch;c++)data.push(ab.getChannelData(c));
    const dt=1/rate,rcH=1/(2*Math.PI*150),rcL=1/(2*Math.PI*4000),aH=rcH/(rcH+dt),aL=dt/(rcL+dt),hop=Math.max(1,Math.floor(rate/100));
    const n=Math.min(ab.length,rate*900),out=new Uint8Array(Math.ceil(n/hop));let hp=0,px=0,lp=0,acc=0,k=0,o=0;
    for(let i=0;i<n;i++){let x=0;for(let c=0;c<ch;c++)x+=data[c][i];x/=ch;const h=aH*(hp+x-px);px=x;hp=h;lp+=aL*(h-lp);acc+=lp*lp;
      if(++k>=hop){const db=20*Math.log10(Math.sqrt(acc/k)+1e-6);out[o++]=Math.max(0,Math.min(255,Math.round((db+60)*255/60)));acc=0;k=0}
      if((i&262143)===0)await new Promise(z=>setTimeout(z,0))}
    let s='';const b=out.subarray(0,o);for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode.apply(null,b.subarray(i,i+8192));return btoa(s);
  }
  N.analyzeAudio=(url,k,id)=>{(async()=>{const ck=k||url;let d='';try{d=sync('envGet',[ck])}catch{}
    if(!d){d=await envelope(url);try{post('envPut',[ck,d])}catch{}}return JSON.stringify({hop:0.01,data:d})})().catch(()=>'{"error":"unavailable"}').then(p=>window.__lazzyEnv?.(id,p))};
  if(ping.desktop)document.addEventListener('DOMContentLoaded',()=>{const a=document.getElementById('offlineSettings');if(!a)return;const g=document.createElement('div');g.className='settings-group';
    g.innerHTML='<div class="setting-title"><svg><use href="#i-external"/></svg><h2>Lazzy sound на телефоне</h2></div><p class="settings-help">Открыть эту же библиотеку на iPhone или другом телефоне в той же Wi-Fi сети. Сочетания: Ctrl+Shift+P — эта ссылка, F12 — во весь экран.</p><div class="api-actions"><button class="btn-accent" id="pcShare">Показать ссылку</button></div>';
    a.parentNode.insertBefore(g,a);g.querySelector('#pcShare').onclick=()=>post('shareToPhone',[])});
  window.LumenNative=N;
})();
