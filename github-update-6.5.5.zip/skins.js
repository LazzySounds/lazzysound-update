'use strict';
/* Interface designs: Liquid Glass (ours), Apple Music, Material You, Stream, Minimal. */
const SKINS={
  liquid:{n:'Liquid',d:'Наш, стеклянный',acc:'tide'},
  apple:{n:'Apple',d:'Как Apple Music',acc:'red'},
  material:{n:'Material',d:'Material You',acc:'auto'},
  stream:{n:'Стрим',d:'Тёмный, плотный',acc:'green'},
  mono:{n:'Минимал',d:'Только главное',acc:'mono'}
};
let Skin=store.get('skin','liquid');if(!SKINS[Skin])Skin='liquid';
function applySkin(){
  const r=document.documentElement;r.dataset.skin=Skin;if(Skin==='liquid')delete r.dataset.solid;else r.dataset.solid='1';
  requestAnimationFrame(()=>dispatchEvent(new Event('resize')));
}
function renderSkinPicker(){
  const host=$('#skinChoices');if(!host)return;
  host.innerHTML=Object.entries(SKINS).map(([k,s])=>`<button class="sk-card${k===Skin?' on':''}" data-skin="${k}" aria-pressed="${k===Skin}"><span class="sk-prev sk-${k}" aria-hidden="true"><i class="sk-h"></i><i class="sk-g"><i></i><i></i><i></i><i></i></i><i class="sk-m"><i></i></i><i class="sk-t"><i></i><i></i><i></i><i></i></i></span><b>${s.n}</b><small>${s.d}</small><svg class="sk-ok"><use href="#i-check"/></svg></button>`).join('');
  host.onclick=e=>{const b=e.target.closest('[data-skin]');if(!b||b.dataset.skin===Skin)return;Skin=b.dataset.skin;store.set('skin',Skin);
    if(SKINS[Skin].acc&&typeof ACCENTS!=='undefined'&&ACCENTS[SKINS[Skin].acc]){Prefs.accent=SKINS[Skin].acc;saveProfile()}
    applySkin();host.querySelectorAll('.sk-card').forEach(c=>{const on=c.dataset.skin===Skin;c.classList.toggle('on',on);c.setAttribute('aria-pressed',String(on))})};
}
applySkin();renderSkinPicker();
$('#resetAppearance')?.addEventListener('click',()=>{Skin='liquid';store.set('skin',Skin);applySkin();renderSkinPicker()});
