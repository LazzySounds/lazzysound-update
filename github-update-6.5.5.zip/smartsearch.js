'use strict';
/* Lazzy sound 3.1 — search that understands typos.
   Three layers, so it works even when one is unavailable:
   1. Local: fuzzy ranking (trigrams + edit distance), Cyrillic↔Latin transliteration, wrong keyboard layout.
   2. Catalogue: iTunes song search (US + KZ stores) is typo-tolerant and free — used for "did you mean" and autocomplete.
   3. AI: the user's key or free Pollinations (≈1 reply / 30 s) rewrites the query, understands descriptions.
   Corrected queries are searched in the real sources; nothing is invented. */

/* ---------- Text helpers ---------- */
const CYR='абвгдеёжзийклмнопрстуфхцчшщъыьэюя',LAT=['a','b','v','g','d','e','e','zh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','kh','ts','ch','sh','sch','','y','','e','yu','ya'];
const translit=s=>String(s||'').toLowerCase().split('').map(c=>{const i=CYR.indexOf(c);return i<0?c:LAT[i]}).join('');
const RU_KEYS='йцукенгшщзхъфывапролджэячсмитьбю.',EN_KEYS="qwertyuiop[]asdfghjkl;'zxcvbnm,./";
function swapLayout(s){const t=String(s||'').toLowerCase();let out='',ru=0,en=0;for(const c of t){let i=RU_KEYS.indexOf(c);if(i>=0&&/[а-яё]/.test(c)){out+=EN_KEYS[i];ru++;continue}i=EN_KEYS.indexOf(c);if(i>=0&&/[a-z\[\];',.]/.test(c)){out+=RU_KEYS[i];en++;continue}out+=c}return ru||en?out:''}
const hasCyr=s=>/[а-яё]/i.test(s);
const norm=s=>normalize(s);
function grams(s){s=' '+norm(s)+' ';const g=new Map();for(let i=0;i<s.length-2;i++){const k=s.slice(i,i+3);g.set(k,(g.get(k)||0)+1)}return g}
function dice(a,b){if(!a||!b)return 0;const A=grams(a),B=grams(b);let inter=0,na=0,nb=0;for(const v of A.values())na+=v;for(const v of B.values())nb+=v;for(const [k,v] of A)if(B.has(k))inter+=Math.min(v,B.get(k));return na+nb?2*inter/(na+nb):0}
function lev(a,b,max=2){if(Math.abs(a.length-b.length)>max)return max+1;let prev=Array.from({length:b.length+1},(_,i)=>i);for(let i=1;i<=a.length;i++){const cur=[i];let best=i;for(let j=1;j<=b.length;j++){cur[j]=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));best=Math.min(best,cur[j])}if(best>max)return max+1;prev=cur}return prev[b.length]}
/* How well a candidate string matches a query, 0…1, tolerant to typos and script. */
function similarity(query,text){
  const q=norm(query),t=norm(text);if(!q||!t)return 0;
  if(t===q)return 1;
  const qa=translit(q),ta=translit(t);
  let s=Math.max(dice(q,t),dice(qa,ta)*.96);
  const qw=qa.split(' ').filter(w=>w.length>1),tw=ta.split(' ').filter(Boolean);
  if(qw.length){let hit=0;for(const w of qw){if(tw.some(x=>x===w||x.startsWith(w)&&w.length>=3||(w.length>=4&&lev(w,x,w.length>6?2:1)<=(w.length>6?2:1))))hit++}s=Math.max(s,hit/qw.length*.92)}
  return s;
}

/* ---------- Better ranking for every merge (also used by album track matching) ---------- */
mergeSearchResults=function(items,queries){
  const qs=(Array.isArray(queries)?queries:[queries]).filter(Boolean);
  const groups=new Map();
  const quality=t=>t.type==='local'?8:['hitmoz','jamendo','jade','audius','commons','ccmixter','archive'].includes(t.type)&&t.src?7:t.src&&t.type!=='radio'?6:t.type==='radio'?2:t.type==='album'?1:0;
  for(const raw of items.filter(isUsableEntry)){
    const t={...raw};const kind=groupOf(t);const key=kind==='radio'||kind==='catalog'?t.id:norm(t.artist)+'|'+norm(t.title);
    const label=PROVIDER_LABELS[t.type==='album'?'archive':t.type]||t.type;const old=groups.get(key);
    if(!old){t.providers=[label];groups.set(key,t)}else{const providers=[...new Set([...old.providers,label])];if(quality(t)>quality(old))groups.set(key,{...t,providers});else old.providers=providers}
  }
  return [...groups.values()].map(t=>{let best=0;qs.forEach((q,i)=>{const w=i===0?1:.97;best=Math.max(best,w*Math.max(similarity(q,t.title+' '+t.artist),similarity(q,t.artist+' '+t.title),similarity(q,t.title)*.95,similarity(q,t.artist)*.8))});
    return {...t,_rank:best*100+quality(t)+(t.type==='radio'?-10:0)}}).filter(t=>t._rank>12||qs.length===0).sort((a,b)=>b._rank-a._rank||a.title.localeCompare(b.title));
};

/* ---------- Catalogue hints (iTunes, free) ---------- */
const hintCache=new Map();
async function catalogSongs(q,country){
  const k=country+'|'+norm(q);if(hintCache.has(k))return hintCache.get(k);
  const p=bounded(publicCatalog('songs',{q:q.slice(0,200),country}),9000).then(j=>(j.results||[]).filter(x=>x.kind==='song'&&x.trackName&&x.artistName).map(x=>({artist:x.artistName,title:String(x.trackName).replace(/\s*\((feat|with)\.?[^)]*\)/i,'').trim(),art:/^https:\/\//.test(x.artworkUrl100||'')?x.artworkUrl100.replace('100x100bb','300x300bb'):'',duration:(x.trackTimeMillis||0)/1000,album:x.collectionName||''}))).catch(()=>[]);
  hintCache.set(k,p);if(hintCache.size>120)hintCache.delete(hintCache.keys().next().value);return p;
}
async function catalogHints(q){
  const tries=[catalogSongs(q,'US'),catalogSongs(q,'KZ')];
  if(hasCyr(q))tries.push(catalogSongs(translit(q),'US'));
  let list=(await Promise.all(tries)).flat();
  if(!list.length){const sw=swapLayout(q);if(sw&&sw!==norm(q))list=(await Promise.all([catalogSongs(sw,'US'),catalogSongs(sw,'KZ')])).flat()}
  const seen=new Set();return list.filter(h=>{const k=norm(h.artist)+'|'+norm(h.title);if(seen.has(k))return false;seen.add(k);return true}).map(h=>({...h,score:Math.max(similarity(q,h.artist+' '+h.title),similarity(q,h.title+' '+h.artist),similarity(q,h.artist)*.9)})).sort((a,b)=>b.score-a.score).slice(0,8);
}

/* ---------- AI rewrite (cached) ---------- */
const FIX_SYSTEM='Ты исправляешь поисковые запросы музыкального плеера. Пользователь мог ошибиться в написании, транслитерации или раскладке клавиатуры, написать часть строки из песни или описать музыку словами. Ответь только JSON без пояснений: {"fixed":"Исполнитель Название" или "Исполнитель" или жанр,"alts":["до 3 других вероятных вариантов"],"type":"track|artist|genre|mood"}. Пиши названия так, как они записаны в стримингах: зарубежные латиницей, русскоязычные как принято у артиста (например, Скриптонит, Miyagi & Andy Panda). Если запрос уже правильный — верни его без изменений. Для описаний настроения верни жанр или конкретных исполнителей на английском.';
const fixCache=store.get('aifix',{});
async function aiFix(q){
  const k=norm(q);if(fixCache[k])return fixCache[k];
  if(typeof aiReady!=='function'||!aiReady()||store.get('aiSearch',true)===false)return null;
  const j=aiJSON(await aiAsk(FIX_SYSTEM,'Запрос: «'+q.slice(0,200)+'»'));
  const clean=x=>typeof x==='string'?x.replace(/\s+/g,' ').trim().slice(0,120):'';
  const out={fixed:clean(j.fixed),alts:(Array.isArray(j.alts)?j.alts:[]).map(clean).filter(Boolean).slice(0,3),type:String(j.type||'')};
  if(!out.fixed)return null;
  fixCache[k]=out;const keys=Object.keys(fixCache);if(keys.length>200)delete fixCache[keys[0]];store.set('aifix',fixCache);return out;
}

/* ---------- Source fan-out (shared by the main query and corrected ones) ---------- */
function sourceJobs(query,{withLocal=true,withCatalog=true,withRadio=true}={}){
  const jobs=[];
  if(withCatalog)jobs.push(['albumCatalog',()=>searchAlbumCatalog(query)]);
  jobs.push(['audius',()=>searchAudius(query)],['archive',()=>searchArchive(query)],['commons',()=>searchCommons(query)],['ccmixter',()=>searchCcMixter(query)]);
  if(withRadio)jobs.push(['radio',()=>searchRadio({name:query})]);
  if(withLocal)jobs.push(['local',async()=>{const all=await DB.all();return all.filter(t=>similarity(query,t.title+' '+t.artist)>.45).map(({blob,...t})=>t)}]);
  if(typeof SC!=='undefined'&&SC.id)jobs.unshift(['soundcloud:'+SC.id,()=>searchSoundCloud(query)]);
  if(typeof Connections!=='undefined'){
    if(Connections.jadeEndpoint){const e=Connections.jadeEndpoint;jobs.unshift(['jade:'+e,()=>searchJade(query,e)])}
    if(Connections.jamendoId){const id=Connections.jamendoId;jobs.unshift(['jamendo:'+id,()=>searchJamendo(query,id)])}
    if(Connections.hitmozEnabled)jobs.unshift(['hitmoz',()=>searchHitmoz(query)]);
  }
  return jobs;
}

/* ---------- The search itself ---------- */
let Smart={token:0,queries:[],gathered:[],extraDone:new Set(),pending:0};
function remerge(){mergedResults=mergeSearchResults(Smart.gathered,Smart.queries);renderMergedSearch()}
function runSources(query,token,opts){
  const jobs=sourceJobs(query,opts);Smart.pending+=jobs.length;let failed=0;
  return Promise.all(jobs.map(async([source,fn])=>{
    try{const data=source==='local'?await fn():await cachedSearch(source,query,fn);if(token!==searchGeneration)return;Smart.gathered.push(...data.slice(0,120))}
    catch{failed++}
    if(token!==searchGeneration)return;Smart.pending--;remerge();progressText();
  })).then(()=>failed);
}
function progressText(){
  const n=mergedResults.length;$('#searchProgress').textContent=Smart.pending>0?`Ищем… ${n} найдено`:`Найдено: ${n}`;
  $('#searchHint').textContent=Smart.pending>0?'Результаты дополняются — уже можно слушать.':Smart.queries.length>1?'Учли возможные опечатки: искали и по исправленному запросу.':'Поиск завершён. Повторы объединены.';
}
doSearch=async function(opts){const auto=!!opts?.auto;
  clearTimeout(st);if(!auto)hideSuggest();const query=$('#q').value.trim(),token=++searchGeneration;
  $('#searchSuggestions').hidden=!!query;$('#searchMore').hidden=!query;$('#didYouMean').innerHTML='';
  if(!query){clearSearch();return}
  if(query.length<2){mergedResults=[];$('#searchProgress').textContent='Введи запрос';$('#searchList').innerHTML='<div class="empty">Введи хотя бы два символа.</div>';return}
  Smart={token,queries:[query],gathered:[],extraDone:new Set([norm(query)]),pending:0};
  mergedResults=[];loading($('#searchList'));$('#searchProgress').textContent='Ищем…';$('#searchHint').textContent='Ищем во всех источниках сразу и проверяем опечатки.';
  const main=runSources(query,token);
  smartCorrect(query,token,auto);
  await main;
};

/* Decide which corrected queries are worth searching, then search them too. */
async function smartCorrect(query,token,auto){
  const offers=[];const add=(q,from)=>{q=String(q||'').trim();if(!q||q.length<2)return;const k=norm(q);if(Smart.extraDone.has(k)||offers.some(o=>norm(o.q)===k))return;offers.push({q,from})};
  const hintsP=catalogHints(query).catch(()=>[]);
  const fixAI=()=>aiFix(query).catch(e=>{if(e.rateLimit)Smart.aiLimited=e.rateLimit;return null});
  let aiP=auto?null:fixAI();
  const hints=await hintsP;if(token!==searchGeneration)return;
  const strong=hints.filter(h=>h.score>=.42);
  if(auto)aiP=strong.length?Promise.resolve(fixCache[norm(query)]||null):fixAI();
  if(strong[0]){const h=strong[0];const artistOnly=similarity(query,h.artist)>=similarity(query,h.artist+' '+h.title)+.05;add(artistOnly?h.artist:h.artist+' '+h.title,'catalog');if(strong[1]&&norm(strong[1].artist)!==norm(h.artist))add(strong[1].artist+' '+strong[1].title,'catalog')}
  showDidYouMean(query,offers,hints);searchOffers(offers.slice(0,2),token);
  const ai=await aiP;if(token!==searchGeneration)return;
  const before=offers.length;
  if(ai){add(ai.fixed,'ai');ai.alts.forEach(a=>add(a,'ai'))}
  showDidYouMean(query,offers,hints);
  searchOffers(offers.slice(before).slice(0,2),token);
}
function searchOffers(list,token){
  for(const o of list){if(Smart.extraDone.has(norm(o.q)))continue;Smart.extraDone.add(norm(o.q));Smart.queries.push(o.q);runSources(o.q,token,{withLocal:false,withCatalog:false,withRadio:false})}
}
function showDidYouMean(query,offers,hints){
  const el=$('#didYouMean');if(!el)return;
  const chips=offers.slice(0,4);const more=hints.filter(h=>h.score>=.3&&!chips.some(c=>norm(c.q)===norm(h.artist+' '+h.title))).slice(0,4);
  if(!chips.length&&!more.length){el.innerHTML='';return}
  el.innerHTML=`${chips.length?`<p class="dym-label"><span class="ai-dot"></span>${chips.every(c=>c.from==='ai')?'ИИ понял запрос так':'Возможно, ты искал'}</p><div class="dym-row">${chips.map((c,i)=>`<button class="dym-chip${c.from==='ai'?' ai':''}" data-dym="${i}">${esc(c.q)}</button>`).join('')}</div>`:''}${more.length?`<p class="dym-label">Похожие песни из каталога</p><div class="dym-songs">${more.map((h,i)=>`<button class="dym-song" data-hint="${i}">${h.art?`<span class="cover" style="background-image:url('${esc(h.art)}')"></span>`:coverHTML({title:h.title,artist:h.artist})}<span><b>${esc(h.title)}</b><small>${esc(h.artist)}</small></span></button>`).join('')}</div>`:''}${Smart.aiLimited&&!aiHasKey()?`<p class="dym-note">Бесплатный ИИ отдыхает ${Smart.aiLimited} с — пока помогает каталог.</p>`:''}`;
  el.onclick=e=>{const c=e.target.closest('[data-dym]');if(c){$('#q').value=chips[+c.dataset.dym].q;doSearch();return}const h=e.target.closest('[data-hint]');if(h){const x=more[+h.dataset.hint];chooseFullTrack({id:'hint:'+x.artist+'|'+x.title,type:'catalogTrack',title:x.title,artist:x.artist,duration:x.duration,art:x.art,albumName:x.album})}};
}

/* ---------- Autocomplete while typing (catalogue only — no AI quota spent) ---------- */
let suggestTimer=0,suggestToken=0;
function hideSuggest(){const b=$('#suggestBox');if(b){b.hidden=true;b.innerHTML=''}}
$('#q').addEventListener('input',()=>{clearTimeout(suggestTimer);const q=$('#q').value.trim();if(q.length<2){hideSuggest();return}
  const token=++suggestToken;suggestTimer=setTimeout(async()=>{const hints=await catalogHints(q);if(token!==suggestToken||$('#q').value.trim()!==q||document.activeElement!==$('#q'))return;
    const rows=hints.slice(0,6);if(!rows.length){hideSuggest();return}const b=$('#suggestBox');
    b.innerHTML=rows.map((h,i)=>`<button data-sg="${i}"><svg><use href="#i-search"/></svg><span><b>${esc(h.title)}</b><small>${esc(h.artist)}</small></span></button>`).join('');b.hidden=false;
    b.onmousedown=e=>e.preventDefault();
    b.onclick=e=>{const r=e.target.closest('[data-sg]');if(!r)return;const h=rows[+r.dataset.sg];$('#q').value=h.artist+' '+h.title;$('#q').blur();doSearch()};
  },380)});
$('#q').addEventListener('blur',()=>setTimeout(hideSuggest,150));

/* ---------- 3.3: artist cards on top of results — tap opens the artist with all tracks ---------- */
async function artistHits(q,token){
  const el=$('#artistHits');if(!el)return;el.innerHTML='';
  const [users,hints]=await Promise.all([
    (typeof audiusApi==='function'?audiusApi('/v1/users/search?query='+encodeURIComponent(q.slice(0,80))+'&limit=8').then(j=>j.data||[]):Promise.resolve([])).catch(()=>[]),
    catalogHints(q).catch(()=>[])]);
  if(token!==searchGeneration)return;
  const list=[];
  const h=hints.find(x=>similarity(q,x.artist)>.72);
  if(h)list.push({name:h.artist,art:h.art,sub:'Исполнитель'});
  users.filter(u=>similarity(q,u.name||'')>.6||similarity(q,u.handle||'')>.72).sort((a,b)=>(b.follower_count||0)-(a.follower_count||0)).slice(0,4).forEach(u=>{
    if(list.some(x=>norm(x.name)===norm(u.name))){const x=list.find(x=>norm(x.name)===norm(u.name));Object.assign(x,{artistId:u.id,handle:u.handle,sub:'Исполнитель · '+compactNum(u.follower_count||0)+' подписчиков',art:(u.profile_picture?.['150x150']||'').startsWith('https://')?u.profile_picture['150x150']:x.art});return}
    const pic=u.profile_picture?.['150x150']||'';list.push({name:u.name,artistId:u.id,handle:u.handle,art:pic.startsWith('https://')?pic:'',sub:'Audius · '+compactNum(u.follower_count||0)+' подписчиков'})});
  if(!list.length)return;
  el.innerHTML=`<div class="artist-hits">${list.slice(0,5).map((a,i)=>`<button class="artist-hit glass" data-ah="${i}">${a.art?`<span class="cover round" style="background-image:url('${esc(a.art)}')"></span>`:`<span class="cover round">${esc((a.name||'?')[0].toUpperCase())}</span>`}<span class="ah-copy"><b>${esc(a.name)}</b><small>${esc(a.sub)}</small></span><svg class="chev"><use href="#i-chev"/></svg></button>`).join('')}</div>`;
  el.onclick=e=>{const b=e.target.closest('[data-ah]');if(b)openArtist(list[+b.dataset.ah])};
}
const baseDoSearch=doSearch;
doSearch=async function(opts){const q=$('#q').value.trim();if(q.length<2){$('#artistHits').innerHTML='';return baseDoSearch(opts)}const p=baseDoSearch(opts);artistHits(q,searchGeneration);return p};

/* ---------- 4.0: calmer search UI ---------- */
(function(){
  const view=$('[data-view="search"]'),list=$('#searchList');
  const state=()=>{view.dataset.state=$('#q').value.trim().length>=2?'results':'idle'};
  $('#q').addEventListener('input',state);state();
  /* AI ideas card lives under the results, not between them */
  const tools=$('.discovery-tools'),ideas=$('#aiSuggestions');if(tools&&list){list.after(tools);tools.after(ideas)}
  /* batch result re-renders while sources keep answering (no row shuffling every few ms) */
  const base=renderMergedSearch;let t=0,again=false;
  renderMergedSearch=function(){if(t){again=true;return}base();t=setTimeout(()=>{t=0;if(again){again=false;base()}},320)};
  /* suggestions: close on scroll / tap outside, never reopen for the query already searched by Enter */
  addEventListener('scroll',()=>{if(!$('#suggestBox').hidden)hideSuggest()},{passive:true});
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('.search-wrap'))hideSuggest()},{passive:true});
})();
/* keyboard: hide bottom bars instead of letting them ride up; ignore the resize-scroll for tab compaction */
(function(){
  let base=innerHeight;const isText=el=>el&&(el.tagName==='TEXTAREA'||(el.tagName==='INPUT'&&!/range|checkbox|radio|file|button/.test(el.type)));
  const check=()=>{const vv=window.visualViewport,h=vv?vv.height:innerHeight;if(!isText(document.activeElement))base=Math.max(base,innerHeight);
    const open=isText(document.activeElement)&&(h<base*.82||innerHeight<base*.82);document.body.classList.toggle('kb-open',open);if(open)window.__kbAt=Date.now()};
  addEventListener('resize',()=>{window.__kbAt=Date.now();check()});window.visualViewport?.addEventListener('resize',check);
  document.addEventListener('focusin',()=>setTimeout(check,350));document.addEventListener('focusout',()=>setTimeout(()=>{check();window.__kbAt=Date.now()},50));
  addEventListener('orientationchange',()=>{base=0;setTimeout(()=>{base=innerHeight},500)});
})();
