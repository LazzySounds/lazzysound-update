'use strict';
/* Lazzy sound 3.2 — motion layer, rewritten for smoothness on phones:
   • only transform/opacity are animated; nothing writes CSS variables on :root per frame;
   • no permanent rAF loops (the wallpaper animates in CSS on the compositor and pauses when hidden);
   • layout is measured only when something actually moved (tab change, resize), never inside observers of the whole tree;
   • springs use WAAPI with a precomputed linear() curve where supported. */
const reducedMotion=()=>document.documentElement.dataset.motion==='reduce'||window.LZ_OSREDUCE===true;
/* On the low tier, decorative extras (row cascades, squish, bursts) are skipped; core transitions stay. */
const liteMotion=()=>reducedMotion()||document.documentElement.dataset.perf==='low';
const EASE_OUT='cubic-bezier(.16,1,.3,1)',EASE_SNAP='cubic-bezier(.2,.9,.25,1)';
/* A real damped spring sampled into CSS linear(): overshoots a little and settles — the "liquid" feel. */
const SPRING=(()=>{const pts=[];let x=0,v=0;const k=210,c=25,dt=1/60;for(let i=0;i<=60;i++){pts.push(+x.toFixed(4));const a=k*(1-x)-c*v;v+=a*dt;x+=v*dt}pts[60]=1;const s=`linear(${pts.join(',')})`;return CSS.supports('transition-timing-function',s)?s:'cubic-bezier(.34,1.35,.5,1)'})();
const full=$('#full'),fullCover=$('#fullCover');

/* ---------- 1. Load: logo wave draws, title rises ---------- */
const boot=()=>requestAnimationFrame(()=>{document.body.classList.remove('booting');document.body.classList.add('booted')});
if($('#intro'))document.addEventListener('lazzy:intro-done',boot,{once:true});else Promise.race([document.fonts?.ready||Promise.resolve(),new Promise(r=>setTimeout(r,450))]).then(boot);
setTimeout(boot,4000);

/* ---------- 2. Liquid drop indicator for the tab bar and segmented controls ---------- */
function slideDrop(host,ind,target,opts={}){
  if(!host||!ind)return;if(!target||!host.getClientRects().length||!target.offsetWidth){ind.style.opacity='0';return}
  /* layout offsets, not screen rects: unaffected by the compact tab bar's scale or a view mid-transition */
  const x=target.offsetLeft,w=target.offsetWidth;
  const prev=ind._pos;ind._pos={x,w};ind.style.opacity='1';
  if(ind.style.width!==w+'px')ind.style.width=w+'px';ind.style.transform=`translate3d(${x}px,0,0)`;
  if(!prev||reducedMotion()||Math.abs(prev.x-x)<1)return;
  ind.getAnimations().forEach(a=>a.cancel());
  const d=Math.abs(prev.x-x),mid=prev.x+(x-prev.x)*.55,stretch=Math.min(1.5,(Math.max(prev.w,w)+d*.4)/w);
  ind.animate([{transform:`translate3d(${prev.x}px,0,0) scaleX(${prev.w/w})`},{transform:`translate3d(${mid}px,0,0) scaleX(${stretch})`,offset:.45},{transform:`translate3d(${x}px,0,0) scaleX(1)`}],{duration:420,easing:SPRING});
}
const TAB_ORDER=['home','search','radio','library','profile'];
const moveTabInd=()=>slideDrop($('.tabbar'),$('#tabInd'),$('.tabbar button.on'));
function moveSegInd(seg){let ind=seg.querySelector(':scope>.seg-ind');if(!ind){ind=document.createElement('span');ind.className='seg-ind';seg.prepend(ind)}const on=seg.querySelector(':scope>button.on');slideDrop(seg,ind,on,{scroll:true});seg.classList.toggle('has-ind',!!on&&!!seg.offsetParent)}
function watchSeg(seg){moveSegInd(seg);seg.addEventListener('click',e=>{if(e.target.closest('button'))requestAnimationFrame(()=>moveSegInd(seg))});new MutationObserver(muts=>{if(muts.some(m=>m.target.parentElement===seg&&m.target.tagName==='BUTTON'))requestAnimationFrame(()=>moveSegInd(seg))}).observe(seg,{subtree:true,attributes:true,attributeFilter:['class']})}
$$('.seg').forEach(watchSeg);const ptabs=$('.profile-tabs');if(ptabs)watchSeg(ptabs);

/* ---------- 3. Views: direction-aware transitions + iOS-style collapsing large title ---------- */
const baseGo=go;
go=function(v){
  const from=view;baseGo(v);moveTabInd();
  requestAnimationFrame(()=>{$$(`.view[data-view="${v}"] .seg,.view[data-view="${v}"] .profile-tabs`).forEach(moveSegInd);syncTopTitle()});
  if(from===v||reducedMotion())return;
  const el=$(`.view[data-view="${v}"]`);if(!el)return;const a=TAB_ORDER.indexOf(from),b=TAB_ORDER.indexOf(v);
  const dx=a<0||b<0?0:b>a?24:-24;
  el.animate([{opacity:0},{opacity:1}],{duration:document.documentElement.dataset.perf==='low'?160:240,easing:'ease-out'});
};
addEventListener('resize',()=>{moveTabInd();$$('.view.active .seg,.view.active .profile-tabs').forEach(moveSegInd)});
requestAnimationFrame(moveTabInd);
let scrollQueued=false;
function syncTopTitle(){const t=$('.view.active .page-title, .view.active #colTitle, .view.active #albumTitle');const y=scrollY;document.body.classList.toggle('scrolled',y>6);
  const show=!!t&&t.getBoundingClientRect().bottom<64;document.body.classList.toggle('title-in-bar',show);const tt=$('#topTitle');if(t&&tt.textContent!==t.textContent)tt.textContent=t.textContent}
addEventListener('scroll',()=>{if(scrollQueued)return;scrollQueued=true;requestAnimationFrame(()=>{scrollQueued=false;syncTopTitle()})},{passive:true});

/* ---------- 4. Full player: the cover flies from the mini player (FLIP) ---------- */
function ghostFrom(el){const g=document.createElement('div');const cs=getComputedStyle(el);g.className='cover-ghost';g.style.backgroundImage=cs.backgroundImage;g.style.color=cs.color;g.style.fontFamily=cs.fontFamily;g.style.fontWeight=cs.fontWeight;g.textContent=el.textContent;document.body.appendChild(g);return g}
function visibleRect(el){if(!el)return null;const r=el.getBoundingClientRect();return r.width>4&&r.bottom>0&&r.top<innerHeight?r:null}
function sourceCover(){if(visibleRect($('#mini:not(.hidden) #miniCover')))return $('#miniCover');const p=$('.tile.playing .cover');return view==='home'&&visibleRect(p)?p:null}
function flyCover(open){
  if(reducedMotion())return;const src=sourceCover();if(!src)return;const from=src.getBoundingClientRect();
  /* 6.3.1: no flight when the big cover is not what the user sees (lyrics screen, player scrolled down) */
  if(full.classList.contains('lyrics-open')||Date.now()-(full._lyAt||0)<900||full.scrollTop>40)return;
  /* final rect = where the cover sits once the sheet has fully risen (ignore the panel's current translate) */
  const panelTop=full.getBoundingClientRect().top,c=fullCover.getBoundingClientRect();
  const to={left:c.left,top:c.top-panelTop,width:c.width,height:c.height};
  const a=open?from:{...to,top:c.top},b=open?to:from;
  const g=ghostFrom(fullCover);g.style.fontSize=getComputedStyle(fullCover).fontSize;Object.assign(g.style,{width:b.width+'px',height:b.height+'px'});
  fullCover.style.visibility='hidden';if(!open)src.style.visibility='hidden';
  const sx=a.width/b.width,sy=a.height/b.height;
  /* real corner radii of both ends (the mini cover is a circle); the ghost is scaled, so its start radius is divided by the scale */
  const rad=(el,w)=>{const v=getComputedStyle(el).borderTopLeftRadius;return /%/.test(v)?w*parseFloat(v)/100:parseFloat(v)||0};
  const rSrc=rad(src,from.width),rFull=rad(fullCover,c.width),rA=open?rSrc:rFull,rB=open?rFull:rSrc;
  const anim=g.animate([{transform:`translate(${a.left}px,${a.top}px) scale(${sx},${sy})`,borderRadius:(rA/sx)+'px'},{transform:`translate(${b.left}px,${b.top}px) scale(1)`,borderRadius:rB+'px'}],{duration:open?620:400,easing:EASE_SNAP,fill:'forwards'});
  anim.onfinish=anim.oncancel=()=>{fullCover.style.visibility='';src.style.visibility='';g.remove()};
}
let fullWasOpen=false;
new MutationObserver(()=>{const ly=full.classList.contains('lyrics-open');if(ly||full._prevLy)full._lyAt=Date.now();full._prevLy=ly;const open=full.classList.contains('open');if(open===fullWasOpen)return;fullWasOpen=open;document.body.classList.toggle('full-open',open);if(open)audio.dispatchEvent(new Event('timeupdate'));if(open)full.scrollTop=0;if(!full.classList.contains('dragging')&&!full._dragDismiss)requestAnimationFrame(()=>flyCover(open));full._dragDismiss=false}).observe(full,{attributes:true,attributeFilter:['class']});
let lastTitle=$('#fullTitle').textContent;
new MutationObserver(()=>{const t=$('#fullTitle').textContent;if(t===lastTitle)return;lastTitle=t;if(reducedMotion()||!full.classList.contains('open'))return;
  fullCover.animate([{opacity:0,transform:'translateX(48px) scale(.9) rotate(2deg)'},{opacity:1,transform:'none'}],{duration:600,easing:SPRING});
  $('.full-meta>div').animate([{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'none'}],{duration:480,delay:60,easing:EASE_OUT,fill:'backwards'});
}).observe($('#fullTitle'),{childList:true,characterData:true,subtree:true});

/* ---------- 5. Drag to dismiss (player & sheets) with velocity and rubber-banding ---------- */
function dragToDismiss(panel,canStart,onDismiss){
  let y0=null,dy=0,lastY=0,lastT=0,v=0,active=false;
  panel.addEventListener('touchstart',e=>{if(!canStart(e))return;y0=lastY=e.touches[0].clientY;lastT=performance.now();dy=0;v=0;active=false},{passive:true});
  panel.addEventListener('touchmove',e=>{if(y0===null)return;const y=e.touches[0].clientY,now=performance.now();const raw=y-y0;v=(y-lastY)/Math.max(1,now-lastT);lastY=y;lastT=now;
    if(!active&&raw>8){active=true;panel.classList.add('dragging')}if(!active)return;dy=raw>0?raw:-Math.sqrt(-raw)*3;panel.style.transform=`translate3d(0,${dy}px,0)`},{passive:true});
  const end=()=>{if(y0===null)return;y0=null;if(!active)return;active=false;const dismiss=dy>120||(dy>30&&v>.5);
    panel.style.transform='';panel.classList.remove('dragging');if(dismiss){panel._dragDismiss=true;onDismiss()}};
  panel.addEventListener('touchend',end);panel.addEventListener('touchcancel',end);
}
dragToDismiss(full,e=>full.scrollTop<=0&&!!e.target.closest('.full-top,.cover-stage,.full-grab,.full-meta'),()=>full.classList.remove('open'));
const sheet=$('#sheet');dragToDismiss(sheet,e=>sheet.scrollTop<=0&&!e.target.closest('input,textarea,select,.q-grip'),()=>closeSheet());

/* ---------- 6. Lists: only rows that just arrived rise in ---------- */
function watchList(el,sel,key){
  let seen=new Set();
  new MutationObserver(()=>{if(el.querySelector('.loader')||!el.children.length){seen=new Set();return}if(liteMotion()||window.__quietList){el.querySelectorAll(':scope>'+sel).forEach(r=>{const id=r.getAttribute(key);if(id)seen.add(id)});return}let n=0;
    el.querySelectorAll(':scope>'+sel).forEach(row=>{const id=row.getAttribute(key);if(!id||seen.has(id))return;seen.add(id);if(n<12)row.animate([{opacity:0,transform:'translateY(12px)'},{opacity:1,transform:'none'}],{duration:460,delay:n*32,easing:EASE_OUT,fill:'backwards'});n++})}).observe(el,{childList:true});
}
for(const id of ['searchList','radioList','colList','libList'])if($('#'+id))watchList($('#'+id),'.item,.lib-row','data-id');
if($('#albumTracks'))watchList($('#albumTracks'),'.album-track','data-album-track');

/* ---------- 7. Heart burst ---------- */
function burst(btn){
  if(reducedMotion())return;const r=btn.getBoundingClientRect(),b=document.createElement('div');b.className='burst';b.style.left=r.left+r.width/2+'px';b.style.top=r.top+r.height/2+'px';
  const nb=liteMotion()?5:10;for(let i=0;i<nb;i++){const p=document.createElement('i'),a=i/nb*Math.PI*2+Math.random()*.4,d=22+Math.random()*16;b.appendChild(p);p.animate([{transform:'translate(0,0) scale(1)',opacity:1},{transform:`translate(${Math.cos(a)*d}px,${Math.sin(a)*d}px) scale(0)`,opacity:0}],{duration:560+Math.random()*200,easing:EASE_OUT,fill:'forwards'})}
  document.body.appendChild(b);setTimeout(()=>b.remove(),900);
  btn.querySelector('svg')?.animate([{transform:'scale(.6)'},{transform:'scale(1)'}],{duration:520,easing:SPRING});
}
document.addEventListener('click',e=>{const btn=e.target.closest('[data-fav],#miniFav,#fullFav,#albumSave');if(!btn)return;requestAnimationFrame(()=>{if(btn.classList.contains('fav')&&btn.isConnected)burst(btn)})});

/* ---------- 8. Liquid press: glass controls squish under the finger ---------- */
document.addEventListener('pointerdown',e=>{const g=e.target.closest('.glass:not(.tabbar):not(.mini):not(.sheet):not(.settings-group):not(.searchbox),.playbig,.tile,.card');if(!g||liteMotion())return;
  g.getAnimations().forEach(a=>a.id==='press'&&a.cancel());
  const down=g.animate([{transform:'scale(1)'},{transform:'scale(.96)'}],{duration:120,easing:'ease-out',fill:'forwards',id:'press'});
  const up=()=>{down.cancel();const a=g.animate([{transform:'scale(.96)'},{transform:'scale(1)'}],{duration:480,easing:SPRING,id:'press'});removeEventListener('pointerup',up);removeEventListener('pointercancel',up)};
  addEventListener('pointerup',up);addEventListener('pointercancel',up)},{passive:true});

/* ---------- 9. Play / pause morph ---------- */
const pop=()=>{if(reducedMotion())return;for(const b of [$('#playBtn'),$('#miniPlay')])b.querySelector('svg')?.animate([{transform:'scale(.4) rotate(-25deg)',opacity:0},{transform:'none',opacity:1}],{duration:480,easing:SPRING})};
audio.addEventListener('play',pop);audio.addEventListener('pause',pop);

/* ---------- 10. Search glow while sources answer ---------- */
const progress=$('#searchProgress');
new MutationObserver(()=>{$('.searchbox').classList.toggle('busy',/^(Ищем|Поиск \d)/.test(progress.textContent))}).observe(progress,{childList:true,characterData:true,subtree:true});

/* ---------- 11. Wallpaper follows the cover; pauses when not visible ---------- */
document.addEventListener('visibilitychange',()=>document.body.classList.toggle('hidden-tab',document.hidden));
const wallArt=$('#wallArt');
new MutationObserver(()=>{const a=$('#fullArt').style.backgroundImage;if(wallArt.style.backgroundImage!==a){wallArt.style.backgroundImage=a;if(!reducedMotion())wallArt.animate([{opacity:0},{opacity:1}],{duration:900,easing:'ease-out'})}}).observe($('#fullArt'),{attributes:true,attributeFilter:['style']});

/* ---------- 12. Real lenses: a displacement map per glass element (edges bend what is behind) ---------- */
const LENS=(()=>{
  const ok=CSS.supports('backdrop-filter','url(#x)');if(!ok)return {apply(){}};
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('width','0');svg.setAttribute('height','0');svg.style.position='absolute';document.body.appendChild(svg);
  const cache=new Map();
  function map(w,h,r,edge){const k=[w,h,r,edge].join('x');if(cache.has(k))return cache.get(k);
    const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');const img=x.createImageData(w,h),d=img.data;
    for(let j=0;j<h;j++)for(let i=0;i<w;i++){const px=i+.5-w/2,py=j+.5-h/2,ax=Math.abs(px)-(w/2-r),ay=Math.abs(py)-(h/2-r);
      const qx=Math.max(ax,0),qy=Math.max(ay,0),sd=Math.hypot(qx,qy)+Math.min(Math.max(ax,ay),0)-r;const t=Math.max(0,Math.min(1,1+sd/edge)),k2=t*t*t;
      let nx,ny;if(qx>0||qy>0){const L=Math.hypot(qx,qy)||1;nx=Math.sign(px)*qx/L;ny=Math.sign(py)*qy/L}else if(ax>ay){nx=Math.sign(px);ny=0}else{nx=0;ny=Math.sign(py)}
      const p=(j*w+i)*4;d[p]=128-nx*127*k2;d[p+1]=128-ny*127*k2;d[p+2]=128;d[p+3]=255}
    x.putImageData(img,0,0);const url=c.toDataURL();cache.set(k,url);return url}
  let n=0;
  function apply(el,{edge=18,scale=26,blur=2,sat=1.8,bright=1.06}={}){
    if(!el)return;const r0=el.getBoundingClientRect();const w=Math.round(r0.width),h=Math.round(r0.height);if(w<8||h<8)return;
    const rad=Math.min(parseFloat(getComputedStyle(el).borderTopLeftRadius)||0,h/2,w/2);
    const id=el._lensId||(el._lensId='lens'+(n++));let f=svg.querySelector('#'+id);
    if(!f){f=document.createElementNS('http://www.w3.org/2000/svg','filter');f.id=id;f.setAttribute('color-interpolation-filters','sRGB');f.setAttribute('filterUnits','userSpaceOnUse');f.setAttribute('primitiveUnits','userSpaceOnUse');f.innerHTML='<feImage x="0" y="0" preserveAspectRatio="none" result="m"/><feDisplacementMap in="SourceGraphic" in2="m" xChannelSelector="R" yChannelSelector="G"/>';svg.appendChild(f)}
    for(const a of ['width','height'])f.setAttribute(a,a==='width'?w:h);f.setAttribute('x',0);f.setAttribute('y',0);
    const im=f.querySelector('feImage');im.setAttribute('width',w);im.setAttribute('height',h);im.setAttribute('href',map(w,h,Math.round(rad),edge));
    f.querySelector('feDisplacementMap').setAttribute('scale',scale);
    el.style.setProperty('--lens',`url(#${id}) blur(${blur}px) saturate(${sat}) brightness(${bright})`);el.classList.add('lensed');
  }
  return {apply};
})();
function lensAllHeavy(){LENS.apply($('.tabbar'),{edge:20,scale:30,blur:16});LENS.apply($('#mini'),{edge:18,scale:26,blur:16});LENS.apply($('#tabInd'),{edge:16,scale:-36,blur:0,sat:2.2,bright:1.12});$$('.playbig').forEach(b=>b.offsetParent&&LENS.apply(b,{edge:22,scale:40,blur:3}))}
function lensAll(){if(store.get('lensFx',false))lensAllHeavy()}
requestAnimationFrame(()=>setTimeout(lensAll,60));addEventListener('resize',()=>setTimeout(lensAll,120));
new MutationObserver(()=>setTimeout(lensAll,50)).observe(full,{attributes:true,attributeFilter:['class']});
new MutationObserver(()=>setTimeout(lensAll,650)).observe($('#mini'),{attributes:true,attributeFilter:['class']});

/* ---------- 13. While scrolling: lighter glass (keeps 120/144 Hz) and the tab bar tucks away like iOS 26 ---------- */
const LENS_ON=store.get('lensFx',false);let lastTouch=0;addEventListener('touchmove',()=>{lastTouch=Date.now()},{passive:true});addEventListener('wheel',()=>{lastTouch=Date.now()},{passive:true});let scrollIdle=0,lastY=scrollY;
addEventListener('scroll',()=>{
  if(LENS_ON){document.body.classList.add('is-scrolling');clearTimeout(scrollIdle);scrollIdle=setTimeout(()=>document.body.classList.remove('is-scrolling'),160)}
  const y=scrollY,dy=y-lastY;lastY=y;if(Math.abs(dy)<4)return;
  /* only the user's own scrolling compacts the bar (not keyboard resizes or results growing) */
  if(Date.now()-lastTouch>900||Date.now()-(window.__kbAt||0)<700)return;
  document.body.classList.toggle('tab-compact',dy>0&&y>120);
},{passive:true});
document.addEventListener('lazzy:intro-done',()=>setTimeout(lensAll,80));

