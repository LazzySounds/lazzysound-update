'use strict';
/* Lazzy sound 3.4 — living background: particles (snow, stars, fireflies…) over the wallpaper that move with the music.
   The pulse follows the track's timeline: a per-track tempo (beat) times the loudness envelope of the waveform.
   No Web Audio graph is attached to the player, so background playback and every source keep working. */
const FX_TYPES={none:{label:'Нет',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8"/><path d="M6.5 17.5l11-11"/></svg>'},snow:{label:'Снег',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18M4.2 7.5l15.6 9M4.2 16.5l15.6-9M9.5 4.5L12 7l2.5-2.5M9.5 19.5L12 17l2.5 2.5"/></svg>'},stars:{label:'Звёзды',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3c.8 4.6 2.4 6.2 7 7-4.6.8-6.2 2.4-7 7-.8-4.6-2.4-6.2-7-7 4.6-.8 6.2-2.4 7-7z"/><path d="M19 16.5v4M17 18.5h4"/></svg>'},fireflies:{label:'Светлячки',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="2.5"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M6.3 17.7l1.4-1.4M16.3 7.7l1.4-1.4"/></svg>'},bubbles:{label:'Пузыри',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="14" r="5"/><circle cx="17" cy="7" r="3"/><circle cx="18" cy="16" r="1.5"/></svg>'},petals:{label:'Лепестки',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="2"/><ellipse cx="12" cy="6.5" rx="2.6" ry="3.5"/><ellipse cx="12" cy="17.5" rx="2.6" ry="3.5"/><ellipse cx="6.5" cy="12" rx="3.5" ry="2.6"/><ellipse cx="17.5" cy="12" rx="3.5" ry="2.6"/></svg>'},confetti:{label:'Конфетти',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 6l2 2M16 4l-1 3M19 11l-3 1M8 17l-2 3M13 14l3 3M11 9l1.5 1.5"/><circle cx="18" cy="19" r=".8"/><circle cx="4" cy="12" r=".8"/></svg>'},rain:{label:'Дождь',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4l-2 5M13 4l-2 5M19 4l-2 5M10 13l-2 5M16 13l-2 5"/></svg>'},dust:{label:'Пыль',icon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="17" r="1"/><circle cx="10" cy="13" r="1"/><circle cx="14" cy="9" r="1"/><circle cx="18" cy="5" r="1"/><circle cx="8" cy="7" r=".7"/><circle cx="17" cy="15" r=".7"/></svg>'}};
const FX_DENSITY={low:{label:'Мало',k:.55},mid:{label:'Средне',k:1},high:{label:'Много',k:1.7}};
const FX_DEFAULT={high:{type:'snow',density:'mid',pulse:true},mid:{type:'snow',density:'low',pulse:false},low:{type:'none',density:'low',pulse:false}}[document.documentElement.dataset.perf||'high']||{};
const Fx=Object.assign({type:'snow',density:'mid',react:true,pulse:true,inPlayer:true},FX_DEFAULT,store.get('fx',{}));
if(!FX_TYPES[Fx.type])Fx.type='snow';if(!FX_DENSITY[Fx.density])Fx.density='mid';
const saveFx=()=>store.set('fx',Fx);

const FxEngine=(()=>{
  const cv=document.createElement('canvas');cv.className='fx-canvas';cv.setAttribute('aria-hidden','true');
  const x=cv.getContext('2d');let W=0,H=0,dpr=1,parts=[],raf=0,last=0,pulse=0,level=0,kickBoost=0,sprites={},spriteKey='',cols=['#46b7ff','#8bf3e6','#2e7dff'],colsAt=0;
  const rnd=(a,b)=>a+Math.random()*(b-a);
  const accent=()=>{const cs=getComputedStyle(document.documentElement);return[cs.getPropertyValue('--accent').trim()||'#46b7ff',cs.getPropertyValue('--accent-2').trim()||'#8bf3e6',cs.getPropertyValue('--accent-3').trim()||'#2e7dff']};
  function glow(color,r,core=.35){const s=document.createElement('canvas');const n=Math.ceil(r*2*dpr);s.width=s.height=n;const g=s.getContext('2d');const gr=g.createRadialGradient(n/2,n/2,0,n/2,n/2,n/2);gr.addColorStop(0,color);gr.addColorStop(core,color);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,n,n);return s}
  function buildSprites(){
    const now=performance.now();if(now-colsAt>1000||!spriteKey){colsAt=now;cols=accent()}const [a1,a2,a3]=cols;const light=document.documentElement.dataset.theme==='light';const key=a1+a2+a3+dpr+light;if(key===spriteKey)return;spriteKey=key;
    const ink=light?'rgba(90,110,170,.75)':'rgba(255,255,255,.95)';
    sprites={snow:glow(ink,6,.45),star:glow(light?a3:'rgba(255,255,255,1)',4,.25),fly:[glow(a1,10,.18),glow(a2,10,.18),glow(a3,10,.18)],dust:glow(light?'rgba(90,110,170,.6)':'rgba(255,255,255,.7)',3,.4)};
  }
  function resize(){dpr=1;const host=cv.parentElement;W=host?.clientWidth||innerWidth;H=host?.clientHeight||innerHeight;cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);spriteKey='';buildSprites()}
  function spawn(type,initial){
    const p={x:rnd(0,W),y:initial?rnd(0,H):-20,s:rnd(.5,1.2),a:rnd(0,Math.PI*2),r:rnd(-1,1),v:rnd(.6,1.2),c:Math.floor(Math.random()*3),z:rnd(.4,1)};
    if(type==='bubbles'||type==='fireflies'){if(!initial)p.y=H+20}
    if(type==='stars'||type==='dust'){p.y=rnd(0,H)}
    if(type==='confetti'){p.c=Math.floor(Math.random()*5);p.w=rnd(4,8);p.h=rnd(8,14)}
    if(type==='rain'){p.len=rnd(10,22)}
    return p;
  }
  function count(){const base={snow:56,stars:70,fireflies:22,bubbles:18,petals:22,confetti:36,rain:70,dust:46}[Fx.type]||0;return Math.round(base*FX_DENSITY[Fx.density].k*Math.min(1.4,W*H/(390*844)))}
  function reset(){parts=[];const n=count();for(let i=0;i<n;i++)parts.push(spawn(Fx.type,true))}

  /* Music signal: tempo from the track id (84–131 BPM), loudness from the waveform envelope. */
  const bpmOf=t=>84+(hash(t.id||t.title||'')%48);
  let envId='',env=[];
  function signal(dt){
    const t=cur(),playing=!!t&&!audio.paused;let target=0,kick=0;
    if(playing&&Fx.react){
      if(envId!==t.id){envId=t.id;env=typeof fakePeaks==='function'?fakePeaks(t.id,96):[];if(typeof Wave!=='undefined'&&Wave.id===t.id&&Wave.peaks.length)env=Wave.peaks}
      const d=audio.duration,c=audio.currentTime||0;const e=isFinite(d)&&d>0&&env.length?env[Math.min(env.length-1,Math.floor(c/d*env.length))]:.6;
      const ph=(c*bpmOf(t)/60)%1;kick=Math.exp(-ph*7);target=.3+.7*e;
    }else if(playing)target=.35;
    level+=(target-level)*Math.min(1,dt*2.5);
    const p=level*(.45+.55*kick)+kickBoost;kickBoost*=Math.pow(.02,dt);
    pulse+=(p-pulse)*Math.min(1,dt*14);
    return pulse;
  }

  function step(dt,P){
    const type=Fx.type,speed=.35+level*.9;const [a1,a2,a3]=cols;
    x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,W,H);
    const light=document.documentElement.dataset.theme==='light';const ink=light?'rgba(80,100,160,.85)':'rgba(255,255,255,.85)';
    x.globalCompositeOperation=!light&&(type==='fireflies'||type==='stars')?'lighter':'source-over';
    for(let i=0;i<parts.length;i++){const p=parts[i];
      switch(type){
        case 'snow':{p.a+=dt*(.6+P);p.y+=dt*28*p.v*p.z*(.6+speed);p.x+=Math.sin(p.a)*dt*14*(1+P*1.6)*p.z;const r=(2.2+P*1.6)*p.s*p.z*2;x.globalAlpha=.5+.45*p.z;x.drawImage(sprites.snow,p.x-r,p.y-r,r*2,r*2);if(p.y>H+10)parts[i]=spawn(type,false);break}
        case 'stars':{p.a+=dt*(1+P*4)*p.v;p.x+=dt*3*p.r;const tw=.35+.65*Math.abs(Math.sin(p.a));const r=(1.2+P*2.2*p.z)*p.s*2.4;x.globalAlpha=Math.min(1,tw*(.4+P*.9)*p.z+.12);x.drawImage(sprites.star,p.x-r,p.y-r,r*2,r*2);if(p.x<-10)p.x=W+10;if(p.x>W+10)p.x=-10;break}
        case 'fireflies':{p.a+=dt*p.r*.9;p.x+=Math.cos(p.a)*dt*18*speed;p.y-=dt*10*p.v*speed;const r=(7+P*9)*p.s;x.globalAlpha=(.35+.5*Math.abs(Math.sin(p.a*2.3)))*(.55+P*.6);x.drawImage(sprites.fly[p.c],p.x-r,p.y-r,r*2,r*2);if(p.y<-30||p.x<-40||p.x>W+40)parts[i]=spawn(type,false);break}
        case 'bubbles':{p.a+=dt*1.4;p.y-=dt*30*p.v*(.5+speed);p.x+=Math.sin(p.a)*dt*10;const r=(6+p.s*10)*(1+P*.25);x.globalAlpha=.22+.25*p.z+P*.2;x.lineWidth=1.2;x.strokeStyle=ink;x.beginPath();x.arc(p.x,p.y,r,0,Math.PI*2);x.stroke();x.globalAlpha*=.8;x.fillStyle=ink;x.beginPath();x.arc(p.x-r*.35,p.y-r*.35,r*.18,0,Math.PI*2);x.fill();if(p.y<-30)parts[i]=spawn(type,false);break}
        case 'petals':{p.a+=dt*(1.2+P*2)*p.r;p.y+=dt*34*p.v*(.5+speed);p.x+=Math.sin(p.a*.7)*dt*30;const s=(6+p.s*5)*(1+P*.2);x.save();x.translate(p.x,p.y);x.rotate(p.a);x.scale(1,Math.abs(Math.cos(p.a*1.3))*.7+.3);x.globalAlpha=.55+.35*p.z;x.fillStyle=p.c?'#ffb3cf':'#ffd6e6';x.beginPath();x.ellipse(0,0,s,s*.55,0,0,Math.PI*2);x.fill();x.restore();if(p.y>H+20)parts[i]=spawn(type,false);break}
        case 'confetti':{p.a+=dt*(3+P*6)*p.r;p.y+=dt*48*p.v*(.45+speed);p.x+=Math.sin(p.a*.5)*dt*22;const col=[a1,a2,a3,'#ffd166','#ff6b9a'][p.c];x.save();x.translate(p.x,p.y);x.rotate(p.a);x.scale(Math.cos(p.a*1.7),1);x.globalAlpha=.8;x.fillStyle=col;x.fillRect(-p.w/2,-p.h/2,p.w,p.h);x.restore();if(p.y>H+20)parts[i]=spawn(type,false);break}
        case 'rain':{p.y+=dt*(420+P*380)*p.v*p.z;p.x-=dt*40*p.z;x.globalAlpha=.18+.3*p.z+P*.15;x.strokeStyle=light?'rgba(80,110,170,.7)':'rgba(200,225,255,.9)';x.lineWidth=1.1*p.z;x.beginPath();x.moveTo(p.x,p.y);x.lineTo(p.x+p.len*.18,p.y-p.len*(1+P*.6));x.stroke();if(p.y>H+20){parts[i]=spawn(type,false);parts[i].x=rnd(0,W+60)}break}
        case 'dust':{p.a+=dt*.4*p.r;p.x+=Math.cos(p.a)*dt*8*(1+P*2);p.y+=Math.sin(p.a)*dt*8*(1+P*2);const r=(1.4+P*1.8)*p.s*2;x.globalAlpha=(.25+.45*p.z)*(.6+P*.7);x.drawImage(sprites.dust,p.x-r,p.y-r,r*2,r*2);if(p.x<-10)p.x=W+10;if(p.x>W+10)p.x=-10;if(p.y<-10)p.y=H+10;if(p.y>H+10)p.y=-10;break}
      }
    }
    x.globalAlpha=1;x.globalCompositeOperation='source-over';
  }

  let pulseNow=0;
  function frame(now){
    raf=0;if(document.hidden)return;
    // On 120/144 Hz screens draw particles every other frame (~60–72 fps): smooth enough, half the GPU work, scrolling keeps full rate.
    if(last&&now-last<(typeof perfFrameGap==='function'?perfFrameGap():12.5)){raf=requestAnimationFrame(frame);return}
    const dt=Math.min(.05,(now-(last||now))/1000);last=now;
    const P=signal(dt);
    const hiddenHost=document.body.classList.contains('full-open')&&cv.parentElement?.id==='ambient';
    if(Fx.type!=='none'&&cv.parentElement&&!hiddenHost){buildSprites();step(dt,P)}
    pulseNow=Fx.pulse?Math.min(1,P*1.1):0;
    if(running())raf=requestAnimationFrame(frame);
  }
  const reducedFx=()=>document.documentElement.dataset.motion==='reduce'||window.LZ_OSREDUCE===true;
  const running=()=>!reducedFx()&&(Fx.type!=='none'||Fx.pulse);
  function mount(){
    const inFull=$('#full').classList.contains('open')&&Fx.inPlayer;const host=inFull?$('#fullBg'):$('#ambient');
    if(cv.parentElement!==host){host.appendChild(cv);resize();reset()}
    cv.style.display=Fx.type==='none'?'none':'';if(Fx.type==='none'&&cv.width){cv.width=cv.height=0}else if(Fx.type!=='none'&&!cv.width){resize();reset()}
  }
  function start(){mount();if(!running()){x.clearRect(0,0,cv.width,cv.height);pulseNow=0;return}if(!raf){last=0;raf=requestAnimationFrame(frame)}}
  addEventListener('resize',()=>{resize();reset()});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&Fx.type!=='none'&&!cv.width){resize();reset()}start()});
  new MutationObserver(()=>mount()).observe($('#full'),{attributes:true,attributeFilter:['class']});
  audio.addEventListener('loadstart',()=>{kickBoost=.6});
  new MutationObserver(()=>{spriteKey='';start()}).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme','data-motion']});
  return{start,restart(){reset();start()},mount,free(){cv.width=cv.height=0;parts=[];sprites={};spriteKey=''},get pulse(){return pulseNow}};
})();

/* ---------- Settings: Profile → Фон ---------- */
function renderFxSettings(){
  const host=$('#fxSettings');if(!host)return;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-snow"/></svg><h2>Живой фон</h2></div>
    <p class="settings-help">Частицы двигаются и пульсируют вместе с треком, цвет берётся из акцента и обложки.</p>
    <div class="fx-choices" id="fxType">${Object.entries(FX_TYPES).map(([k,v])=>`<button data-fx="${k}" class="${k===Fx.type?'on':''}"><i>${v.icon}</i>${v.label}</button>`).join('')}</div>
    <p class="field-label">Количество</p><div class="choice-row" id="fxDensity">${Object.entries(FX_DENSITY).map(([k,v])=>`<button data-fxd="${k}" class="${k===Fx.density?'on':''}">${v.label}</button>`).join('')}</div>
    <label class="toggle-row"><span><b>Реагировать на музыку</b><small>Быстрее и ярче, когда трек громче</small></span><input type="checkbox" id="fxReact" ${Fx.react?'checked':''}></label>
    <label class="toggle-row"><span><b>Пульс обоев</b><small>Цветной фон дышит в такт</small></span><input type="checkbox" id="fxPulse" ${Fx.pulse?'checked':''}></label>
    <label class="toggle-row"><span><b>В плеере</b><small>Частицы и на экране трека</small></span><input type="checkbox" id="fxInPlayer" ${Fx.inPlayer?'checked':''}></label>`;
  $('#fxType').onclick=e=>{const b=e.target.closest('[data-fx]');if(!b)return;Fx.type=b.dataset.fx;saveFx();renderFxSettings();FxEngine.restart()};
  $('#fxDensity').onclick=e=>{const b=e.target.closest('[data-fxd]');if(!b)return;Fx.density=b.dataset.fxd;saveFx();renderFxSettings();FxEngine.restart()};
  $('#fxReact').onchange=e=>{Fx.react=e.target.checked;saveFx()};
  $('#fxPulse').onchange=e=>{Fx.pulse=e.target.checked;saveFx();FxEngine.start()};
  $('#fxInPlayer').onchange=e=>{Fx.inPlayer=e.target.checked;saveFx();FxEngine.mount()};
}
renderFxSettings();
document.addEventListener('lazzy:intro-done',()=>FxEngine.start(),{once:true});
setTimeout(()=>FxEngine.start(),4200);
