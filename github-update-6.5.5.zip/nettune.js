'use strict';
(function(){
var H=['youtube.com','youtu.be','googlevideo.com','ytimg.com','ggpht.com','soundcloud.com','sndcdn.com','soundcloud.cloud','audius.co','audius.org','archive.org','ccmixter.org','jamendo.com','mixcloud.com','deezer.com','dzcdn.net','genius.com','lrclib.net','lyrics.ovh','musicbrainz.org','theaudiodb.com','wikidata.org','wikimedia.org','discogs.com','last.fm','song.link','radio-browser.info','pollinations.ai'];
var M=['tlsrec+split','tlsrec','split','disorder','tlsrec+disorder'];
var N={on:store.get('netOn',false),strat:store.get('netStrat',M[0])};
if(M.indexOf(N.strat)<0)N.strat=M[0];
var nat=function(){return typeof window.LumenNative?.setNetMode==='function'};
function ap(){store.set('netOn',N.on);store.set('netStrat',N.strat);try{if(nat())LumenNative.setNetMode(!!N.on,N.strat,H.join('\n'))}catch(e){}}
var pend=new Map();
window.__lazzyNet=function(id,p){var f=pend.get(id);if(f){pend.delete(id);try{f(JSON.parse(p))}catch(e){f({ok:false})}}};
function chk(u){return new Promise(function(res){var id='n'+Date.now()+Math.random().toString(36).slice(2,6);pend.set(id,res);setTimeout(function(){if(pend.delete(id))res({ok:false,error:'нет ответа'})},25000);try{LumenNative.netTest(u,id)}catch(e){pend.delete(id);res({ok:false,error:e.message})}})}
function num(k){return String(M.indexOf(k)+1||1)}
function render(){
  var host=$('#netSettings');if(!host)return;
  if(!nat()){host.innerHTML='<div class="setting-title"><svg><use href="#i-sliders"/></svg><h2>Мод</h2></div><p class="settings-help">Доступно в приложении для Android.</p>';return}
  host.innerHTML='<div class="setting-title"><svg><use href="#i-sliders"/></svg><h2>Мод</h2></div>'
    +'<p class="settings-help">Если музыка или обложки грузятся плохо — включи и подбери номер кнопкой «Проверить».</p>'
    +'<label class="toggle-row"><span><b>Включить</b><small>'+(N.on?'Вкл · '+num(N.strat):'Выкл')+'</small></span><input type="checkbox" id="ntOn" '+(N.on?'checked':'')+'></label>'
    +'<p class="field-label">Режим</p><div class="choice-row nt-strats" id="ntStrat">'+M.map(function(k,i){return '<button data-bs="'+k+'" class="'+(k===N.strat?'on':'')+'">'+(i+1)+'</button>'}).join('')+'</div>'
    +'<div class="api-actions"><button class="btn-accent" id="ntTest">Проверить</button></div>'
    +'<p class="api-status" id="ntStatus" role="status"></p>';
  $('#ntOn').onchange=function(e){N.on=e.target.checked;ap();render();toast(N.on?'Вкл':'Выкл')};
  $('#ntStrat').onclick=function(e){var b=e.target.closest('[data-bs]');if(!b)return;N.strat=b.dataset.bs;ap();render()};
  $('#ntTest').onclick=async function(){var st=$('#ntStatus');st.textContent='Проверяем…';var sites=['https://soundcloud.com/','https://audius.co/','https://archive.org/','https://lrclib.net/'];
    var out=await Promise.all(sites.map(async function(u,i){var r=await chk(u);return (r.ok?'✅':'❌')+' '+(i+1)+(r.ok?' · '+r.ms+' мс':'')}));var okn=out.filter(function(x){return x[0]==='✅'}).length;st.textContent=(N.on?'':'Выкл. ')+okn+'/'+sites.length+'  '+out.join('  ')};
}
window.renderNetSettings=render;
render();
if(nat()&&N.on)ap();
})();
