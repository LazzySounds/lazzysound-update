'use strict';
/* 6.0.8 lyrics library: paste the text yourself (from Genius etc.), time it with «✍ Тайминги», publish it to LRCLIB —
   the open community database the app reads from, so every LRCLIB user (and every Lazzy user) gets the song next time. */
const LrcPend=new Map();
window.__lazzyLrc=(id,p)=>{const r=LrcPend.get(id);if(!r)return;LrcPend.delete(id);try{r(JSON.parse(p))}catch{r({status:0,body:''})}};
function lrcPost(path,body,token){
  if(window.LumenNative?.lrclibPost)return new Promise(res=>{const id='lrc-'+Date.now()+Math.random().toString(36).slice(2,6);LrcPend.set(id,res);setTimeout(()=>{if(LrcPend.has(id)){LrcPend.delete(id);res({status:0,body:''})}},30000);try{LumenNative.lrclibPost(path,body||'',token||'',id)}catch{LrcPend.delete(id);res({status:0,body:''})}});
  return fetch('https://lrclib.net/api/'+path,{method:'POST',headers:{'Content-Type':'application/json',...(token?{'X-Publish-Token':token}:{})},body:body||''}).then(async r=>({status:r.status,body:await r.text()})).catch(()=>({status:0,body:''}))}

/* LRCLIB asks for a small proof of work before publishing: find a nonce whose SHA-256(prefix+nonce) ≤ target. Runs in a worker. */
const POW_SRC=`const K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
const W=new Uint32Array(64),H=new Uint32Array(8);
function sha(bytes,len){const nb=((len+9+63)>>6)<<6,m=new Uint8Array(nb);m.set(bytes.subarray(0,len));m[len]=0x80;const bl=len*8;m[nb-4]=bl>>>24;m[nb-3]=bl>>>16;m[nb-2]=bl>>>8;m[nb-1]=bl;
 H.set([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
 for(let o=0;o<nb;o+=64){for(let i=0;i<16;i++)W[i]=(m[o+4*i]<<24)|(m[o+4*i+1]<<16)|(m[o+4*i+2]<<8)|m[o+4*i+3];
  for(let i=16;i<64;i++){const a=W[i-15],b=W[i-2];W[i]=(((a>>>7)|(a<<25))^((a>>>18)|(a<<14))^(a>>>3))+W[i-16]+(((b>>>17)|(b<<15))^((b>>>19)|(b<<13))^(b>>>10))+W[i-7]}
  let a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
  for(let i=0;i<64;i++){const t1=(h+(((e>>>6)|(e<<26))^((e>>>11)|(e<<21))^((e>>>25)|(e<<7)))+((e&f)^(~e&g))+K[i]+W[i])|0,t2=((((a>>>2)|(a<<30))^((a>>>13)|(a<<19))^((a>>>22)|(a<<10)))+((a&b)^(a&c)^(b&c)))|0;h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0}
  H[0]+=a;H[1]+=b;H[2]+=c;H[3]+=d;H[4]+=e;H[5]+=f;H[6]+=g;H[7]+=h}return H}
onmessage=e=>{const {prefix,target}=e.data,T=new Uint32Array(8);for(let i=0;i<8;i++)T[i]=parseInt(target.substr(i*8,8),16);
 const buf=new Uint8Array(prefix.length+24);for(let i=0;i<prefix.length;i++)buf[i]=prefix.charCodeAt(i);
 for(let n=0;;n++){const s=String(n);for(let i=0;i<s.length;i++)buf[prefix.length+i]=s.charCodeAt(i);const h=sha(buf,prefix.length+s.length);
  let ok=true;for(let i=0;i<8;i++){if(h[i]<T[i])break;if(h[i]>T[i]){ok=false;break}}
  if(ok){postMessage({nonce:s});return}if(n%250000===0)postMessage({p:n})}};`;
function solvePow(prefix,target,onP){return new Promise((res,rej)=>{let w;try{w=new Worker(URL.createObjectURL(new Blob([POW_SRC],{type:'text/javascript'})))}catch(e){rej(e);return}
  const tm=setTimeout(()=>{w.terminate();rej(new Error('слишком долго'))},6*60000);
  w.onmessage=e=>{if(e.data.nonce!=null){clearTimeout(tm);w.terminate();res(e.data.nonce)}else onP?.(e.data.p)};w.onerror=e=>{clearTimeout(tm);w.terminate();rej(new Error('worker'))};w.postMessage({prefix,target})})}
const lrcStamp=s=>{const m=Math.floor(s/60),x=(s-m*60);return '['+String(m).padStart(2,'0')+':'+x.toFixed(2).padStart(5,'0')+']'};
async function publishLrclib(t,res){
  const lines=(res.synced||[]).filter(l=>l.text!=null);if(lines.length<3)throw new Error('Сначала запиши тайминги («✍ Тайминги»)');
  const plain=res.plain||lines.map(l=>l.text).join('\n'),synced=lines.map(l=>lrcStamp(l.t)+' '+String(l.text).replace(WORD_TAG,'').trim()).join('\n');
  const dur=Math.round(mDur()||t.duration||0);if(dur<20)throw new Error('Неизвестна длина трека');
  toast('LRCLIB: получаем задание…');const ch=await lrcPost('request-challenge','');let c={};try{c=JSON.parse(ch.body)}catch{}
  if(!c.prefix||!c.target)throw new Error('LRCLIB не ответил');
  let last=0;const nonce=await solvePow(c.prefix,c.target,p=>{if(Date.now()-last>4000){last=Date.now();toast('LRCLIB: проверка… '+Math.round(p/1e6*10)/10+' млн')}});
  const body=JSON.stringify({trackName:cleanTitle(t.title),artistName:cleanArtist(t.artist||''),albumName:t.albumName||cleanTitle(t.title),duration:dur,plainLyrics:plain,syncedLyrics:synced});
  const r=await lrcPost('publish',body,c.prefix+':'+nonce);if(r.status!==201&&r.status!==200)throw new Error('LRCLIB отклонил ('+r.status+')');
}

/* paste lyrics for a song the databases don't have */
function pasteLyrics(t){
  openSheet({title:'Свой текст',sub:t.artist+' — '+t.title,tracks:[],cover:t});$('#sheet').dataset.mode='info';$('#sheetList').innerHTML='';
  $('#sheetActions').innerHTML=`<p class="settings-help">Скопируй текст (например, со страницы Genius) и вставь сюда — по строке на строку песни. Потом «✍ Тайминги» → «⇪ В LRCLIB», и песня появится у всех.</p>
    <textarea class="settings-input ly-paste" id="lyPaste" rows="12" placeholder="Текст песни…"></textarea><div class="api-actions"><button class="btn-accent" id="lyPasteOk">Сохранить</button><a class="chip" href="${esc(typeof geniusUrl==='function'?geniusUrl(t):'https://genius.com')}" target="_blank" rel="noopener">Открыть Genius</a></div>`;
  {const r0=lyrMem.get(t.id)||lyrStore.get(t.id);if(r0&&(r0.plain||r0.synced?.length))$('#lyPaste').value=r0.plain||r0.synced.map(l=>l.text).join('\n')}
  $('#lyPasteOk').onclick=async()=>{const text=$('#lyPaste').value.replace(/\r/g,'').replace(/^\s*\[(?:Куплет|Припев|Бридж|Verse|Chorus|Bridge|Intro|Outro|Pre-Chorus|Hook|Интро|Аутро)[^\]]*\]\s*$/gim,'').replace(/\n{3,}/g,'\n\n').trim();
    if(text.split('\n').filter(x=>x.trim()).length<2){toast('Слишком коротко');return}
    const res={plain:text,synced:[],src:'Свой текст',v:2,title:t.title,artist:t.artist,user:true};
    lyrMem.set(t.id,res);try{lyrStore.set(t.id,res)}catch{}try{await DB.saveCollection('lyrics:'+t.id,res)}catch{}
    closeSheet();if(Ly.open&&cur()?.id===t.id)render(typeof estimateSynced==='function'?estimateSynced(res,t):res);toast('Сохранено. Нажми «✍ Тайминги», чтобы текст шёл в такт')}}
const baseSetMessage608=setMessage;
setMessage=function(html){baseSetMessage608(html);if(!/Текст не нашли/.test(html))return;const t=cur();const a=linesEl.querySelector('.ly-actions');
  const gl=a&&a.querySelector('a[href*="genius.com"]');if(t&&gl&&typeof geniusSong==='function')geniusSong(t).then(g=>{if(g&&gl.isConnected){gl.href=g.url;gl.lastChild.textContent='Открыть на Genius'}}).catch(()=>{});
  if(t&&a&&!a.querySelector('.ly-paste-btn')){a.insertAdjacentHTML('beforeend','<button class="chip ly-paste-btn">📋 Вставить текст</button>');a.querySelector('.ly-paste-btn').onclick=()=>pasteLyrics(t)}
  if(t&&a&&!a.querySelector('.ly-asr-btn')&&typeof asrFetch==='function'&&typeof asrReady==='function'&&asrReady()){a.insertAdjacentHTML('beforeend','<button class="chip ly-asr-btn">🎙 Распознать слова</button>');const b=a.querySelector('.ly-asr-btn');b.onclick=()=>recognizeLyrics(t,b)}};

/* 6.1.5: no lyrics anywhere → Whisper listens to the track and writes timed lines (marked as recognised, editable) */
function wordsToLrc(words){
  const lines=[];let cur=[];const fmtT=s=>{const m=Math.floor(s/60),x=s-m*60;return String(m).padStart(2,'0')+':'+x.toFixed(2).padStart(5,'0')};
  const flush=()=>{if(!cur.length)return;let txt=cur.map(w=>w.w).join(' ').replace(/\s+([,.!?…])/g,'$1').trim();txt=txt[0].toUpperCase()+txt.slice(1);lines.push(`[${fmtT(cur[0].s)}]${txt}`);cur=[]};
  for(let i=0;i<words.length;i++){const w=words[i],prev=words[i-1];
    if(cur.length&&(w.s-prev.e>.7||cur.length>=9||(cur.length>=4&&/[.!?…]$/.test(prev.w))))flush();cur.push(w)}
  flush();return lines.join('\n')}
async function recognizeLyrics(t,btn){
  if(btn){btn.disabled=true;btn.textContent='🎙 Слушаю песню…'}
  try{const r=await asrFetch(t);const words=(r.words||[]).filter(w=>w.w&&isFinite(w.s));if(words.length<8)throw new Error('В треке почти нет слов');
    const synced=parseLRC(wordsToLrc(words));if(synced.length<3)throw new Error('Слова не разобрать');
    const res={synced,plain:synced.map(l=>l.text).join('\n'),src:'Распознано ИИ (Whisper)',v:2,title:t.title,artist:t.artist,asr:true};
    lyrMem.set(t.id,res);try{lyrStore.set(t.id,res)}catch{}try{await DB.saveCollection('lyrics:'+t.id,res)}catch{}
    if(Ly.open&&cur()?.id===t.id)render(res);toast('Готово. ИИ может ошибаться — поправь через «📋 Свой текст»')}
  catch(e){toast('Не получилось: '+(e.message||'ошибка'));if(btn){btn.disabled=false;btn.textContent='🎙 Распознать слова'}}}

/* «⇪ В LRCLIB» next to «✍ Тайминги» when this track has user/community timings */
(function(){const anchor=$('#lyRec');if(!anchor)return;anchor.insertAdjacentHTML('afterend','<button class="chip ly-tapsync" id="lyPub" hidden>⇪ В LRCLIB</button><button class="chip ly-tapsync" id="lyEditTxt">📋 Свой текст</button>');
  const upd=()=>{const t=cur(),r=t&&(lyrMem.get(t.id)||lyrStore.get(t.id));$('#lyPub').hidden=!(r&&(r.community||r.user)&&r.synced?.length>2&&!r.published)};
  new MutationObserver(upd).observe(linesEl,{childList:true});
  $('#lyEditTxt').onclick=e=>{e.stopPropagation();const t=cur();if(t)pasteLyrics(t)};
  $('#lyPub').onclick=async e=>{e.stopPropagation();const t=cur(),r=t&&(lyrMem.get(t.id)||lyrStore.get(t.id));if(!t||!r)return;const b=$('#lyPub');b.disabled=true;
    try{await publishLrclib(t,r);r.published=true;lyrMem.set(t.id,r);try{lyrStore.set(t.id,r)}catch{}toast('Опубликовано в LRCLIB — спасибо! Песня появится у всех');upd()}catch(x){toast(x.message||'Не получилось')}finally{b.disabled=false}}})();
