'use strict';
/* Lazzy sound logo family (3.7). One mark — a sound wave: seven rounded bars whose heights trace one smooth swell,
   slightly off-centre like a real waveform. Dressed six ways. The same SVG renders the launcher icons (build step),
   the in-app header and the start-up intro (bars grow one by one). */
(()=>{
const H=[.30,.54,.82,1,.72,.48,.64],BW=36,GAP=20,MAXH=292,X0=(512-(7*BW+6*GAP))/2;
/* bars(fill, extra) — fill can be a colour, a gradient url, or a function of the bar index */
const bars=(fill,extra='')=>H.map((h,i)=>{const hh=Math.round(MAXH*h),x=X0+i*(BW+GAP),y=256-hh/2;const f=typeof fill==='function'?fill(i):fill;
  return `<rect class="lz-bar" style="--i:${i}" x="${x}" y="${y}" width="${BW}" height="${hh}" rx="${BW/2}" fill="${f}" ${extra}/>`}).join('');
const tile=(fill,extra='')=>`<rect width="512" height="512" rx="128" fill="${fill}" ${extra}/>`;
const L={
  wave:{name:'Волна',svg:u=>`<defs><linearGradient id="${u}g" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#6a5cff"/><stop offset=".5" stop-color="#46b7ff"/><stop offset="1" stop-color="#8bf3e6"/></linearGradient><radialGradient id="${u}n" cx=".2" cy=".1" r="1"><stop offset="0" stop-color="#25304a"/><stop offset=".55" stop-color="#0d1016"/><stop offset="1" stop-color="#08090c"/></radialGradient></defs>${tile(`url(#${u}n)`)}<g>${bars(`url(#${u}g)`)}</g>`},
  glass:{name:'Стекло',svg:u=>`<defs><linearGradient id="${u}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2e7dff"/><stop offset=".55" stop-color="#8a3ffc"/><stop offset="1" stop-color="#ff4f9a"/></linearGradient><radialGradient id="${u}s" cx=".25" cy=".2" r=".8"><stop offset="0" stop-color="#7ff7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7ff7ff" stop-opacity="0"/></radialGradient><linearGradient id="${u}r" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".4" stop-color="#fff" stop-opacity=".15"/><stop offset="1" stop-color="#fff" stop-opacity=".6"/></linearGradient><linearGradient id="${u}f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".38"/><stop offset="1" stop-color="#fff" stop-opacity=".12"/></linearGradient></defs>${tile(`url(#${u}b)`)}<circle cx="150" cy="120" r="190" fill="url(#${u}s)"/><rect x="72" y="72" width="368" height="368" rx="110" fill="url(#${u}f)" stroke="url(#${u}r)" stroke-width="5"/><g transform="translate(256 256) scale(.78) translate(-256 -256)">${bars('#fff')}</g>`},
  glitch:{name:'Глитч',svg:u=>`${tile('#050505')}<g transform="translate(-12 -8)" opacity=".95">${bars('#25F4EE')}</g><g transform="translate(12 8)" opacity=".95">${bars('#FE2C55')}</g><g>${bars('#ffffff')}</g>`},
  flash:{name:'Вспышка',svg:u=>`${tile('#FFD60A')}<g>${bars('#111111')}</g><circle cx="424" cy="92" r="20" fill="#111"/>`},
  mono:{name:'Минимал',svg:u=>`<defs><linearGradient id="${u}g" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#2e7dff"/><stop offset="1" stop-color="#6a5cff"/></linearGradient></defs>${tile('#f5f6f8')}<g>${bars(i=>i===3?`url(#${u}g)`:'#0b0d11')}</g>`},
  sunset:{name:'Закат',svg:u=>`<defs><linearGradient id="${u}b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffb35c"/><stop offset=".5" stop-color="#ff3d77"/><stop offset="1" stop-color="#7a2cff"/></linearGradient></defs>${tile(`url(#${u}b)`)}<circle cx="256" cy="520" r="230" fill="#fff" opacity=".12"/><g>${bars('#fff')}</g>`}
};
let n=0;
window.LAZZY_LOGOS=L;
window.logoSVG=(id,cls='')=>{const l=L[id]||L.wave;const u='lz'+(n++);return `<svg class="${cls}" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><clipPath id="${u}c"><rect width="512" height="512" rx="128"/></clipPath><g clip-path="url(#${u}c)">${l.svg(u)}</g></svg>`};
/* The bare wave (no tile) — splash screen and notification glyph. */
window.logoBarsSVG=(fill='#fff')=>{const u='lzb'+(n++);return `<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${u}g" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#6a5cff"/><stop offset=".5" stop-color="#46b7ff"/><stop offset="1" stop-color="#8bf3e6"/></linearGradient></defs>${bars(fill==='grad'?`url(#${u}g)`:fill)}</svg>`};
})();
