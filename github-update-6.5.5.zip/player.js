'use strict';
/* Lazzy sound 3.3 — faster, sturdier playback.
   • Audius streams are resolved to their final content-node URL ahead of time (one redirect less at start).
   • The next track in the queue is resolved and pre-buffered while the current one plays.
   • A buffering ring shows while the stream is loading; a watchdog restarts a stream that stalls.
   • If a source fails, the same song is looked up in the other sources and playback continues there. */

/* ---------- Stream resolving (cached ~10 min) ---------- */
const resolvedStreams=new Map(),resolvePending=new Map();
window.__lazzyResolved=(id,url)=>{const p=resolvePending.get(id);if(!p)return;resolvePending.delete(id);clearTimeout(p.timer);p.resolve(url||'')};
function resolveStream(src,ms=900){
  if(!src||!/^https:\/\/api\.audius\.co\/v1\/tracks\//.test(src))return Promise.resolve('');
  const hit=resolvedStreams.get(src);if(hit&&Date.now()-hit.t<600000)return Promise.resolve(hit.url);
  if(!window.LumenNative?.resolveStream)return Promise.resolve('');
  return new Promise(resolve=>{const id='rs-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{resolvePending.delete(id);resolve('')},ms);
    resolvePending.set(id,{resolve:url=>{if(url)resolvedStreams.set(src,{t:Date.now(),url});resolve(url)},timer});try{LumenNative.resolveStream(src,id)}catch{clearTimeout(timer);resolve('')}});
}

/* ---------- Load: same contract as app.js, with resolving and a load token ---------- */
let loadToken=0;
load=async function(){
  const t=cur();if(!t)return;const token=++loadToken;
  if(!isFullAudio(t)){audio.pause();toast('Этот источник отключён: доступны только полные аудиофайлы');return}
  if(S.objUrl){URL.revokeObjectURL(S.objUrl);S.objUrl=null}
  document.body.classList.add('buffering');
  let src=t.src;
  if(t.type==='local'){const rec=await DB.get(t.id);if(!rec){toast('Файл не найден');document.body.classList.remove('buffering');return}src=S.objUrl=URL.createObjectURL(rec.blob)}
  else if(typeof isOffline==='function'&&isOffline(t)){src=offlineUrl(t)}
  else if(t.type==='audius'){src=resolvedStreams.get(t.src)?.url||(document.hidden?t.src:(await resolveStream(t.src,900))||t.src)}
  else if(t.type==='soundcloud'){try{src=await scResolve(t)}catch(e){document.body.classList.remove('buffering');toast(e.message);return}}
  if(token!==loadToken)return;
  stall.reset();audio.src=src;
  audio.play().catch(e=>{if(e.name!=='AbortError')toast('Не удалось воспроизвести. Попробуй другой трек.')});
  S.recent=[t,...S.recent.filter(r=>r.id!==t.id)].slice(0,30);store.set('recent',S.recent);
  updateUI();updateMediaSession();renderRecent();if(typeof playerContextChanged==='function')playerContextChanged();
  setTimeout(prefetchNext,document.hidden?500:4000);sendHandoff();
};

/* ---------- Pre-buffer the next track ---------- */
const warm=new Audio();warm.preload='auto';warm.muted=true;
function releaseWarm(){if(!warm.getAttribute('src'))return;warm.removeAttribute('src');delete warm.dataset.src;try{warm.load()}catch{}}
audio.addEventListener('loadstart',releaseWarm);
async function prefetchNext(){

  if(!S.queue.length||S.repeat==='one')return;if(S.shuffle&&S.queue.length>1&&(S.nextIdx==null||S.nextIdx===S.idx)){let k;do k=Math.floor(Math.random()*S.queue.length);while(k===S.idx);S.nextIdx=k}
  const n=S.queue[S.shuffle?S.nextIdx:S.idx+1];if(!n||n.type==='local'||n.type==='radio'||n.type==='youtube'||!isFullAudio(n))return;
  const url=n.type==='audius'?((await resolveStream(n.src,3000))||n.src):n.src;
  if(document.documentElement.dataset.perf==='low')return; // weak phones: resolve only, no second buffer
  if(warm.dataset.src===url)return;warm.dataset.src=url;try{warm.src=url;warm.load()}catch{}
}

/* ---------- Buffering ring ---------- */
const bufOn=()=>document.body.classList.add('buffering'),bufOff=()=>document.body.classList.remove('buffering');
audio.addEventListener('waiting',bufOn);audio.addEventListener('loadstart',bufOn);
for(const ev of ['playing','canplaythrough','pause','error','ended'])audio.addEventListener(ev,bufOff);
audio.addEventListener('timeupdate',()=>{if(!audio.paused&&audio.readyState>=3)bufOff()});

/* ---------- Stall watchdog: reload in place if nothing moves for 12 s ---------- */
const stall={last:0,at:0,timer:0,reset(){this.last=-1;this.at=Date.now()}};
setInterval(()=>{if(audio.paused||!audio.src||!isFinite(audio.duration))return;const c=audio.currentTime;
  if(c!==stall.last){stall.last=c;stall.at=Date.now();return}
  if(Date.now()-stall.at>12000){stall.at=Date.now();const pos=c;const s=audio.src;audio.src=s;audio.currentTime=pos;audio.play().catch(()=>{});toast('Поток подвис — переподключаемся')}},2000);

/* ---------- Source failed → same song from another source, else skip ---------- */
async function findAlternative(t){
  if(typeof sourceJobs!=='function')return null;const q=t.artist+' '+t.title;
  const jobs=sourceJobs(q,{withLocal:false,withCatalog:false,withRadio:false}).filter(([s])=>!s.startsWith(t.type)&&!/^youtube/.test(s));
  const out=(await Promise.all(jobs.map(([s,fn])=>bounded(cachedSearch(s,q,fn),9000).catch(()=>[])))).flat();
  return out.filter(c=>isFullAudio(c)&&c.type!=='youtube'&&c.src!==t.src&&similarity(t.title,c.title)>.82&&similarity(t.artist,c.artist)>.6&&(!t.duration||!c.duration||Math.abs(t.duration-c.duration)<12))[0]||null;
}
audio.addEventListener('error',async()=>{
  const t=cur();if(!t||!audio.src||t.type==='radio'||t.type==='local'||t._alt)return;const idx=S.idx,token=loadToken;
  const host=(()=>{try{return new URL(audio.currentSrc||audio.src).host}catch{return '?'}})();toast('Источник недоступен ('+host+', ошибка '+(audio.error?.code||'?')+') — ищем этот трек в других');
  const alt=await findAlternative(t).catch(()=>null);if(token!==loadToken||S.idx!==idx)return;
  if(alt){S.queue[idx]={...alt,_alt:true,_wave:t._wave,album:t.album,albumName:t.albumName,albumTrackId:t.albumTrackId};load();toast('Играет из '+(PROVIDER_LABELS[alt.type]||alt.type))}
  else if(S.idx<S.queue.length-1){toast('Не нашли рабочий источник — следующий трек');setTimeout(()=>{if(token===loadToken)next()},900)}
});

/* Warm up connections to the stream hosts before the first tap. */
for(const h of ['https://api.audius.co','https://archive.org','https://ia800000.us.archive.org','https://upload.wikimedia.org'])
  {const l=document.createElement('link');l.rel='preconnect';l.href=h;l.crossOrigin='';document.head.appendChild(l)}

/* ---------- 3.4: system media notification + background playback ----------
   Every play / pause / track change is reported to the native PlaybackService, which keeps the app in the
   foreground while minimised and turns notification, lock-screen and headset buttons into player commands. */
let lastMediaState='';
function pushMediaState(){
  const t=cur();if(!t||!window.LumenNative?.mediaState)return;
  const live=!isFinite(audio.duration);
  const s={title:t.title||'Lazzy sound',artist:t.type==='radio'?'Радио':(t.artist||''),art:/^https:\/\//.test(t.art||'')?t.art:'',playing:!audio.paused,
    duration:live?0:Math.round((audio.duration||0)*1000),position:Math.round((audio.currentTime||0)*1000)};
  const key=JSON.stringify(s);if(key===lastMediaState)return;lastMediaState=key;
  try{LumenNative.mediaState(key)}catch{}
}
for(const ev of ['play','playing','pause','loadedmetadata','seeked'])audio.addEventListener(ev,pushMediaState);
window.__lazzyMedia=(cmd,arg)=>{
  if(cmd==='play'){if(cur())audio.play().catch(()=>{})}
  else if(cmd==='pause')audio.pause();
  else if(cmd==='next')next();
  else if(cmd==='prev')prev();
  else if(cmd==='seek'&&isFinite(audio.duration))audio.currentTime=Math.max(0,Math.min(audio.duration,(+arg||0)/1000));
};
/* When the phone is locked, keep the end-of-track hand-off robust: if the next track was refused autoplay, retry once. */
audio.addEventListener('ended',()=>{const token=loadToken;setTimeout(()=>{if(token!==loadToken&&audio.paused&&audio.src&&document.hidden)audio.play().catch(()=>{})},2500)});


/* ---------- Native hand-off: if the app is closed while playing, Android keeps playing this list ---------- */
function handoffUrl(t,isCur){
  if(!t||t.type==='local'||(window.isHitmoz&&isHitmoz(t)))return '';
  if(typeof isOffline==='function'&&isOffline(t))return 'offline:'+t.id;
  if(isCur&&/^https?:\/\//.test(audio.currentSrc||'')&&!audio.currentSrc.startsWith(location.origin))return audio.currentSrc;
  if(t.type==='soundcloud')return '';
  if(t.type==='audius')return resolvedStreams.get(t.src)?.url||t.src;
  return /^https?:\/\//.test(t.src||'')?t.src:'';
}
function sendHandoff(){
  if(!window.LumenNative?.setHandoff)return;const q=S.queue,start=S.idx;if(!q.length||start<0)return;
  let order=[start];if(S.shuffle){const rest=q.map((_,i)=>i).filter(i=>i!==start);for(let i=rest.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[rest[i],rest[j]]=[rest[j],rest[i]]}if(S.nextIdx!=null)rest.sort((a,b)=>(b===S.nextIdx)-(a===S.nextIdx));order=order.concat(rest)}
  else{for(let i=start+1;i<q.length;i++)order.push(i);if(S.repeat==='all')for(let i=0;i<start;i++)order.push(i)}
  const list=[],tracks=[];for(const i of order.slice(0,60)){const t=q[i],url=handoffUrl(t,i===start);if(!url)continue;list.push({id:t.id,title:t.title||'',artist:t.artist||'',art:/^https:/.test(t.art||'')?t.art:'',url});tracks.push(t)}
  try{LumenNative.setHandoff(list.length?JSON.stringify({items:list}):'');store.set('handoffQueue',tracks.map(t=>{const {blob,_rank,providers,...c}=t;return c}))}catch{}
}
/* the app was reopened while Android kept playing: continue here from the same place */
setTimeout(()=>{let h=null;try{h=JSON.parse(window.LumenNative?.takeHandoff?.()||'null')}catch{}if(!h||!h.id)return;
  const list=store.get('handoffQueue',[]);const i=list.findIndex(t=>t.id===h.id);if(i<0)return;S.queue=list;S.idx=i;
  const pos=(h.pos||0)/1000;audio.addEventListener('loadedmetadata',function f(){audio.removeEventListener('loadedmetadata',f);try{audio.currentTime=pos}catch{}if(!h.playing)audio.pause()});
  load()},300);
