'use strict';
/* 5.9: TheAudioDB (artist info), Deezer (chart, related artists, covers), Songlink (open in other services), Mixcloud (mixes), Phish.in (legal live tracks) */
const EXT_OK=/^https:\/\/(api\.deezer\.com|www\.theaudiodb\.com|api\.song\.link|api\.mixcloud\.com|phish\.in|ru\.wikipedia\.org|en\.wikipedia\.org|www\.wikidata\.org|musicbrainz\.org|api\.genius\.com)\//;
const extCache=new Map();
function jsonp(url,param){return new Promise((res,rej)=>{const cb='__lzj'+Date.now().toString(36)+Math.random().toString(36).slice(2,7),s=document.createElement('script');
  const end=()=>{clearTimeout(tm);delete window[cb];s.remove()},tm=setTimeout(()=>{end();rej(new Error('timeout'))},10000);
  window[cb]=j=>{end();res(j)};s.onerror=()=>{end();rej(new Error('jsonp'))};s.src=url+(url.includes('?')?'&':'?')+param+cb;document.head.appendChild(s)})}
async function extGet(url,ttl=6*3600e3){
  if(!EXT_OK.test(url))throw new Error('host');const c=extCache.get(url);if(c&&Date.now()-c.t<ttl)return c.j;
  let j;
  if(window.LumenNative?.publicCatalog&&typeof publicCatalog==='function')j=await publicCatalog('get',{url});
  else if(url.startsWith('https://api.deezer.com/'))j=await jsonp(url,'output=jsonp&callback=');
  else if(url.startsWith('https://api.mixcloud.com/'))j=await jsonp(url,'callback=');
  else{const r=await bounded(fetch(url,{credentials:'omit'}),10000);if(!r.ok)throw new Error('HTTP '+r.status);j=await r.json()}
  if(j?.results&&!Array.isArray(j)&&Object.keys(j).length===1&&Array.isArray(j.results)&&!/theaudiodb/.test(url))j=j.results;
  extCache.set(url,{t:Date.now(),j});if(extCache.size>200)extCache.delete(extCache.keys().next().value);return j}
const httpsOr=(u,d='')=>/^https:\/\//.test(u||'')?u:d;
const encQ=s=>encodeURIComponent(String(s||'').slice(0,150));

/* ---------- Deezer ---------- */
async function deezerArtist(name){const j=await extGet('https://api.deezer.com/search/artist?limit=5&q='+encQ(name));return (j.data||[]).find(a=>sameArtist(name,a.name))||null}
async function deezerTrack(t){const q=`artist:"${t.artist}" track:"${plainTitle(t.title)}"`;let j=await extGet('https://api.deezer.com/search?limit=5&q='+encQ(q));
  if(!(j.data||[]).length)j=await extGet('https://api.deezer.com/search?limit=5&q='+encQ(t.artist+' '+t.title));
  return (j.data||[]).find(x=>similarity(t.title,x.title)>.5&&similarity(t.artist,x.artist?.name||'')>.5)||null}
const mapDz=x=>({id:'dz:'+x.id,type:'deezer',title:x.title||'',artist:x.artist?.name||'',art:httpsOr(x.album?.cover_xl||x.album?.cover_big),duration:+x.duration||0,meta:fmt(+x.duration||0),sourceUrl:httpsOr(x.link,'https://www.deezer.com')});
/* chart entries are metadata: tap → the full track is found in the app's own sources */
async function playByName(t){toast('Ищем полный трек…');
  try{const r=await searchEverywhere(t.artist+' '+t.title);const full=r.filter(isFullAudio).map(x=>({x,s:similarity(t.title,x.title)+similarity(t.artist,x.artist)})).sort((a,b)=>b.s-a.s);
    if(full[0]&&full[0].s>1.1){playTrack([full[0].x],0);return}}catch{}
  toast('Полной версии в источниках нет · открыть в Deezer можно из меню трека')}

let dzChart=store.get('dzChart',{t:0,items:[]}).items||[];
function paintDzChart(){const el=$('#shelfDeezer');if(!el)return;el.closest('.shelf').hidden=!dzChart.length;
  el.innerHTML=dzChart.slice(0,20).map((t,i)=>cardHTML(t,i,(i+1)+' · '+t.artist)).join('');
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(b)playByName(dzChart[+b.dataset.i])}}
async function loadDzChart(){paintDzChart();if(Date.now()-(store.get('dzChart',{}).t||0)<3*3600e3&&dzChart.length)return;
  try{const j=await extGet('https://api.deezer.com/chart/0/tracks?limit=30');const list=(j.data||[]).map(mapDz).filter(t=>t.title);if(list.length){dzChart=list;store.set('dzChart',{t:Date.now(),items:list});paintDzChart()}}catch{}}
{const tr=$('#shelfTrending')?.closest('.shelf');if(tr&&!$('#shelfDeezer'))tr.insertAdjacentHTML('afterend','<section class="shelf" hidden><div class="shelf-head"><h2>Мировой чарт</h2><span class="shelf-sub">Deezer</span></div><div class="cards" id="shelfDeezer"></div></section>');loadDzChart()}

/* ---------- TheAudioDB + Deezer + Mixcloud on the artist page ---------- */
async function audioDbArtist(name){const j=await extGet('https://www.theaudiodb.com/api/v1/json/123/search.php?s='+encQ(name),24*3600e3);return (j.artists||[]).find(a=>sameArtist(name,a.strArtist))||null}
async function audioDbVideos(id){if(!/^\d+$/.test(id||''))return [];const j=await extGet('https://www.theaudiodb.com/api/v1/json/123/mvid.php?i='+id,24*3600e3);return (j.mvids||[]).filter(v=>/^https?:\/\/(www\.)?(youtube\.com|youtu\.be)\//.test(v.strMusicVid||''))}
async function mixcloudSearch(q){const j=await extGet('https://api.mixcloud.com/search/?type=cloudcast&limit=12&q='+encQ(q));
  return (j.data||[]).filter(m=>/^https:\/\/www\.mixcloud\.com\//.test(m.url||'')).map(m=>({title:m.name||'Микс',artist:m.user?.name||'Mixcloud',art:httpsOr(m.pictures?.extra_large||m.pictures?.large),url:m.url,dur:+m.audio_length||0}))}
function extHost(){let el=$('#colExtra');if(!el){$('#colSections').insertAdjacentHTML('afterend','<div id="colExtra" class="col-sections col-extra"></div>');el=$('#colExtra')}return el}
const baseOpenCollection59=openCollection;
openCollection=function(o){const el=$('#colExtra');if(el)el.innerHTML='';return baseOpenCollection59(o)};
const baseOpenArtist59=openArtist;
openArtist=function(a){baseOpenArtist59(a);const fid=colState?.followId,name=a.name;if(!name)return;const live=()=>colState?.followId===fid;
  Promise.allSettled([audioDbArtist(name),deezerArtist(name),mixcloudSearch(name)]).then(async([adb,dz,mx])=>{
    if(!live())return;const A=adb.value,D=dz.value,M=(mx.value||[]).filter(m=>similarity(name,m.title+' '+m.artist)>.5).slice(0,10);
    const pic=httpsOr(A?.strArtistThumb)||httpsOr(D?.picture_xl),back=httpsOr(A?.strArtistFanart)||httpsOr(A?.strArtistBanner)||pic;
    if(pic&&!colState.art){colState.art=pic;setCover($('#colCover'),{title:name,art:pic})}
    if(back)$('#colBackdrop').style.backgroundImage=`url('${back.replace(/'/g,'%27')}')`;
    const [vids,rel]=await Promise.all([A?audioDbVideos(A.idArtist).catch(()=>[]):[],D?extGet('https://api.deezer.com/artist/'+D.id+'/related?limit=12').then(j=>j.data||[]).catch(()=>[]):[]]);
    if(!live())return;const el=extHost();const bio=(A?.strBiographyRU||A?.strBiographyEN||'').trim();
    const facts=[A?.strGenre,A?.strCountry,A?.intFormedYear&&+A.intFormedYear?'с '+A.intFormedYear:'',D?.nb_fan?compactNum(D.nb_fan)+' фанатов Deezer':''].filter(Boolean);
    let h='';
    if(bio||facts.length)h+=`<div class="ext-about"><div class="shelf-head"><h2>Об исполнителе</h2><span class="shelf-sub">TheAudioDB</span></div>${facts.length?`<p class="ext-facts">${facts.map(esc).join(' · ')}</p>`:''}${bio?`<p class="ext-bio">${esc(bio)}</p><button class="text-link ext-more">Читать полностью</button>`:''}${A?.strWebsite?`<button class="chip ext-link" data-url="https://${esc(A.strWebsite.replace(/^https?:\/\//,''))}"><svg><use href="#i-external"/></svg>Сайт</button>`:''}</div>`;
    if(vids.length)h+=`<div class="shelf-head"><h2>Клипы</h2><span class="shelf-sub">YouTube</span></div><div class="cards">${vids.slice(0,10).map((v,i)=>`<button class="card" data-url="${esc(v.strMusicVid)}"><span class="card-art">${coverHTML({title:v.strTrack||'Клип',artist:name,art:httpsOr(v.strTrackThumb)},'cv-lg')}</span><b>${esc(v.strTrack||'Клип')}</b><small>Клип</small></button>`).join('')}</div>`;
    if(rel.length)h+=`<div class="shelf-head"><h2>Похожие исполнители</h2><span class="shelf-sub">Deezer</span></div><div class="cards ext-rel">${rel.map((r,i)=>`<button class="card" data-rel="${i}"><span class="card-art round">${coverHTML({title:r.name,artist:'',art:httpsOr(r.picture_xl||r.picture_big)},'cv-lg')}</span><b>${esc(r.name)}</b><small>${r.nb_fan?compactNum(r.nb_fan)+' фанатов':'Исполнитель'}</small></button>`).join('')}</div>`;
    if(M.length)h+=`<div class="shelf-head"><h2>Миксы и сеты</h2><span class="shelf-sub">Mixcloud</span></div><div class="cards">${M.map(m=>`<button class="card" data-url="${esc(m.url)}"><span class="card-art">${coverHTML(m,'cv-lg')}</span><b>${esc(m.title)}</b><small>${esc(m.artist)}${m.dur?' · '+fmt(m.dur):''}</small></button>`).join('')}</div>`;
    el.innerHTML=h;
    if(typeof artistInfo==='function')artistInfo(name).then(info=>{if(!live())return;const html=aboutHTML(name,info,A,D);if(!html)return;const old=el.querySelector('.ext-about');if(old)old.outerHTML=html;else el.insertAdjacentHTML('afterbegin',html)}).catch(()=>{});
    el.onclick=e=>{const u=e.target.closest('[data-url]');if(u){window.open(u.dataset.url,'_blank','noopener');return}
      const r=e.target.closest('[data-rel]');if(r){const x=rel[+r.dataset.rel];openArtist({name:x.name,art:httpsOr(x.picture_xl||x.picture_big)});return}
      const g=e.target.closest('#aiBioGen');if(g){g.disabled=true;g.lastChild.textContent='ИИ вспоминает…';aiBio(name).then(t=>{const f=g.closest('.ai-bio-foot');if(!t){g.lastChild.textContent='ИИ не знает этого исполнителя';return}f.outerHTML=`<p class="ext-bio open">${esc(t)}</p><div class="ai-bio-foot"><small>Кратко от ИИ — может быть неточно</small></div>`}).catch(err=>{g.disabled=false;g.lastChild.textContent=err.message||'Не получилось'});return}
      if(e.target.closest('.ext-more')){el.querySelector('.ext-bio')?.classList.toggle('open');const b=el.querySelector('.ext-more');b.textContent=el.querySelector('.ext-bio.open')?'Свернуть':'Читать полностью'}};
  })};

/* ---------- Songlink: the same track in other services ---------- */
const SL_NAMES={spotify:'Spotify',appleMusic:'Apple Music',youtube:'YouTube',youtubeMusic:'YouTube Music',yandex:'Яндекс Музыка',deezer:'Deezer',soundcloud:'SoundCloud',tidal:'TIDAL',amazonMusic:'Amazon Music',pandora:'Pandora',audiomack:'Audiomack',anghami:'Anghami',boomplay:'Boomplay',napster:'Napster',itunes:'iTunes',bandcamp:'Bandcamp',audius:'Audius'};
async function songLinks(t){const d=t.type==='deezer'?{id:String(t.id).slice(3)}:await deezerTrack(t);if(!d)return null;
  const j=await extGet('https://api.song.link/v1-alpha.1/links?songIfSingle=true&url='+encodeURIComponent('https://www.deezer.com/track/'+d.id),24*3600e3);
  const L=j?.linksByPlatform||{};return {page:httpsOr(j?.pageUrl),list:Object.entries(L).filter(([k,v])=>SL_NAMES[k]&&/^https:\/\//.test(v?.url||'')).map(([k,v])=>({k,name:SL_NAMES[k],url:v.url}))}}
const baseTrackInfo59=openTrackInfo;
openTrackInfo=function(t){const r=baseTrackInfo59(t);const row=$('#sheetActions .track-actions');
  if(row&&t&&t.type!=='radio'&&t.type!=='album'&&t.title&&t.artist&&!$('#infoSl')){row.insertAdjacentHTML('beforeend','<button class="chip" id="infoSl"><svg><use href="#i-external"/></svg>Открыть в…</button>');
    $('#infoSl').onclick=async()=>{const b=$('#infoSl');b.disabled=true;const box=document.createElement('div');box.className='ext-sl';box.innerHTML='<div class="loader"><i></i><i></i><i></i></div>';$('#sheetList').prepend(box);
      try{const s=await songLinks(t);if(!s||!s.list.length)throw 0;
        box.innerHTML=`<div class="track-actions">${s.list.map(x=>`<button class="chip" data-url="${esc(x.url)}">${esc(x.name)}</button>`).join('')}${s.page?`<button class="chip" data-url="${esc(s.page)}">Все сервисы</button>`:''}</div><small>Ссылки: Songlink / Odesli</small>`;
        box.onclick=e=>{const u=e.target.closest('[data-url]');if(u)window.open(u.dataset.url,'_blank','noopener')}}
      catch{box.innerHTML='<p class="info-muted">Трек не найден в других сервисах</p>'}}}
  return r};

/* ---------- Phish.in: full, legal live recordings (only for queries that name the band) ---------- */
async function searchPhish(q){const term=q.replace(/\bphish\b/ig,'').trim()||'';
  const j=await extGet(term?'https://phish.in/api/v2/search/'+encodeURIComponent(term.slice(0,80)):'https://phish.in/api/v2/tracks?per_page=40&sort=likes_count:desc');
  const arr=Array.isArray(j)?j:(j.tracks||j.data||[]);
  return arr.flatMap(x=>{const u=httpsOr(x.mp3_url||x.mp3);if(!u)return [];const ms=+x.duration||0,sec=ms>20000?Math.round(ms/1000):ms;
    return [{id:'phish:'+(x.id||x.slug||u),type:'phish',title:String(x.title||'Track').slice(0,300),artist:'Phish',src:u,art:httpsOr(x.show_cover_art_urls?.medium||x.show_album_cover_url||x.waveform_image_url),
      duration:sec,meta:[x.show_date,x.venue_name].filter(Boolean).join(' · ')||fmt(sec),sourceUrl:httpsOr(x.url,'https://phish.in'),fullStream:true}]})}
const baseSourceJobs59=sourceJobs;
sourceJobs=function(q,o){const jobs=baseSourceJobs59(q,o);if(/\bphish\b/i.test(q))jobs.push(['phish',()=>searchPhish(q)]);return jobs};
Object.assign(PROVIDER_LABELS,{phish:'Phish.in',deezer:'Deezer'});

/* ---------- 6.0.4: artist page gets the whole catalogue — the artist's top songs (Deezer) and album tracks are looked up
   one by one in the app's own sources (no YouTube: its daily search limit is too small for this) ---------- */
async function artistSearchOne(q){const jobs=sourceJobs(q,{withLocal:false,withCatalog:false,withRadio:false}).filter(([s])=>!/^youtube/.test(s));
  const out=await Promise.all(jobs.map(([src,fn])=>bounded(cachedSearch(src,q,fn),12000).catch(()=>[])));return out.flat()}
async function artistDeepFill(name,fid){
  const live=()=>colState?.followId===fid;for(let i=0;i<60&&live()&&$('#colList .loader');i++)await new Promise(z=>setTimeout(z,500));if(!live())return;
  const D=await deezerArtist(name).catch(()=>null);if(!D||!live())return ytArtistFill(name,fid);
  const top=(await extGet('https://api.deezer.com/artist/'+D.id+'/top?limit=60').catch(()=>({}))).data||[];
  const key=s=>normalize(plainTitle(String(s||'')).replace(/\s*[\[(].*?[\])]/g,''));
  const titles=[...new Map(top.map(x=>[key(x.title),x.title])).values()];if(!titles.length)return ytArtistFill(name,fid);
  const lab=$('#colListLabel'),base='Треки';let found=0,done=0,paint=0;
  const have=()=>new Set((colState.tracks||[]).map(t=>key(t.title)));
  const queue=titles.filter(t=>!have().has(key(t)));if(!queue.length)return ytArtistFill(name,fid);
  const status=()=>{if(live()&&lab)lab.textContent=done<queue.length?`${base} · ищем ещё ${queue.length-done}…`:base};status();
  const work=async()=>{while(queue.length&&live()){const title=queue.shift();
      try{if(!have().has(key(title))){const r=(await artistSearchOne(name+' '+title)).filter(isFullAudio).map(x=>({x,s:similarity(title,x.title)+(artistMatch(name,x.artist||'')?1:0)})).filter(o=>o.s>1.7).sort((a,b)=>b.s-a.s);
        if(r[0]&&live()&&!have().has(key(r[0].x.title))){colState.tracks.push(r[0].x);found++;clearTimeout(paint);paint=setTimeout(()=>{if(live())renderCollection()},400)}}}catch{}
      done++;status()}};
  const total=queue.length;await Promise.all([work(),work(),work()]);if(live()&&lab)lab.textContent=base;
  if(found&&live())renderCollection();await ytArtistFill(name,fid)}
/* 6.3.2: artist with fewer than 3 playable tracks (e.g. Russian artists whose only source was Hitmoz) — one cached YouTube search fills the page */
async function ytArtistFill(name,fid){
  const live=()=>colState?.followId===fid;if(!live()||(colState.tracks||[]).filter(isFullAudio).length>=3||typeof searchYouTube!=='function')return;
  const key=s=>normalize(plainTitle(String(s||'')));const have=new Set((colState.tracks||[]).map(t=>key(t.title)));
  const yt=(await bounded(cachedSearch('youtube',name,()=>searchYouTube(name)),12000).catch(()=>[])).filter(t=>t.type==='youtube'&&artistMatch(name,t.artist||'')&&!have.has(key(t.title)));
  if(!yt.length||!live())return;colState.tracks.push(...yt.slice(0,40));renderCollection();const lab=$('#colListLabel');if(lab)lab.textContent='Треки · с YouTube'}
const baseOpenArtist604=openArtist;
openArtist=function(a){baseOpenArtist604(a);const fid=colState?.followId;if(a?.name)setTimeout(()=>{if(colState?.followId===fid)artistDeepFill(a.name,fid)},1500)};
