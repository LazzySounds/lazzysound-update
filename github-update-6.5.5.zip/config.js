/* Lazzy sound — build-time configuration.
   Paste your Google OAuth client (type "Desktop app", Google Drive API enabled) here to enable
   "Sign in with Google" for every user without manual setup. Desktop-app client secrets are not
   confidential by Google's design for installed apps (PKCE protects the flow). */
window.LAZZY_CONFIG = {
  googleClientId: '397850677407-3r929kfvubic2783itr563d3h7f568p8.apps.googleusercontent.com',
  googleWebClientId:'397850677407-s17lhftln6q9dvb5ijo1srlm1im2cqsa.apps.googleusercontent.com',
  googleClientSecret: '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',
  // Accounts: free Firebase Spark project (Firestore only). Uploads go to the uploader's Google Drive.
  // Groq key built in for everyone: Whisper word timestamps for exact lyrics sync
  updateRepo:'LazzySounds/lazzysound-update',
  updateBase:'https://lazzysound.netlify.app/',
  ownerTelegram:'+6YcH54fqGrFhZDIy',
  geniusToken:'XfwRqzQ1fIowokOYyrmMpDnUHXUG2dD3blfO275Lwl2cxtS_DsyGgfL7',
  youtubeKey:'AIzaSyDxrxmFhw6OD6L1nzj3I89wGkiScuWVp-g',
  groqKey: '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',
  firebase: { apiKey: 'AIzaSyADtSaZDPRL4ZH5AZWI1o9KKaOnrYIMJL4', projectId: 'lazzy-sounds-b04cf' }
};
