'use strict';
/* Lazzy sound 5.0 — Yandex Music import: liked tracks, playlists, albums (metadata only, your own token).
   Every track is matched to a playable copy on the app's sources, like the Spotify import. */
const YM={pending:new Map(),has:(()=>{try{return !!window.LumenNative?.hasYandexToken?.()}catch{return false}})(),uid:''};
window.__lazzyYM=(id,payload)=>{const p=YM.pending.get(id);if(!p)return;YM.pending.delete(id);clearTimeout(p.t);try{const j=JSON.parse(payload);if(j.connectorError)throw new Error(j.connectorError==='auth'?'Яндекс не принял токен':j.connectorError==='notfound'?'Не найдено (или плейлист закрыт)':'Яндекс Музыка недоступна');p.resolve(j.result??j)}catch(e){p.reject(e)}};
const ymApi=(path,form=null)=>new Promise((resolve,reject)=>{if(!window.LumenNative?.yandexApi){reject(new Error('Импорт Яндекса работает в приложении'));return}
  const id='ym-'+Date.now()+'-'+Math.random().toString(36).slice(2);const t=setTimeout(()=>{YM.pending.delete(id);reject(new Error('Яндекс не ответил'))},30000);YM.pending.set(id,{resolve,reject,t});LumenNative.yandexApi(path,form,id)});
const ymTrack=t=>t&&t.title&&t.available!==false?{title:t.title,artist:(t.artists||[]).map(a=>a.name).join(', '),duration:Math.round((t.durationMs||0)/1000),album:t.albums?.[0]?.title||'',art:t.coverUri?'https://'+t.coverUri.replace('%%','400x400'):''}:null;
async function ymUid(){if(YM.uid)return YM.uid;const r=await ymApi('/account/status');YM.uid=String(r.account?.uid||'');if(!YM.uid)throw new Error('Токен не подходит');return YM.uid}
async function ymTracksByIds(ids){const out=[];for(let k=0;k<ids.length;k+=200){const r=await ymApi('/tracks','track-ids='+ids.slice(k,k+200).join(','));out.push(...(Array.isArray(r)?r:[]))}return out}
const ymPl=r=>(r.tracks||[]).map(x=>x.track||x).map(ymTrack).filter(Boolean);
async function ymLiked(){const uid=await ymUid();const r=await ymApi(`/users/${uid}/likes/tracks`);const ids=(r.library?.tracks||[]).map(x=>x.albumId?`${x.id}:${x.albumId}`:String(x.id));return (await ymTracksByIds(ids)).map(ymTrack).filter(Boolean)}
async function ymPlaylist(owner,kind){const r=await ymApi(`/users/${encodeURIComponent(owner)}/playlists/${kind}?rich-tracks=true`);let items=ymPl(r);
  if(!items.length&&r.tracks?.length)items=(await ymTracksByIds(r.tracks.map(x=>String(x.id)))).map(ymTrack).filter(Boolean);return {name:r.title||'Яндекс Музыка',items}}
async function ymImportRun(name,load){const ui=importProgressUI(name);try{const x=await load();showImportResult(await runImport(x.name||name,x.items||x,ui))}catch(e){$('#impText').textContent=e.message}}
async function importFromYandex(){
  if(!YM.has){go('profile');window.setProfileTab?.('sources');setTimeout(()=>$('#ymSettings')?.scrollIntoView({behavior:'smooth',block:'start'}),200);toast('Вставь токен Яндекс Музыки');return}
  openSheet({title:'Импорт из Яндекс Музыки',sub:'Выбери, что перенести',tracks:[],cover:{title:'Яндекс'}});$('#sheet').dataset.mode='import';$('#sheetActions').innerHTML='';loading($('#sheetList'));
  try{const uid=await ymUid();const pls=await ymApi(`/users/${uid}/playlists/list`);
    const rows=[{id:'liked',name:'Мне нравится',count:''},...(Array.isArray(pls)?pls:[]).map(p=>({id:p.kind,owner:p.owner?.uid||uid,name:p.title,count:p.trackCount??''}))];
    $('#sheetList').innerHTML=rows.map((r,i)=>`<button class="lib-row" data-ym="${i}"><div class="cover pl-empty"><svg><use href="#i-${r.id==='liked'?'heart-f':'queue'}"/></svg></div><span class="meta"><b>${esc(r.name)}</b><span>${r.count===''?'':r.count+' треков'}</span></span></button>`).join('');
    $('#sheetList').onclick=e=>{const b=e.target.closest('[data-ym]');if(!b)return;const r=rows[+b.dataset.ym];$('#sheetList').innerHTML='';
      ymImportRun(r.name,async()=>r.id==='liked'?{name:'Мне нравится · Яндекс',items:await ymLiked()}:ymPlaylist(r.owner,r.id))};
  }catch(e){$('#sheetList').innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}
/* links: /users/<login>/playlists/<kind>, /album/<id>, /album/<a>/track/<t>, /track/<t>, /playlists/<uuid> */
function ymFromLink(url){
  if(!/music\.yandex\.(ru|com|by|kz|uz)\//.test(url))return false;
  let m=url.match(/\/users\/([^/?#]+)\/playlists\/(\d+)/);if(m){ymImportRun('Яндекс Музыка',()=>ymPlaylist(decodeURIComponent(m[1]),m[2]));return true}
  m=url.match(/\/playlists\/([A-Za-z0-9.-]{8,64})/);if(m){ymImportRun('Яндекс Музыка',async()=>{const r=await ymApi('/playlist/'+m[1]+'?rich-tracks=true');return {name:r.title,items:ymPl(r)}});return true}
  m=url.match(/\/track\/(\d+)/);if(m){ymImportRun('Яндекс Музыка',async()=>{const r=await ymApi('/tracks/'+m[1]);const t=ymTrack(Array.isArray(r)?r[0]:r);return {name:t?.title||'Трек',items:t?[t]:[]}});return true}
  m=url.match(/\/album\/(\d+)/);if(m){ymImportRun('Яндекс Музыка',async()=>{const r=await ymApi(`/albums/${m[1]}/with-tracks`);return {name:r.title,items:(r.volumes||[]).flat().map(ymTrack).filter(Boolean)}});return true}
  return false;
}
function renderYmSettings(){
  const host=$('#ymSettings');if(!host)return;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-cloud"/></svg><h2>Яндекс Музыка (импорт)</h2></div>
    <p class="settings-help">Переносит «Мне нравится» и плейлисты: берутся только названия, каждый трек ищется в доступных источниках. Как получить токен: <b>ym.marshal.dev/token</b>. Токен хранится зашифрованным на устройстве.</p>
    <label class="field-label" for="ymTok">Токен</label><input class="settings-input" id="ymTok" type="password" autocomplete="off" spellcheck="false" placeholder="${YM.has?'Сохранён':'y0_…'}">
    <div class="api-actions"><button class="btn-accent" id="ymSave">Сохранить</button>${YM.has?'<button class="chip" id="ymOut">Удалить</button>':''}<button class="chip" id="ymImport">Импорт</button></div>
    <p class="api-status">${YM.has?'Подключён':'Не подключён — публичные плейлисты по ссылке работают и без токена'}</p>`;
  $('#ymSave').onclick=()=>{const v=$('#ymTok').value.trim();let ok=false;try{ok=!!LumenNative.saveYandexToken(v)}catch{}if(!ok){toast('Токен не подошёл');return}YM.has=!!v;YM.uid='';renderYmSettings();toast('Сохранено')};
  if($('#ymOut'))$('#ymOut').onclick=()=>{try{LumenNative.saveYandexToken('')}catch{}YM.has=false;YM.uid='';renderYmSettings()};
  $('#ymImport').onclick=importFromYandex;
}
renderYmSettings();
/* hook into the import menu and «По ссылке» */
const baseImportFromLink=importFromLink;
importFromLink=async function(given){const url=(typeof given==='string'?given:(await askText('Ссылка на плейлист, альбом или трек','')||'')).trim();if(!url)return;if(ymFromLink(url))return;return baseImportFromLink(url)};
const baseOpenImportMenu=openImportMenu;
openImportMenu=function(){baseOpenImportMenu();$('#sheetList').insertAdjacentHTML('beforeend','<button class="lib-row" data-imp="ym"><div class="cover pl-empty"><svg><use href="#i-cloud"/></svg></div><span class="meta"><b>Яндекс Музыка</b><span>«Мне нравится» и плейлисты</span></span></button>');
  const h=$('#sheetList').onclick;$('#sheetList').onclick=e=>{const b=e.target.closest('[data-imp="ym"]');if(b){importFromYandex();return}h(e)}};
