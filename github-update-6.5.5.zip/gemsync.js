'use strict';
/* 6.3.4: Gemini listens to the track and returns when each lyric line starts. */
const GEM={busy:new Set(),on:store.get('gemOn',true)!==false};
const gemKey=()=>(window.LAZZY_CONFIG||{}).geminiKey||store.get('geminiKey','')||(AiConf.provider==='gemini'&&!window.LumenNative?.aiRequest?localStorage.getItem('lumen.aiKeyWeb')||'':'');
const b64=blob=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(String(r.result).split(',')[1]||'');r.onerror=()=>no(new Error('чтение файла'));r.readAsDataURL(blob)});
async function gemYtCopy(t){
  if(typeof searchYouTube!=='function')return null;const d=liveDur(t)||audio.duration||0;
  const list=await searchYouTube(cleanArtist(t.artist)+' '+cleanTitle(t.title)).catch(()=>[]);
  const ok=c=>c.yt&&similarity(normalize(cleanTitle(t.title)),normalize(cleanTitle(c.title||'')))>.5&&(!d||!c.duration||Math.abs(c.duration-d)<=4);
  const c=list.find(c=>ok(c)&&artistSim(t.artist,c.artist||'')>.5)||list.find(c=>ok(c)&&normalize(c.title).includes(normalize(cleanArtist(t.artist))));
  return c?{file_data:{file_uri:'https://www.youtube.com/watch?v='+c.yt}}:null}
async function gemAudioPart(t){try{return await gemAudioPart0(t)}catch(e){const y=await gemYtCopy(t).catch(()=>null);if(y)return y;e.noAudio=true;throw e}}
async function gemAudioPart0(t){
  if(t.type==='youtube'&&t.yt)return {file_data:{file_uri:'https://www.youtube.com/watch?v='+t.yt}};
  const N=window.LumenNative;let url=cur()?.id===t.id&&/^https?:|^blob:/.test(audio.currentSrc||'')?audio.currentSrc:'';
  if(!url&&typeof isOffline==='function'&&isOffline(t))url=offlineUrl(t);
  if(!url&&/^https:\/\//.test(t.src||''))url=(typeof resolveStream==='function'?await resolveStream(t.src,4000):'')||t.src;
  if(!url&&t.type==='soundcloud'&&typeof scResolve==='function')url=await scResolve(t).catch(()=>'');
  if(!url)throw new Error('нет ссылки на аудио');
  let blob=null,name='';
  try{
    if(N?.fetchAudio&&!url.startsWith(location.origin)&&!url.startsWith('blob:')){
      let r=await nativeCall('fetchAudio',[url],150000);
      if(!r?.src&&N.webFetchAudio)r=await nativeCall('webFetchAudio',[url],160000);
      if(!r?.src){const alt=await altSourceUrl(t).catch(()=>'');if(alt)r=await nativeCall('fetchAudio',[alt],150000)}
      if(r?.src){name=r.src.split('/').pop();blob=await (await fetch(new URL(r.src,location.href))).blob()}
    }
    if(!blob){const r=await fetch(url,{credentials:'omit'});if(!r.ok)throw new Error('HTTP '+r.status);blob=await r.blob()}
  }finally{if(name)try{N.envDone?.(name)}catch{}}
  if(blob.size<5e4)throw new Error('файл пустой');if(blob.size>19e6)throw new Error('файл слишком большой');
  return {inline_data:{mime_type:/^audio\/(mpeg|mp3|wav|ogg|flac|aac)/.test(blob.type)?blob.type:'audio/mpeg',data:await b64(blob)}};
}
/* 6.3.7: the model is picked from the key's own model list (Google retires old ids for new keys) */
const GEM_FALLBACK=['gemini-3.8-flash','gemini-flash-latest','gemini-3.6-flash','gemini-2.5-flash'];
const gemVer=n=>{const m=n.match(/gemini-(\d+(?:\.\d+)?)/);return m?+m[1]:0};
async function gemPickModel(force){
  const k=gemKey(),saved=store.get('gemModel',{});if(!force&&saved.k===k.slice(-6)&&saved.m)return saved.m;
  let m='';try{const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200',{headers:{'x-goog-api-key':k}});const j=await r.json();
    const ok=(j.models||[]).filter(x=>(x.supportedGenerationMethods||[]).includes('generateContent')).map(x=>x.name.replace(/^models\//,'')).filter(n=>/^gemini-[\d.]+-flash(-latest)?$|^gemini-flash-latest$/.test(n));
    ok.sort((a,b)=>gemVer(b)-gemVer(a)||(/latest/.test(a)?1:-1));m=ok[0]||''}catch{}
  m=m||GEM_FALLBACK[0];store.set('gemModel',{k:k.slice(-6),m});return m}
async function gemCall(body){
  const tried=new Set();let model=await gemPickModel(),lastErr;
  for(let n=0;n<4;n++){tried.add(model);
    const c=new AbortController(),tm=setTimeout(()=>c.abort(),180000);let j,r;
    try{r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',{method:'POST',signal:c.signal,headers:{'content-type':'application/json','x-goog-api-key':gemKey()},body:JSON.stringify(body)});j=await r.json().catch(()=>({}))}
    catch(e){throw e.name==='AbortError'?new Error('Gemini долго отвечает'):e}finally{clearTimeout(tm)}
    if(r.ok){const txt=(j.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('');return JSON.parse(txt.slice(txt.indexOf('{'),txt.lastIndexOf('}')+1)||'{}')}
    const msg=String(j.error?.message||'HTTP '+r.status);lastErr=msg;
    if(r.status===404||/no longer available|not found|not supported|deprecated|update your code/i.test(msg)){
      const sug=[...msg.matchAll(/models\/(gemini-[\w.-]*\w)/g)].map(x=>x[1]).find(x=>!tried.has(x));
      model=sug||(n===0?await gemPickModel(true):'')||GEM_FALLBACK.find(x=>!tried.has(x));
      if(model&&!tried.has(model)){store.set('gemModel',{k:gemKey().slice(-6),m:model});continue}}
    if(r.status===401||r.status===403||/API key/i.test(msg))throw new Error('ключ не подходит ('+msg.slice(0,90)+')');
    throw new Error(msg.slice(0,120))}
  throw new Error(String(lastErr).slice(0,120))}
/* no lyrics anywhere: Gemini listens and writes the words with times */
async function gemTranscribe(t){
  const key='gemtx:'+t.id;try{const c=await DB.collection(key);if(c?.items?.lines?.length)return c.items.lines}catch{}
  const part=await gemAudioPart(t);
  const j=await gemCall({contents:[{parts:[part,{text:`Song: "${t.title}" by ${t.artist||'unknown'}. Transcribe the sung lyrics exactly as heard, in the original language, one line per sung phrase, with the start time in seconds. Skip instrumental parts. Return only JSON {"lines":[{"t":number,"text":"..."}]}.`}]}],generationConfig:{responseMimeType:'application/json',temperature:0}});
  let L=(j.lines||[]).map(x=>({t:+x.t,text:String(x.text||'').trim()})).filter(x=>isFinite(x.t)&&x.text).sort((a,b)=>a.t-b.t);
  if(L.length<4)throw new Error('Gemini не расслышал слов');try{await DB.saveCollection(key,{lines:L})}catch{}return L}
async function gemTimes(t,lines){
  const key='gem:'+t.id+':'+lines.length;try{const c=await DB.collection(key);if(c?.items?.t?.length===lines.length){const T=c.items.t;T.noAudio=c.items.noAudio;return T}}catch{}
  let part=null,noAudio=false;try{part=await gemAudioPart(t)}catch(e){if(!e.noAudio)throw e;noAudio=true}
  const d=Math.round(liveDur(t)||audio.duration||0);
  const prompt=noAudio?`Song: "${t.title}" by ${t.artist||'unknown'}${d?', length '+d+' s':''}. Search the web for synced lyrics (LRC) or a timed video of this exact song and give the start time in seconds of each lyric line below, in order (${lines.length} lines). If no exact source exists, estimate from the song structure (intro, verses, choruses) so times fit inside ${d||'the song'} seconds. Return only JSON {"t":[numbers]} with exactly ${lines.length} increasing numbers.\n\n`+lines.map((x,i)=>(i+1)+'. '+x).join('\n'):`Song: "${t.title}" by ${t.artist||'unknown'}. Listen to the vocals and give the start time in seconds of each lyric line below, in order (${lines.length} lines). Repeated lines get their own time each. Times must increase. Return only JSON {"t":[numbers]} with exactly ${lines.length} numbers.\n\n`+lines.map((x,i)=>(i+1)+'. '+x).join('\n');
  const j=await gemCall(noAudio?{contents:[{parts:[{text:prompt}]}],tools:[{google_search:{}}],generationConfig:{temperature:0}}:{contents:[{parts:[part,{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0}});
  let T=(j.t||[]).map(Number);
  if(T.filter(isFinite).length<lines.length*.6)throw new Error('Gemini не расставил строки');
  T=lines.map((_,i)=>isFinite(T[i])?T[i]:NaN);
  for(let i=0;i<T.length;i++)if(!isFinite(T[i])||(i&&T[i]<=T[i-1])){let k=i+1;while(k<T.length&&!(isFinite(T[k])&&T[k]>(T[i-1]||0)))k++;const a=i?T[i-1]:0,b=k<T.length?T[k]:a+3*(k-i+1);for(let m=i;m<k;m++)T[m]=+(a+(b-a)*(m-i+1)/(k-i+1)).toFixed(2);i=k-1}
  try{await DB.saveCollection(key,{t:T,noAudio})}catch{}T.noAudio=noAudio;return T;
}
const baseAsrApply=asrApply;
asrApply=async function(res,t){
  if(res?.gem)return;
  if(res?.missing&&!res.instrumental&&GEM.on&&gemKey()&&t&&t.type!=='radio'&&!GEM.busy.has(t.id)){
    GEM.busy.add(t.id);const say=m=>{if(Ly.open&&cur()?.id===t.id)$('#lySrc').textContent=m};say('Текста нет — Gemini слушает трек и записывает слова…');
    try{const L=await gemTranscribe(t);if(cur()?.id!==t.id||Ly.id!==t.id)return;render({synced:L,plain:L.map(x=>x.text).join('\n'),gem:true,src:'Текст и тайминги: распознал ИИ Gemini (может ошибаться)'})}
    catch(e){say('Gemini: '+e.message)}finally{GEM.busy.delete(t.id)}return}
  if(!GEM.on||!gemKey()||!t||t.type==='radio'||res?.missing||res?.instrumental||!res?.plain||(res.synced?.length>2&&!res.estimated))return baseAsrApply(res,t);
  const lines=(res.estimated?res.synced.map(l=>l.text):res.plain.split('\n').map(x=>x.trim()).filter(x=>x&&!/^\[.*\]$/.test(x)));
  if(lines.length<3||GEM.busy.has(t.id))return baseAsrApply(res,t);
  const say=m=>{if(Ly.open&&cur()?.id===t.id)$('#lySrc').textContent=m};
  GEM.busy.add(t.id);say('Тайминги: Gemini слушает трек…');
  try{const T=await gemTimes(t,lines);if(cur()?.id!==t.id||Ly.id!==t.id)return;
    render({...res,synced:lines.map((x,i)=>({t:T[i],text:x})),estimated:false,gem:true,src:(T.noAudio?'Тайминги: Gemini по названию (примерно) · ':'Тайминги: ИИ Gemini · ')+(res.src||'')});
  }catch(e){say('Gemini: '+e.message+' · '+(res.src||''))}
  finally{GEM.busy.delete(t.id)}
};
function renderGemSettings(){
  const host=$('#gemSettings');if(!host)return;const k=store.get('geminiKey','');
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-mic"/></svg><h2>Тайминги через Gemini</h2></div>
    <p class="settings-help">ИИ Gemini слушает трек и сам расставляет время каждой строки — для любых песен с текстом без таймингов. Ключ бесплатный: <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com/apikey</a></p>
    <label class="toggle-row"><span><b>Включить</b><small>${gemKey()?'Ключ есть — работает':'Нужен ключ'}</small></span><input type="checkbox" id="gemOn" ${GEM.on?'checked':''}></label>
    <label class="field-label" for="gemKeyIn">API-ключ Gemini</label><input class="settings-input" id="gemKeyIn" maxlength="4000" autocomplete="off" spellcheck="false" placeholder="Вставь ключ" value="${esc(k)}">
    <div class="api-actions"><button class="btn-accent" id="gemSave">Сохранить</button></div>`;
  $('#gemOn').onchange=e=>{GEM.on=e.target.checked;store.set('gemOn',GEM.on);renderGemSettings()};
  $('#gemSave').onclick=()=>{const v=$('#gemKeyIn').value.trim();store.set('geminiKey',v);renderGemSettings();toast(v?'Gemini подключён':'Gemini отключён')};
}
renderGemSettings();
