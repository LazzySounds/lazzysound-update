'use strict';
/* Lazzy sound 3.8 — the colourful backgrounds, painted into two tiny canvases (64 px wide) that the GPU stretches
   to full screen. Bilinear upscaling *is* the blur, so there are no full-screen blurred layers any more:
   the wallpaper used to cost ~6 big GPU layers (≈100 MB of tiles on a 3× screen), now it is a few kilobytes.
   • home wallpaper: blurred cover + four drifting colour blobs + the music pulse;
   • player background: blurred cover + aurora + the dark gradient for legibility.
   Drift redraws ~15 fps (high) / 8 fps (mid) / only on change (low); the pulse follows the particle loop. */
const Backdrop=(()=>{
  const W=64;let H=140;
  const mk=(host,cls)=>{const c=document.createElement('canvas');c.className='bd-canvas '+cls;c.setAttribute('aria-hidden','true');host.prepend(c);return c};
  const wall=mk($('#ambient'),'bd-wall'),fullc=mk($('#fullBg'),'bd-full');
  const ctxW=wall.getContext('2d'),ctxF=fullc.getContext('2d');
  const cover={url:'',small:null};let colors={},colorsAt=0,raf=0,last=0,dirty=true,t0=performance.now();
  function readColors(){const cs=getComputedStyle(document.documentElement);colors={bg:cs.getPropertyValue('--bg').trim()||'#06070b',hue:parseFloat(cs.getPropertyValue('--hue'))||210,light:document.documentElement.dataset.theme==='light'};colorsAt=performance.now()}
  function fit(c){const h=Math.max(80,Math.round(W*innerHeight/Math.max(1,innerWidth)));if(c.width!==W||c.height!==h){c.width=W;c.height=h}H=h}
  /* the cover is reduced to 24×24 once per track; the decoded full-size image is dropped right away */
  function setCover(url){
    if(url===cover.url)return;cover.url=url;cover.small=null;dirty=true;if(!url){kick();return}
    const im=new Image();im.decoding='async';
    im.onload=()=>{if(cover.url!==url)return;const s=document.createElement('canvas');s.width=s.height=24;s.getContext('2d').drawImage(im,0,0,24,24);cover.small=s;im.src='';dirty=true;kick()};
    im.onerror=()=>{};im.src=url;
  }
  function blob(x,cx,cy,r,col){const g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.fillRect(0,0,W,H)}
  function paint(x,c,mode,time,P){
    fit(c);const {bg,hue,light}=colors;const d=k=>Math.sin(time*k);
    x.globalCompositeOperation='source-over';x.globalAlpha=1;x.filter='none';x.fillStyle=bg;x.fillRect(0,0,W,H);
    if(cover.small){
      const s=Math.max(W,H)*(mode==='full'?1.05:1.25);x.globalAlpha=mode==='full'?(light?.55:.9):(light?.16:.4);
      x.filter=mode==='full'?(light?'blur(3px) saturate(1.4) brightness(1.25)':'blur(3px) saturate(1.7)'):'blur(4px) saturate(1.5)';
      x.drawImage(cover.small,(W-s)/2+d(.05)*3,(H-s)/2+d(.04)*4,s,s);x.filter='none';x.globalAlpha=1;
    }
    const M=Math.max(W,H);
    if(mode==='wall'){
      blob(x,W*(.05+.08*d(.11)),H*(.06+.05*d(.09)),M*.62,light?`hsla(${hue},90%,72%,.7)`:`hsla(${hue},85%,52%,.7)`);
      blob(x,W*(1.0-.1*d(.08)),H*(.42+.06*d(.07)),M*.6,light?'rgba(170,150,255,.5)':'rgba(110,70,255,.5)');
      blob(x,W*(.15+.1*d(.06)),H*(1.02-.04*d(.1)),M*.58,light?'rgba(120,230,210,.45)':'rgba(0,190,170,.38)');
      blob(x,W*(.95-.08*d(.12)),H*(.98+.03*d(.05)),M*.55,light?'rgba(255,170,200,.45)':'rgba(255,90,140,.3)');
    }else{
      for(let i=0;i<3;i++)blob(x,W*(.2+.6*((i*.37+.5+.25*d(.07+i*.03))%1)),H*(.15+.3*i+.05*d(.05+i*.02)),M*.55,`hsla(${hue+i*25},90%,55%,${light?.18:.25})`);
      const g=x.createLinearGradient(0,0,0,H);
      if(light){g.addColorStop(0,'rgba(255,255,255,.1)');g.addColorStop(.6,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(255,255,255,.6)')}
      else{g.addColorStop(0,'rgba(6,7,11,.1)');g.addColorStop(.6,'rgba(6,7,11,.45)');g.addColorStop(1,'rgba(6,7,11,.75)')}
      x.fillStyle=g;x.fillRect(0,0,W,H);
    }
    if(P>.01)blob(x,W*.5,H*.45,M*.55,light?`hsla(${hue},90%,70%,${(.45*P).toFixed(3)})`:`hsla(${hue},90%,60%,${(.38*P).toFixed(3)})`);
  }
  const tier=()=>document.documentElement.dataset.perf||'high';
  const fullOpen=()=>$('#full').classList.contains('open');
  function frame(now){
    raf=0;if(document.hidden)return;
    if(now-colorsAt>1000)readColors();
    const P=typeof FxEngine!=='undefined'?FxEngine.pulse:0,pulsing=P>.01||(!audio.paused&&typeof Fx!=='undefined'&&Fx.pulse&&tier()!=='low');
    const gap=pulsing?(typeof perfFrameGap==='function'?perfFrameGap():16):({high:66,mid:125,low:1e9})[tier()];
    if(dirty||now-last>=gap){
      last=now;dirty=false;const time=(now-t0)/1000;
      if(fullOpen())paint(ctxF,fullc,'full',time,0);else paint(ctxW,wall,'wall',time,P);
    }
    if(tier()!=='low'||pulsing||dirty)raf=requestAnimationFrame(frame);
  }
  function kick(){dirty=true;if(!raf)raf=requestAnimationFrame(frame)}
  /* cover follows the playing track (same source the old CSS wallpaper used) */
  new MutationObserver(()=>{const m=/url\(["']?([^"')]+)/.exec($('#fullArt').style.backgroundImage||'');setCover(m?m[1]:'')}).observe($('#fullArt'),{attributes:true,attributeFilter:['style']});
  new MutationObserver(kick).observe($('#full'),{attributes:true,attributeFilter:['class']});
  new MutationObserver(()=>{colorsAt=0;kick()}).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme','data-accent','data-perf','style']});
  document.addEventListener('visibilitychange',kick);addEventListener('resize',kick);
  for(const ev of ['play','pause','loadstart'])audio.addEventListener(ev,kick);
  readColors();kick();
  return{kick,release(){cover.small=null;cover.url='';dirty=true}};
})();
