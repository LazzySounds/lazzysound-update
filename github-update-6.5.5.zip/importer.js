'use strict';
/* Lazzy sound 4.7 — bring your music from other services.
   • Spotify (official Web API, your own Client ID): playlists and Liked Songs are read and every track is matched to a
     full, playable copy on the app's sources (Audius, SoundCloud, Archive…, your files).
   • Track list: paste "Artist — Title" lines (e.g. exported from VK or Yandex) — same matcher.
   The result is a normal playlist (and is downloaded for offline if that is on). Unmatched tracks are listed. */
const Sp={cid:store.get('spClientId',''),token:'',exp:0,pending:new Map(),connected:store.get('spConnected',false)};
window.__lazzySpotify=(id,payload)=>{const p=Sp.pending.get(id);if(!p)return;Sp.pending.delete(id);try{const j=JSON.parse(payload);if(j.error)throw new Error(j.error);p.resolve(j)}catch(e){p.reject(e)}};
const spCall=(fn,...a)=>new Promise((resolve,reject)=>{const id='sp-'+Date.now();Sp.pending.set(id,{resolve,reject});try{LumenNative[fn](...a,id)}catch(e){Sp.pending.delete(id);reject(e)}});
async function spToken(){if(Sp.token&&Date.now()<Sp.exp-60000)return Sp.token;const j=await spCall('spotifyToken');Sp.token=j.access_token;Sp.exp=Date.now()+j.expires_in*1000;return Sp.token}
async function spGet(url){
  for(let k=0;k<3;k++){
    const r=await fetch(url.startsWith('http')?url:'https://api.spotify.com/v1'+url,{headers:{Authorization:'Bearer '+await spToken()}});
    if(r.status===401){Sp.token='';continue}if(r.status===429){await new Promise(z=>setTimeout(z,(+r.headers.get('Retry-After')||2)*1000));continue}
    if(!r.ok)throw new Error('Spotify HTTP '+r.status);return r.json();
  }
  throw new Error('Spotify не отвечает');
}
async function spAll(url,pick,max=2000){const out=[];let next=url;while(next&&out.length<max){const j=await spGet(next);out.push(...pick(j));next=j.next}return out}
const spTrack=t=>t&&t.name&&!t.is_local?{title:t.name,artist:(t.artists||[]).map(a=>a.name).join(', '),duration:Math.round((t.duration_ms||0)/1000),album:t.album?.name||'',art:t.album?.images?.[0]?.url||''}:null;

/* ---------- Matcher ---------- */
async function matchTrack(x){
  const q=`${cleanArtist(x.artist)} ${cleanTitle(x.title)}`.trim();
  const jobs=sourceJobs(q,{withLocal:true,withCatalog:false,withRadio:false});
  const found=(await Promise.all(jobs.map(([s,fn])=>(s==='local'?fn():cachedSearch(s,q,fn)).catch(()=>[])))).flat();
  let best=null,bs=0;
  for(const c of found){if(!isFullAudio(c)||c.type==='radio')continue;
    const ts=similarity(normalize(cleanTitle(x.title)),normalize(cleanTitle(c.title))),as=x.artist?similarity(normalize(cleanArtist(x.artist)),normalize(cleanArtist(c.artist))):.8;
    if(ts<.78||as<.55)continue;let sc=ts*.6+as*.4;if(x.duration&&c.duration){const d=Math.abs(x.duration-c.duration);if(d>15)continue;sc-=d/150}
    if(c.type==='local')sc+=.05;if(sc>bs){bs=sc;best=c}}
  return best;
}
async function runImport(name,items,ui){
  const pl=Library.create(name),missing=[];let done=0,matched=0,stop=false;ui.onStop=()=>{stop=true};
  const queue=[...items];
  async function worker(){while(queue.length&&!stop){const x=queue.shift();let m=null;try{m=await matchTrack(x)}catch{}done++;
    if(m){Library.toggle(pl,m);matched++}else missing.push(x);ui.progress(done,items.length,matched)}}
  await Promise.all([worker(),worker(),worker()]);
  pl.updatedAt=Date.now();Library.save();if(typeof offlineSync==='function')offlineSync();
  if(view==='library')renderLib();return {pl,missing,matched,stopped:stop};
}

/* ---------- UI ---------- */
function parseList(text){
  return text.split(/\r?\n/).map(l=>l.replace(/^\s*\d+[.)]\s*/,'').trim()).filter(Boolean).map(l=>{
    let m=l.match(/^(.+?)\s+[—–-]\s+(.+)$/);if(m)return {artist:m[1].trim(),title:m[2].trim()};
    m=l.match(/^(.+?)\s+by\s+(.+)$/i);if(m)return {title:m[1].trim(),artist:m[2].trim()};
    return {artist:'',title:l};
  }).slice(0,1000);
}
function importProgressUI(title){
  openSheet({title,sub:'Ищем полные версии в доступных источниках',tracks:[],cover:{title:'Импорт'}});$('#sheet').dataset.mode='import';$('#sheetList').onclick=null;$('#sheetList').innerHTML='';
  $('#sheetActions').innerHTML='<div class="imp-prog"><div class="imp-bar"><i id="impBar"></i></div><p id="impText">Начинаем…</p><button class="chip" id="impStop">Остановить</button></div>';
  const ui={progress(d,n,m){$('#impBar').style.transform=`scaleX(${d/n})`;$('#impText').textContent=`${d} из ${n} · найдено ${m}`}};
  $('#impStop').onclick=()=>ui.onStop?.();return ui;
}
function showImportResult(r){
  $('#sheetTitle').textContent=r.stopped?'Импорт остановлен':'Импорт готов';
  $('#sheetSub').textContent=`Найдено ${r.matched} · не найдено ${r.missing.length}`;
  $('#sheetActions').innerHTML=`<div class="imp-result"><div class="api-actions"><button class="btn-accent" id="impOpen"><svg><use href="#i-play"/></svg>Открыть плейлист</button></div>${r.missing.length?`<p class="field-label">Не нашли полную версию</p><div class="imp-miss">${r.missing.slice(0,200).map(x=>`<p>${esc(x.artist?x.artist+' — ':'')}${esc(x.title)}</p>`).join('')}</div>`:''}</div>`;
  $('#impOpen').onclick=()=>{closeSheet();openPlaylist(r.pl)};
}
async function importFromText(){
  openSheet({title:'Импорт списка треков',sub:'По строке на трек: «Исполнитель — Название»',tracks:[],cover:{title:'Импорт'}});$('#sheet').dataset.mode='import';$('#sheetList').onclick=null;$('#sheetList').innerHTML='';
  $('#sheetActions').innerHTML=`<div class="wave-tune"><input class="settings-input" id="impName" maxlength="80" placeholder="Название плейлиста" value="Импорт ${new Date().toLocaleDateString('ru-RU')}">
    <textarea class="settings-input imp-text" id="impText2" rows="8" placeholder="Кино — Группа крови&#10;Земфира — Хочешь?&#10;Arctic Monkeys — Do I Wanna Know?"></textarea>
    <p class="settings-help">Подходит список, скопированный из VK, Яндекс Музыки или любой другой выгрузки.</p>
    <div class="api-actions"><button class="btn-accent" id="impGo">Найти и добавить</button></div></div>`;
  $('#impGo').onclick=async()=>{const items=parseList($('#impText2').value);if(!items.length){toast('Вставь хотя бы одну строку');return}
    const name=$('#impName').value.trim()||'Импорт';const ui=importProgressUI(name);showImportResult(await runImport(name,items,ui))};
}
async function importFromSpotify(){
  if(!window.LumenNative?.spotifySignIn){toast('Импорт Spotify работает в установленном приложении');return}
  if(!Sp.cid){go('profile');window.setProfileTab?.('sources');setTimeout(()=>$('#spSettings')?.scrollIntoView({behavior:'smooth',block:'start'}),200);toast('Укажи Client ID Spotify');return}
  if(!Sp.connected){try{toast('Открываем Spotify…');const j=await spCall('spotifySignIn',Sp.cid);Sp.token=j.access_token;Sp.exp=Date.now()+j.expires_in*1000;Sp.connected=true;store.set('spConnected',true);renderSpSettings()}catch(e){toast(e.message);return}}
  openSheet({title:'Импорт из Spotify',sub:'Выбери, что перенести',tracks:[],cover:{title:'Spotify'}});$('#sheet').dataset.mode='import';$('#sheetActions').innerHTML='';loading($('#sheetList'));
  try{
    const pls=await spAll('/me/playlists?limit=50',j=>j.items||[],500);
    const rows=[{id:'liked',name:'Любимые треки Spotify',count:'—'},...pls.map(p=>({id:p.id,name:p.name,count:p.tracks?.total??''}))];
    $('#sheetList').innerHTML=rows.map((r,i)=>`<button class="lib-row" data-sp="${i}"><div class="cover pl-empty"><svg><use href="#i-${r.id==='liked'?'heart-f':'queue'}"/></svg></div><span class="meta"><b>${esc(r.name)}</b><span>${r.count===''?'':r.count+' треков'}</span></span></button>`).join('');
    $('#sheetList').onclick=async e=>{const b=e.target.closest('[data-sp]');if(!b)return;const r=rows[+b.dataset.sp];$('#sheetList').innerHTML='';const ui=importProgressUI(r.name);
      try{const items=r.id==='liked'?await spAll('/me/tracks?limit=50',j=>(j.items||[]).map(x=>spTrack(x.track)).filter(Boolean)):await spAll(`/playlists/${encodeURIComponent(r.id)}/tracks?limit=100`,j=>(j.items||[]).map(x=>spTrack(x.track)).filter(Boolean));
        showImportResult(await runImport(r.name,items,ui))}catch(err){$('#impText').textContent=err.message}};
  }catch(e){$('#sheetList').innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}
/* ---------- Import by link (Spotify playlist/album/track, SoundCloud playlist/set/track) ---------- */
/* 6.4.5: public Spotify link without login / Premium — the track list from Spotify's own embed page */
async function spEmbed(type,id){
  if(!window.LumenNative?.publicCatalog)throw new Error('Импорт по ссылке Spotify работает в приложении на телефоне и на ПК');
  const j=await publicCatalog('spotifyEmbed',{type,id});if(!j||j.connectorError)throw new Error('Spotify не отдал список — проверь, что плейлист открытый');
  const ent=j.props?.pageProps?.state?.data?.entity||{};const name=ent.name||ent.title||'Spotify';
  const art=(ent.coverArt?.sources||ent.visualIdentity?.image||[])[0]?.url||'';
  const clean=s=>String(s||'').replace(/ /g,' ').trim();
  let list=(ent.trackList||[]).map(x=>({title:clean(x.title),artist:clean(x.subtitle).replace(/\s*,\s*/g,', '),duration:Math.round((+x.duration||0)/1000),album:type==='album'?name:'',art:type==='album'?art:''}));
  if(!list.length&&type==='track')list=[{title:clean(ent.name||ent.title),artist:(ent.artists||[]).map(a=>a.name).join(', '),duration:Math.round((+ent.duration||0)/1000),album:'',art}];
  return {name,items:list.filter(x=>x.title)}}
/* 6.4.6: the only Spotify import — public link, no login, no Premium */
function importSpotify(){
  openSheet({title:'Импорт из Spotify',sub:'Без входа и подписки',tracks:[],cover:{title:'Spotify'}});$('#sheet').dataset.mode='import';$('#sheetList').onclick=null;$('#sheetList').innerHTML='';
  $('#sheetActions').innerHTML=`<div class="wave-tune"><input class="settings-input" id="spLink" placeholder="https://open.spotify.com/playlist/…" autocomplete="off" spellcheck="false">
    <p class="settings-help">Вставь ссылку на <b>открытый</b> плейлист, альбом или трек: в Spotify «⋯» → «Поделиться» → «Скопировать ссылку».<br>«Любимые треки» — закрытые: в Spotify на ПК открой «Любимые», выдели всё (Ctrl+A) → правой кнопкой «Добавить в плейлист» → новый плейлист, и вставь ссылку на него.<br>Большие плейлисты Spotify может отдать не целиком (около 100 треков) — разбей на части.</p>
    <div class="api-actions"><button class="btn-accent" id="spGo">Найти и добавить</button></div></div>`;
  $('#spGo').onclick=()=>importFromLink($('#spLink').value)}
async function importFromLink(given){
  const url=(typeof given==='string'?given:(await askText('Ссылка на плейлист, альбом или трек','')||'')).trim();if(!url)return;
  let m=url.match(/open\.spotify\.com\/(?:intl-[a-z]+\/)?(playlist|album|track)\/([A-Za-z0-9]{10,40})/);
  if(m){
    {const ui=importProgressUI('Spotify');
      try{const {name,items}=await spEmbed(m[1],m[2]);if(!items.length)throw new Error('В плейлисте не нашлось треков');showImportResult(await runImport(name,items,ui))}catch(e){$('#impText').textContent=e.message}
      return}
    if(!Sp.connected){try{const j=await spCall('spotifySignIn',Sp.cid);Sp.token=j.access_token;Sp.exp=Date.now()+j.expires_in*1000;Sp.connected=true;store.set('spConnected',true)}catch(e){toast(e.message);return}}
    const ui=importProgressUI('Spotify');
    try{let name='Spotify',items=[];
      if(m[1]==='playlist'){const p=await spGet('/playlists/'+m[2]+'?fields=name');name=p.name||name;items=await spAll('/playlists/'+m[2]+'/tracks?limit=100',j=>(j.items||[]).map(x=>spTrack(x.track)).filter(Boolean))}
      else if(m[1]==='album'){const a=await spGet('/albums/'+m[2]);name=a.name||name;items=await spAll('/albums/'+m[2]+'/tracks?limit=50',j=>(j.items||[]).map(t=>spTrack({...t,album:{name:a.name,images:a.images}})).filter(Boolean))}
      else{const t=spTrack(await spGet('/tracks/'+m[2]));name=t.title;items=[t]}
      showImportResult(await runImport(name,items,ui))}catch(e){$('#impText').textContent=e.message}
    return;
  }
  if(/^https:\/\/(on\.|m\.)?soundcloud\.com\//.test(url)){
    if(!SC.id){toast('Укажи Client ID SoundCloud: Профиль → Источники');return}
    const ui=importProgressUI('SoundCloud');
    try{const r=await scGet('https://api-v2.soundcloud.com/resolve?'+scQ({url,client_id:SC.id}));let list=[],name=r.title||'SoundCloud';
      if(r.kind==='track')list=[r];
      else if(Array.isArray(r.tracks)){const full=r.tracks.filter(t=>t.media),ids=r.tracks.filter(t=>!t.media).map(t=>t.id);list=full;
        for(let k=0;k<ids.length;k+=50){const j=await scGet('https://api-v2.soundcloud.com/tracks?'+scQ({ids:ids.slice(k,k+50).join(','),client_id:SC.id}));list.push(...(Array.isArray(j)?j:j.collection||[]))}}
      const playable=mapSC(list),pl=Library.create(name);playable.forEach(t=>Library.toggle(pl,t));Library.save();if(typeof offlineSync==='function')offlineSync();if(view==='library')renderLib();
      ui.progress(list.length,Math.max(1,list.length),playable.length);
      showImportResult({pl,matched:playable.length,missing:list.filter(t=>!playable.some(p=>p.id==='sc:'+t.id)).map(t=>({artist:t.user?.username||'',title:t.title||''})),stopped:false})}
    catch(e){$('#impText').textContent=e.message}
    return;
  }
  toast('Поддерживаются ссылки Spotify, SoundCloud и Яндекс Музыки. Для VK — «Список треков»');
}
function openImportMenu(){
  openSheet({title:'Импорт музыки',sub:'Перенеси плейлисты из других сервисов',tracks:[],cover:{title:'Импорт'}});$('#sheet').dataset.mode='import';$('#sheetActions').innerHTML='';
  $('#sheetList').innerHTML=`<button class="lib-row" data-imp="sp"><div class="cover pl-empty"><svg><use href="#i-cloud"/></svg></div><span class="meta"><b>Spotify</b><span>По ссылке — без входа и подписки</span></span></button>
    <button class="lib-row" data-imp="link"><div class="cover pl-empty"><svg><use href="#i-external"/></svg></div><span class="meta"><b>SoundCloud</b><span>Ссылка на плейлист или трек</span></span></button>
    <button class="lib-row" data-imp="txt"><div class="cover pl-empty"><svg><use href="#i-type"/></svg></div><span class="meta"><b>Список треков</b><span>Из VK, Яндекс Музыки и любой выгрузки</span></span></button>`;
  $('#sheetList').onclick=e=>{const b=e.target.closest('[data-imp]');if(!b)return;b.dataset.imp==='sp'?importSpotify():b.dataset.imp==='link'?importFromLink():importFromText()};
}
function renderSpSettings(){
  const host=$('#spSettings');if(!host)return;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-cloud"/></svg><h2>Spotify (импорт)</h2></div>
    <p class="settings-help">Переносит плейлисты по ссылке — без входа в Spotify и без подписки. Каждый трек ищется в доступных источниках.</p>
    <div class="api-actions"><button class="btn-accent" id="spImport">Импорт по ссылке</button></div>`;
  $('#spImport').onclick=importSpotify;
}
renderSpSettings();
/* «Импорт» next to «Новый плейлист» in the library */
const baseRenderLib=renderLib;
renderLib=function(){baseRenderLib();if(libTab==='playlists'&&$('#libActions')&&!$('#plImport')){const b=document.createElement('button');b.className='chip glass';b.id='plImport';b.innerHTML='<svg><use href="#i-upload"/></svg>Импорт';b.onclick=openImportMenu;$('#libActions').appendChild(b)}};
