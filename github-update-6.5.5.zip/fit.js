'use strict';
/* Lazzy sound 3.5 — long titles: no jumping, no half-cut words.
   Player and mini-player titles that don't fit glide sideways (compositor-only marquee with soft edges);
   big page titles scale down with length and wrap evenly. */
function fitMarquee(el){
  if(!el)return;const text=el.textContent;let inner=el.firstElementChild;
  if(!inner||!inner.classList.contains('mq')||inner.textContent!==text){el.innerHTML='';inner=document.createElement('span');inner.className='mq';inner.textContent=text;el.appendChild(inner)}
  el.classList.remove('marquee');inner.style.animation='none';
  requestAnimationFrame(()=>{
    const over=inner.scrollWidth-el.clientWidth;inner.style.animation='';
    if(over>4&&el.clientWidth>0&&document.documentElement.dataset.motion!=='reduce'){
      const d=over+28;el.style.setProperty('--mq-d',-d+'px');el.style.setProperty('--mq-t',Math.max(6,d/28+4)+'s');el.classList.add('marquee');
    }
  });
}
const fitTargets=['#fullTitle','#miniTitle','#fullArtist'];
for(const sel of fitTargets){const el=$(sel);if(!el)continue;el.classList.add('fit-line');
  new MutationObserver(()=>{const i=el.firstElementChild;if(i&&i.classList.contains('mq')&&i.textContent===el.textContent&&el.childNodes.length===1)return;fitMarquee(el)}).observe(el,{childList:true,characterData:true,subtree:true});
  fitMarquee(el)}
new MutationObserver(()=>{if($('#full').classList.contains('open'))setTimeout(()=>{fitMarquee($('#fullTitle'));fitMarquee($('#fullArtist'))},80)}).observe($('#full'),{attributes:true,attributeFilter:['class']});
addEventListener('resize',()=>fitTargets.forEach(s=>fitMarquee($(s))));

/* Big titles: size by length, balanced wrapping, never more than three lines. */
function fitTitle(el){if(!el)return;const n=el.textContent.trim().length;el.classList.toggle('t-long',n>28&&n<=48);el.classList.toggle('t-xlong',n>48)}
for(const sel of ['#colTitle','#albumTitle']){const el=$(sel);if(!el)continue;new MutationObserver(()=>fitTitle(el)).observe(el,{childList:true,characterData:true,subtree:true});fitTitle(el)}
