'use strict';
/* Lazzy sound 3.2 — Spotify / SoundCloud style library:
   playlists, Liked songs, followed artists, artist & genre pages (Audius), editable queue,
   share, add-to-playlist, swipe-to-skip mini player and a SoundCloud-like waveform scrubber. */

/* ---------- Audius public API (trending, artists, genres) ---------- */
const audiusApiPending=new Map();
window.__lazzyAudius=(id,payload)=>{const p=audiusApiPending.get(id);if(!p)return;audiusApiPending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.error)throw new Error(j.error);p.resolve(j)}catch(e){p.reject(e)}};
const audiusApiCache=new Map();
function audiusApi(path,ttl=600000){
  const hit=audiusApiCache.get(path);if(hit&&Date.now()-hit.t<ttl)return hit.p;
  const p=(window.LumenNative?.audiusGet?new Promise((resolve,reject)=>{const id='aa-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{audiusApiPending.delete(id);reject(new Error('Audius не ответил'))},16000);audiusApiPending.set(id,{resolve,reject,timer});LumenNative.audiusGet(path,id)})
    :bounded(fetch('https://api.audius.co'+path+(path.includes('?')?'&':'?')+'app_name=LazzySound',{credentials:'omit'}).then(r=>{if(!r.ok)throw new Error('Audius HTTP '+r.status);return r.json()}),12000));
  p.catch(()=>audiusApiCache.delete(path));audiusApiCache.set(path,{t:Date.now(),p});return p;
}
const audiusTrending=(genre='',time='week')=>audiusApi(`/v1/tracks/trending?time=${time}${genre?'&genre='+encodeURIComponent(genre):''}`).then(mapAudiusTracks);
const AUDIUS_GENRES=[['Electronic',200],['Hip-Hop/Rap',330],['Lo-Fi',190],['House',280],['Pop',320],['Rock',10],['Ambient',170],['Techno',250],['R&B/Soul',300],['Alternative',140],['Jazz',35],['Drum & Bass',100],['Trap',350],['Classical',45],['Dubstep',265],['Metal',0]];

/* ---------- Data: playlists & follows ---------- */
const Library={
  playlists:store.get('playlists',[]),follows:store.get('follows',[]),ctx:null,
  save(sync=true){store.set('playlists',this.playlists);store.set('follows',this.follows);if(sync&&window.LazzySync)LazzySync.schedule()},
  create(name){const p={id:'pl:'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),name:String(name).trim().slice(0,80)||'Мой плейлист',tracks:[],createdAt:Date.now(),updatedAt:Date.now()};this.playlists.unshift(p);this.save();return p},
  get(id){return this.playlists.find(p=>p.id===id)},
  toggle(pl,t){const i=pl.tracks.findIndex(x=>x.id===t.id);if(i>=0)pl.tracks.splice(i,1);else{const {blob,_rank,providers,...clean}=t;pl.tracks.push(clean)}pl.updatedAt=Date.now();this.save();return i<0},
  remove(pl){this.playlists=this.playlists.filter(p=>p.id!==pl.id);window.LazzySync?.tombstone(pl.id);this.save()},
  isFollowing(id){return this.follows.some(f=>f.id===id)},
  follow(a){if(this.isFollowing(a.id)){this.follows=this.follows.filter(f=>f.id!==a.id);window.LazzySync?.tombstone(a.id);this.save();return false}this.follows.unshift({...a,followedAt:Date.now()});this.save();return true}
};
const likedTracks=()=>S.favs.filter(t=>t.type!=='album'&&isUsableEntry(t));
function mosaicHTML(tracks,cls=''){const arts=[...new Set(tracks.map(t=>t.art).filter(Boolean))].slice(0,4);
  if(arts.length>=4)return `<div class="cover mosaic ${cls}">${arts.map(a=>`<i style="background-image:url('${esc(a)}')"></i>`).join('')}</div>`;
  if(arts.length)return `<div class="cover ${cls}" style="background-image:url('${esc(arts[0])}')"></div>`;
  return `<div class="cover ${cls} pl-empty"><svg><use href="#i-note"/></svg></div>`}
const likedCoverHTML=(cls='')=>`<div class="cover liked-cover ${cls}"><svg><use href="#i-heart-f"/></svg></div>`;
const plural=(n,a,b,c)=>{const m=n%10,h=n%100;return n+' '+(m===1&&h!==11?a:m>=2&&m<=4&&(h<12||h>14)?b:c)};

/* ---------- Collection page (playlist / liked / artist / genre / mix) ---------- */
let colState=null,colReturn='library';
function openCollection(o){
  if(view!=='collection')colReturn=view;closeSheet();$('#full').classList.remove('open');
  colState={...o,tracks:o.tracks||[]};Library.ctx=o.kind==='playlist'?o.id:null;go('collection');
  $('#colKind').textContent=o.kindLabel||'';$('#colTitle').textContent=o.title;$('#colSub').textContent=o.sub||'';$('#colMeta').textContent=o.meta||'';
  const host=$('#colCoverHost');host.innerHTML=o.coverHTML||coverHTML(o.cover||{title:o.title,artist:o.sub||'',art:o.art||''});
  const cov=host.firstElementChild;cov.id='colCover';cov.classList.add('col-cover');cov.classList.toggle('round',!!o.round);
  if(!o.coverHTML)setCover(cov,o.cover||{title:o.title,artist:o.sub||'',art:o.art||''});
  $('#colBackdrop').style.backgroundImage=o.art?`url('${o.art.replace(/'/g,'%27')}')`:'none';
  const fb=$('#colFollow');fb.hidden=!o.followId;if(o.followId)syncFollowBtn();
  $('#colMenu').hidden=o.kind!=='playlist';
  if(o.loader){$('#colList').innerHTML='<div class="loader"><i></i><i></i><i></i></div>';$('#colPlay').disabled=$('#colShuffle').disabled=true;
    const token=colState;o.loader().then(tr=>{if(colState!==token)return;colState.tracks=tr;renderCollection()}).catch(e=>{if(colState===token)$('#colList').innerHTML=`<div class="empty"><b>Не удалось загрузить</b><span>${esc(e.message||'Попробуй позже')}</span></div>`})}
  else renderCollection();
}
function renderCollection(){
  if(!colState)return;const tr=colState.tracks.filter(isUsableEntry);const playable=tr.filter(isFullAudio);
  $('#colPlay').disabled=$('#colShuffle').disabled=!playable.length;
  if(colState.metaFn)$('#colMeta').textContent=colState.metaFn(tr);
  renderList($('#colList'),tr,{empty:colState.empty||'Здесь пока пусто.'});
}
function syncFollowBtn(){const on=Library.isFollowing(colState.followId);const b=$('#colFollow');b.classList.toggle('on',on);b.textContent=on?'Вы подписаны':'Подписаться'}
$('#colBack').onclick=()=>{Library.ctx=null;go(colReturn==='collection'?'library':colReturn)};
$('#colPlay').onclick=()=>{const q=colState.tracks.filter(isFullAudio);if(!q.length)return;S.shuffle=false;store.set('shuffle',false);playTrack(q,0)};
$('#colShuffle').onclick=()=>{const q=colState.tracks.filter(isFullAudio);if(!q.length)return;S.shuffle=true;store.set('shuffle',true);playTrack(q,Math.floor(Math.random()*q.length))};
$('#colFollow').onclick=()=>{if(!colState?.followId)return;const on=Library.follow({id:colState.followId,name:colState.title,art:colState.art||'',artistId:colState.artistId||'',source:colState.artistId?'audius':'search'});syncFollowBtn();toast(on?'Подписка оформлена':'Подписка отменена')};
$('#colMenu').onclick=()=>{const pl=Library.get(colState?.id);if(!pl)return;openSheet({title:pl.name,sub:plural(pl.tracks.length,'трек','трека','треков'),tracks:[],cover:pl.tracks[0]||{title:pl.name}});$('#sheet').dataset.mode='plmenu';$('#sheetList').onclick=null;
  $('#sheetActions').innerHTML='<div class="track-actions"><button class="chip" id="plRename"><svg><use href="#i-type"/></svg>Переименовать</button><button class="chip" id="plShare"><svg><use href="#i-external"/></svg>Поделиться</button><button class="chip danger" id="plDelete"><svg><use href="#i-trash"/></svg>Удалить</button></div>';$('#sheetList').innerHTML='';
  $('#plRename').onclick=async()=>{const name=await askText('Новое название',pl.name);if(name){pl.name=name.slice(0,80);pl.updatedAt=Date.now();Library.save();$('#colTitle').textContent=pl.name;toast('Переименовано')}};
  $('#plShare').onclick=()=>shareText(pl.name,pl.name+'\n'+pl.tracks.slice(0,30).map((t,i)=>`${i+1}. ${t.artist} — ${t.title}`).join('\n'));
  $('#plDelete').onclick=()=>{if(!$('#plDelete').dataset.armed){$('#plDelete').dataset.armed='1';$('#plDelete').lastChild.textContent='Точно удалить?';return}Library.remove(pl);closeSheet();toast('Плейлист удалён');go('library')};
};
function openPlaylist(pl){openCollection({kind:'playlist',id:pl.id,kindLabel:'Плейлист',title:pl.name,sub:'Твой плейлист',coverHTML:mosaicHTML(pl.tracks),tracks:pl.tracks,art:pl.tracks.find(t=>t.art)?.art,metaFn:tr=>plural(tr.length,'трек','трека','треков')+' · '+fmtTotal(tr),empty:'<svg><use href="#i-plus"/></svg><b>Плейлист пуст</b><span>Открой меню трека ⋯︎ и выбери «В плейлист».</span>'})}
function openLiked(){openCollection({kind:'liked',kindLabel:'Плейлист',title:'Любимые треки',sub:'Всё, что ты лайкнул',coverHTML:likedCoverHTML(),tracks:likedTracks(),metaFn:tr=>plural(tr.length,'трек','трека','треков'),empty:'<svg><use href="#i-heart"/></svg><b>Пока нет любимых</b><span>Нажми ♥︎ у трека — он появится здесь.</span>'})}
const fmtTotal=tr=>{const s=tr.reduce((a,t)=>a+(+t.duration||0),0);return s?Math.round(s/60)+' мин':''};
function openArtist(a){
  const id=a.artistId?'artist:audius:'+a.artistId:'artist:name:'+normalize(a.name);
  if(a.artistId){
    openCollection({kind:'artist',kindLabel:'Исполнитель',title:a.name,sub:a.handle?'@'+a.handle:'',art:a.art||'',round:true,cover:{title:a.name,artist:'',art:a.art||''},followId:id,artistId:a.artistId,
      loader:async()=>{const [u,list]=await Promise.all([audiusApi('/v1/users/'+a.artistId).catch(()=>null),audiusApi('/v1/users/'+a.artistId+'/tracks?limit=50&sort=plays')]);
        const d=u?.data;if(d&&colState?.followId===id){const pic=(d.profile_picture?.['480x480']||d.profile_picture?.['150x150']||'');if(pic.startsWith('https://')){colState.art=pic;setCover($('#colCover'),{title:d.name,art:pic});$('#colBackdrop').style.backgroundImage=`url('${(d.cover_photo?.['640x']||pic).replace(/'/g,'%27')}')`}
          $('#colMeta').textContent=[d.follower_count?compactNum(d.follower_count)+' подписчиков':'',d.track_count?plural(d.track_count,'трек','трека','треков'):''].filter(Boolean).join(' · ')}
        return mapAudiusTracks(list).sort((x,y)=>y.plays-x.plays)},empty:'У исполнителя нет доступных треков.'});
  }else{
    openCollection({kind:'artist',kindLabel:'Исполнитель',title:a.name,sub:'Найдено во всех источниках',art:a.art||'',round:true,cover:{title:a.name,artist:'',art:a.art||''},followId:id,
      loader:()=>searchEverywhere(a.name).then(r=>r.filter(t=>t.type!=='radio'&&t.type!=='album'&&similarity(a.name,t.artist)>.55)),empty:'Полных треков этого исполнителя в источниках не нашлось.'});
  }
}
async function searchEverywhere(q){const jobs=sourceJobs(q,{withLocal:true,withCatalog:false,withRadio:false});const out=await Promise.all(jobs.map(([src,fn])=>bounded(src==='local'?fn():cachedSearch(src,q,fn),14000).catch(()=>[])));return mergeSearchResults(out.flat(),[q])}
function openGenre(g){openCollection({kind:'genre',kindLabel:'Жанр · тренды недели',title:g,sub:'Популярное на Audius',cover:{title:g,artist:g},loader:()=>audiusTrending(g),metaFn:tr=>plural(tr.length,'трек','трека','треков')})}
function openMix(name,art){openCollection({kind:'mix',kindLabel:'Микс',title:'Микс: '+name,sub:'Собран по твоей истории',art,cover:{title:name,art},loader:()=>searchEverywhere(name).then(r=>r.filter(t=>t.type!=='radio'&&t.type!=='album').slice(0,40))})}
function artistOf(t){const main=String(t.artist||'').split(/\s*(?:,|\bfeat\.?|\bft\.?)\s+/i)[0].trim()||t.artist;return {name:t.artistId?t.artist:main,artistId:t.artistId||'',handle:t.handle||'',art:t.artistArt&&t.artistArt!==t.art?t.artistArt:''}}

/* ---------- Library tab ---------- */
libTab='playlists';
renderLib=async function(){
  $$('#libSeg button').forEach(b=>b.classList.toggle('on',b.dataset.lib===libTab));
  const el=$('#libList'),act=$('#libActions');act.innerHTML='';el.onclick=null;
  if(libTab==='playlists'){
    act.innerHTML='<button class="chip glass" id="plNew"><svg><use href="#i-plus"/></svg>Новый плейлист</button>';
    $('#plNew').onclick=async()=>{const n=await askText('Название плейлиста','');if(n){const p=Library.create(n);renderLib();toast('Плейлист создан');openPlaylist(p)}};
    const liked=likedTracks();
    el.innerHTML=`<button class="lib-row" data-open="liked">${likedCoverHTML()}<span class="meta"><b>Любимые треки</b><span>Плейлист · ${plural(liked.length,'трек','трека','треков')}</span></span></button>`+
      Library.playlists.map(p=>`<button class="lib-row" data-open="${esc(p.id)}">${mosaicHTML(p.tracks)}<span class="meta"><b>${esc(p.name)}</b><span>Плейлист · ${plural(p.tracks.length,'трек','трека','треков')}</span></span></button>`).join('')+
      (Library.playlists.length?'':'<div class="empty"><svg><use href="#i-queue"/></svg><b>Собери свой первый плейлист</b><span>Нажми «Новый плейлист» или «В плейлист» в меню трека.</span></div>');
    el.onclick=e=>{const b=e.target.closest('[data-open]');if(!b)return;if(b.dataset.open==='liked')openLiked();else{const p=Library.get(b.dataset.open);if(p)openPlaylist(p)}};return;
  }
  if(libTab==='artists'){
    el.innerHTML=Library.follows.length?Library.follows.map((a,i)=>`<button class="lib-row" data-artist="${i}">${a.art?`<div class="cover round" style="background-image:url('${esc(a.art)}')"></div>`:`<div class="cover round">${esc((a.name||'?')[0].toUpperCase())}</div>`}<span class="meta"><b>${esc(a.name)}</b><span>Исполнитель</span></span></button>`).join(''):'<div class="empty"><svg><use href="#i-user"/></svg><b>Ты ещё ни на кого не подписан</b><span>Открой исполнителя из меню трека и нажми «Подписаться».</span></div>';
    el.onclick=e=>{const b=e.target.closest('[data-artist]');if(!b)return;const a=Library.follows[+b.dataset.artist];openArtist({name:a.name,artistId:a.artistId,art:a.art})};return;
  }
  if(libTab==='favs'||libTab==='albums')return renderList(el,S.favs.filter(t=>libTab==='albums'?t.type==='album':t.type!=='album'),{empty:libTab==='albums'?'<svg><use href="#i-disc"/></svg><b>Нет сохранённых альбомов</b><span>Найди альбом и нажми ♥︎ на его странице.</span>':'<svg><use href="#i-heart"/></svg><b>Пока нет любимых</b><span>Нажми ♥︎ у трека или станции.</span>'});
  const files=(await DB.all()).sort((a,b)=>b.added-a.added).map(({blob,...m})=>m);
  if(files.length){act.innerHTML='<button class="chip glass" id="libPlayAll"><svg><use href="#i-play"/></svg>Слушать всё</button><button class="chip glass" id="libShuffle"><svg><use href="#i-shuffle"/></svg>Вперемешку</button>';
    $('#libPlayAll').onclick=()=>{S.shuffle=false;playTrack(files,0)};$('#libShuffle').onclick=()=>{S.shuffle=true;store.set('shuffle',true);playTrack(files,Math.floor(Math.random()*files.length))}}
  renderList(el,files,{del:true,empty:'<svg><use href="#i-folder"/></svg><b>Добавь музыку с телефона</b><span>MP3, FLAC, M4A, OGG, WAV — файлы будут играть без интернета.</span>'});
};

/* ---------- Small sheet helpers ---------- */
function askText(title,value){return new Promise(resolve=>{openSheet({title,sub:'',tracks:[],cover:{title:title}});$('#sheet').dataset.mode='ask';$('#sheetCover').style.display='none';$('#sheetList').onclick=null;$('#sheetList').innerHTML='';
  $('#sheetActions').innerHTML=`<form class="ask-form" id="askForm"><input class="settings-input" id="askInput" maxlength="80" autocomplete="off" value="${esc(value||'')}" placeholder="Например, «Вечер пятницы»"><div class="api-actions"><button class="btn-accent" type="submit">Готово</button><button class="chip" type="button" id="askCancel">Отмена</button></div></form>`;
  let done=false;const finish=v=>{if(done)return;done=true;$('#sheetCover').style.display='';closeSheet();resolve(v)};
  $('#askForm').onsubmit=e=>{e.preventDefault();finish($('#askInput').value.trim())};$('#askCancel').onclick=()=>finish(null);
  setTimeout(()=>$('#askInput')?.focus(),350);
  const watch=new MutationObserver(()=>{if(!$('#sheet').classList.contains('open')){watch.disconnect();if(!done){done=true;$('#sheetCover').style.display='';resolve('')}}});watch.observe($('#sheet'),{attributes:true,attributeFilter:['class']});
})}
function addToPlaylist(t){
  openSheet({title:'Добавить в плейлист',sub:t.title+' — '+t.artist,tracks:[],cover:t});$('#sheet').dataset.mode='addpl';$('#sheetList').onclick=null;$('#sheetActions').innerHTML='';
  const draw=()=>{$('#sheetList').innerHTML=`<button class="lib-row" data-pl="new"><div class="cover pl-empty"><svg><use href="#i-plus"/></svg></div><span class="meta"><b>Новый плейлист</b><span>Создать и добавить трек</span></span></button>`+Library.playlists.map(p=>{const has=p.tracks.some(x=>x.id===t.id);return `<button class="lib-row" data-pl="${esc(p.id)}">${mosaicHTML(p.tracks)}<span class="meta"><b>${esc(p.name)}</b><span>${plural(p.tracks.length,'трек','трека','треков')}</span></span><span class="check${has?' on':''}"><svg><use href="#i-check"/></svg></span></button>`}).join('')};
  draw();$('#sheetList').onclick=async e=>{const b=e.target.closest('[data-pl]');if(!b)return;
    if(b.dataset.pl==='new'){const n=await askText('Название плейлиста','');if(!n)return;const p=Library.create(n);Library.toggle(p,t);toast('Добавлено в «'+p.name+'»');return}
    const p=Library.get(b.dataset.pl);const added=Library.toggle(p,t);toast(added?'Добавлено в «'+p.name+'»':'Убрано из «'+p.name+'»');draw();if(colState?.id===p.id){colState.tracks=p.tracks;renderCollection()}};
}
function shareText(title,text){try{if(window.LumenNative?.shareText){LumenNative.shareText(title,text);return}}catch{}if(navigator.share){navigator.share({title,text}).catch(()=>{});return}navigator.clipboard?.writeText(text).then(()=>toast('Скопировано'),()=>toast('Не удалось поделиться'))}
function shareTrack(t){shareText(t.title,`${t.title} — ${t.artist}${t.sourceUrl?'\n'+t.sourceUrl:''}\n\nСлушаю в Lazzy sound`)}

/* Extra actions in the track sheet: playlist, artist, share, remove from this playlist */
const trackInfoBase=openTrackInfo;
openTrackInfo=function(t){
  const r=trackInfoBase(t);const row=$('#sheetActions .track-actions');
  if(row&&t){const pl=Library.ctx&&Library.get(Library.ctx);
    row.insertAdjacentHTML('afterbegin',`${t.type!=='radio'&&t.type!=='album'?'<button class="chip" id="infoAddPl"><svg><use href="#i-plus"/></svg>В плейлист</button>':''}${t.type!=='radio'&&t.type!=='album'&&t.artist?'<button class="chip" id="infoArtist"><svg><use href="#i-user"/></svg>Исполнитель</button>':''}<button class="chip" id="infoShare"><svg><use href="#i-external"/></svg>Поделиться</button>${pl&&pl.tracks.some(x=>x.id===t.id)?'<button class="chip danger" id="infoUnPl"><svg><use href="#i-trash"/></svg>Убрать из плейлиста</button>':''}`);
    if($('#infoAddPl'))$('#infoAddPl').onclick=()=>addToPlaylist(t);
    if($('#infoArtist'))$('#infoArtist').onclick=()=>openArtist(artistOf(t));
    $('#infoShare').onclick=()=>shareTrack(t);
    if($('#infoUnPl'))$('#infoUnPl').onclick=()=>{Library.toggle(pl,t);closeSheet();colState.tracks=pl.tracks;renderCollection();toast('Убрано из плейлиста')};
  }
  return r;
};

/* ---------- Queue: reorder by dragging, remove, jump ---------- */
function openQueue(){
  openSheet({title:'Очередь',sub:S.queue.length?plural(S.queue.length,'трек','трека','треков'):'Пусто',tracks:[],cover:cur()||{title:'Очередь'}});$('#sheet').dataset.mode='queue';$('#sheetList').onclick=null;
  const isWave=S.queue.some(t=>t&&(t._wave||t._tw));
  $('#sheetActions').innerHTML=S.queue.length>1?`<button class="chip" id="qClear"><svg><use href="#i-trash"/></svg>Очистить «Далее»</button><button class="chip" id="qSave"><svg><use href="#i-plus"/></svg>${isWave?'Сохранить волну':'В плейлист'}</button>`:'';
  if($('#qSave'))$('#qSave').onclick=()=>saveAsPlaylist(S.queue,isWave?(MyWave.on&&typeof WAVE_MODES!=='undefined'?'Моя волна · '+WAVE_MODES[MyWave.mode].label:'Волна')+' '+new Date().toLocaleDateString('ru-RU'):'Очередь '+new Date().toLocaleDateString('ru-RU'));
  if($('#qClear'))$('#qClear').onclick=()=>{S.queue=S.queue.slice(0,S.idx+1);drawQueue();toast('Очередь очищена')};
  drawQueue();
}
function drawQueue(){
  const el=$('#sheetList');if(!S.queue.length){el.innerHTML='<div class="empty"><b>Очередь пуста</b><span>Включи трек, альбом или плейлист.</span></div>';return}
  const row=(t,i)=>`<div class="q-row${i===S.idx?' now':''}" data-q="${i}">${coverHTML(t,'sm')}<span class="meta"><b>${esc(t.title)}</b><span>${esc(t.artist||'')}</span></span>${i===S.idx?'<span class="q-now">Играет</span>':`<button class="ibtn q-del" aria-label="Убрать"><svg><use href="#i-plus"/></svg></button><span class="q-grip" aria-label="Перетащить"><svg><use href="#i-grip"/></svg></span>`}</div>`;
  const up=S.queue.map((t,i)=>[t,i]).filter(([,i])=>i>S.idx);
  el.innerHTML=`<p class="q-label">Сейчас играет</p>${row(S.queue[S.idx],S.idx)}<p class="q-label">Далее${up.length?' · '+up.length:''}</p><div class="q-list">${up.map(([t,i])=>row(t,i)).join('')||'<p class="info-muted">Дальше ничего нет — после трека плеер остановится.</p>'}</div>`;
  el.onclick=e=>{const r=e.target.closest('[data-q]');if(!r)return;const i=+r.dataset.q;
    if(e.target.closest('.q-del')){S.queue.splice(i,1);if(i<S.idx)S.idx--;drawQueue();$('#sheetSub').textContent=plural(S.queue.length,'трек','трека','треков');return}
    if(e.target.closest('.q-grip'))return;if(i!==S.idx){S.idx=i;load();setTimeout(drawQueue,60)}};
  enableQueueDrag($('.q-list'));
}
function enableQueueDrag(list){
  if(!list)return;let drag=null;
  list.addEventListener('pointerdown',e=>{const g=e.target.closest('.q-grip');if(!g)return;const r=g.closest('.q-row');e.preventDefault();g.setPointerCapture(e.pointerId);
    const rows=[...list.querySelectorAll('.q-row')];drag={r,g,y0:e.clientY,h:r.offsetHeight,rows,from:rows.indexOf(r),to:rows.indexOf(r)};r.classList.add('dragging')});
  list.addEventListener('pointermove',e=>{if(!drag)return;const dy=e.clientY-drag.y0;drag.r.style.transform=`translateY(${dy}px) scale(1.02)`;
    const to=Math.max(0,Math.min(drag.rows.length-1,drag.from+Math.round(dy/drag.h)));drag.to=to;
    drag.rows.forEach((x,i)=>{if(x===drag.r)return;const shift=drag.from<to&&i>drag.from&&i<=to?-drag.h:drag.from>to&&i<drag.from&&i>=to?drag.h:0;x.style.transform=shift?`translateY(${shift}px)`:''})});
  const end=()=>{if(!drag)return;const {from,to,rows}=drag;rows.forEach(x=>{x.style.transform='';x.classList.remove('dragging')});drag=null;
    if(from!==to){const base=S.idx+1;const [t]=S.queue.splice(base+from,1);S.queue.splice(base+to,0,t)}drawQueue()};
  list.addEventListener('pointerup',end);list.addEventListener('pointercancel',end);
}
$('#queueBtn').onclick=openQueue;

/* ---------- Player extras: share, artist ---------- */
if($('#shareBtn'))$('#shareBtn').onclick=()=>{if(cur())shareTrack(cur())};
if($('#fullArtist'))$('#fullArtist').onclick=()=>{const t=cur();if(t&&t.type!=='radio'&&t.type!=='local')openArtist(artistOf(t))};

/* ---------- Mini player: swipe left/right to skip (Spotify) ---------- */
(()=>{const m=$('#mini');let x0=null,y0=0,dx=0,swiped=false;
  m.addEventListener('touchstart',e=>{if(e.target.closest('button'))return;x0=e.touches[0].clientX;y0=e.touches[0].clientY;dx=0;swiped=false},{passive:true});
  m.addEventListener('touchmove',e=>{if(x0===null)return;dx=e.touches[0].clientX-x0;if(Math.abs(dx)>10&&Math.abs(dx)>Math.abs(e.touches[0].clientY-y0)){swiped=true;m.querySelector('.meta').style.transform=`translateX(${dx}px)`;m.querySelector('.meta').style.opacity=String(1-Math.min(.7,Math.abs(dx)/220))}},{passive:true});
  m.addEventListener('touchend',()=>{if(x0===null)return;x0=null;const meta=m.querySelector('.meta');
    if(swiped&&Math.abs(dx)>70&&S.queue.length>1){const dir=dx<0?-1:1;meta.animate([{transform:`translateX(${dx}px)`,opacity:.3},{transform:`translateX(${dir*240}px)`,opacity:0}],{duration:180,easing:'ease-in'}).onfinish=()=>{dir<0?next():prev();meta.style.transform='';meta.style.opacity='';meta.animate([{transform:`translateX(${-dir*60}px)`,opacity:0},{transform:'none',opacity:1}],{duration:320,easing:'cubic-bezier(.2,.9,.25,1)'})}}
    else{meta.style.transition='transform .35s cubic-bezier(.34,1.4,.5,1),opacity .3s';meta.style.transform='';meta.style.opacity='';setTimeout(()=>meta.style.transition='',380)}});
  m.addEventListener('click',e=>{if(swiped){e.stopImmediatePropagation();e.preventDefault();swiped=false}},true);
})();

/* ---------- SoundCloud-style waveform scrubber ---------- */
const Wave={peaks:[],id:'',cv:$('#wave')};
function seeded(id){let h=hash(id)||1;return()=>{h^=h<<13;h^=h>>>17;h^=h<<5;return((h>>>0)%10000)/10000}}
function fakePeaks(id,n=96){const r=seeded(id);const out=[];let v=.5;const sect=[.35,.6,.8,.55,.95,.7,.9,.45];for(let i=0;i<n;i++){const env=sect[Math.floor(i/n*sect.length)];v=v*.55+r()*.45;out.push(Math.max(.12,Math.min(1,env*(.55+v*.75))))}return out}
async function realPeaks(t,n=96){try{const rec=await DB.get(t.id);if(!rec||rec.blob.size>30e6)return null;const Ctx=window.AudioContext||window.webkitAudioContext;const ctx=new Ctx();const buf=await ctx.decodeAudioData(await rec.blob.arrayBuffer());ctx.close();const d=buf.getChannelData(0),step=Math.floor(d.length/n);const out=[];for(let i=0;i<n;i++){let m=0;for(let j=i*step;j<(i+1)*step;j+=16)m=Math.max(m,Math.abs(d[j]));out.push(m)}const mx=Math.max(...out)||1;return out.map(x=>Math.max(.1,x/mx))}catch{return null}}
function drawWave(){
  const cv=Wave.cv;if(!cv||!Wave.peaks.length||!$('#full').classList.contains('open'))return;const w=cv.clientWidth,h=cv.clientHeight;if(!w)return;const dpr=Math.min(2,devicePixelRatio||1);
  if(cv.width!==w*dpr){cv.width=w*dpr;cv.height=h*dpr}const x=cv.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,w,h);
  const p=parseFloat($('#seek').style.getPropertyValue('--p'))/100||0;const n=Wave.peaks.length,gap=2,bw=(w-gap*(n-1))/n;
  const cs=getComputedStyle(document.documentElement);const g=x.createLinearGradient(0,0,w,0);g.addColorStop(0,cs.getPropertyValue('--accent-2').trim()||'#8bf3e6');g.addColorStop(1,cs.getPropertyValue('--accent-3').trim()||'#2e7dff');
  const live=!isFinite(audio.duration);
  Wave.peaks.forEach((v,i)=>{const bh=Math.max(3,v*h*.92),xx=i*(bw+gap),played=!live&&(i+.5)/n<=p;x.fillStyle=played?g:'rgba(255,255,255,.28)';const r=Math.min(bw/2,2);x.beginPath();x.roundRect?x.roundRect(xx,(h-bh)/2,bw,bh,r):x.rect(xx,(h-bh)/2,bw,bh);x.fill()});
}
async function prepareWave(){const t=cur();if(!t||Wave.id===t.id)return;Wave.id=t.id;Wave.peaks=t.type==='radio'?Array.from({length:96},(_,i)=>.35+.25*Math.sin(i/3)):fakePeaks(t.id);drawWave();if(t.type==='local'){const real=await realPeaks(t);if(real&&Wave.id===t.id){Wave.peaks=real;drawWave()}}}
let waveRaf=0;const waveTick=()=>{if(waveRaf)return;waveRaf=requestAnimationFrame(()=>{waveRaf=0;drawWave()})};
audio.addEventListener('timeupdate',waveTick);audio.addEventListener('loadstart',prepareWave);$('#seek').addEventListener('input',waveTick);
new MutationObserver(()=>{if($('#full').classList.contains('open')){prepareWave();setTimeout(drawWave,40);setTimeout(drawWave,650)}}).observe($('#full'),{attributes:true,attributeFilter:['class']});
addEventListener('resize',waveTick);

/* ======================= 3.3: artists with everything, albums that play ======================= */
async function audiusAllTracks(id){const all=[];for(let off=0;off<300;off+=100){const j=await audiusApi(`/v1/users/${id}/tracks?limit=100&offset=${off}`);all.push(...mapAudiusTracks(j));if((j.data||[]).length<100)break}return all}
/* 6.4.9: strict artist identity — «DJ Paskudas» ≠ «DJ Pankadas» (fuzzy similarity mixed up artists, their albums and photos) */
function artistKey(s){return normalize(String(s||'').replace(/\s*[-–—]\s*topic\s*$/i,'').replace(/\s*vevo\s*$/i,'')).replace(/[^a-z0-9а-яё]/gi,'')}
function sameArtist(a,b){const x=artistKey(a),y=artistKey(b);if(!x||!y)return false;if(x===y)return true;
  if(typeof translit==='function'){const tx=artistKey(translit(String(a))),ty=artistKey(translit(String(b)));if(tx&&(tx===ty||(/[а-яё]/i.test(a+b)&&/[a-z]/i.test(a+b)&&Math.min(tx.length,ty.length)>=6&&similarity(tx,ty)>=.85)))return true}
  return Math.min(x.length,y.length)>=8&&similarity(x,y)>=.95}
function artistMatch(name,credit){if(sameArtist(name,credit))return true;const parts=typeof splitArtists==='function'?splitArtists(credit):[credit];return parts.some(p=>sameArtist(name,p))}
async function catalogAlbumsFor(name){try{return (await bounded(searchAlbumCatalog(name),15000)).filter(a=>sameArtist(name,a.artist)).slice(0,24)}catch{return []}}
function renderColSections(albums){
  const el=$('#colSections');if(!albums.length){el.innerHTML='';return}
  el.innerHTML=`<div class="shelf-head"><h2>Альбомы</h2><span class="shelf-sub">${albums.length}</span></div><div class="cards">${albums.map((a,i)=>cardHTML(a,i,a.year||'Альбом')).join('')}</div>`;
  el.querySelector('.cards').onclick=e=>{const b=e.target.closest('[data-i]');if(b)openAlbum(albums[+b.dataset.i])};
}
const baseOpenCollection=openCollection;
openCollection=function(o){$('#colSections').innerHTML='';$('#colListLabel').textContent=o.listLabel||'';return baseOpenCollection(o)};
openArtist=function(a){
  const id=a.artistId?'artist:audius:'+a.artistId:'artist:name:'+normalize(a.name);
  openCollection({kind:'artist',kindLabel:'Исполнитель',title:a.name,sub:a.handle?'@'+a.handle:'Все источники',art:a.art||'',round:true,cover:{title:a.name,artist:'',art:a.art||''},followId:id,artistId:a.artistId||'',listLabel:'Треки',
    empty:'<svg><use href="#i-note"/></svg><b>Полных треков не нашлось</b><span>Альбомы выше можно открыть — приложение поищет аудио для каждой песни.</span>',
    metaFn:tr=>plural(tr.length,'трек','трека','треков'),
    loader:async()=>{
      const B=(p,v)=>bounded(Promise.resolve(p),20000).catch(()=>v);
      const [aud,others,albums,user]=await Promise.all([
        a.artistId?B(audiusAllTracks(a.artistId),[]):[],
        B(searchEverywhere(a.name).then(r=>r.filter(t=>t.type!=='radio'&&t.type!=='album'&&artistMatch(a.name,t.artist||''))),[]),
        catalogAlbumsFor(a.name),
        a.artistId?B(audiusApi('/v1/users/'+a.artistId),null):null]);
      if(colState?.followId!==id)return [];
      const d=user?.data;
      if(d){const pic=d.profile_picture?.['480x480']||d.profile_picture?.['150x150']||'';if(pic.startsWith('https://')){colState.art=pic;setCover($('#colCover'),{title:d.name,art:pic});$('#colBackdrop').style.backgroundImage=`url('${(d.cover_photo?.['640x']||pic).replace(/'/g,'%27')}')`}}
      else if(!a.art&&albums[0]?.art){colState.art=albums[0].art;setCover($('#colCover'),{title:a.name,art:albums[0].art});$('#colBackdrop').style.backgroundImage=`url('${albums[0].art.replace(/'/g,'%27')}')`}
      renderColSections(albums);
      /* 6.3.2: tracks of this artist you already saved (favourites, history, playlists) — they still play even when a source's search is gone */
      const mine=[...S.favs,...S.recent,...Library.playlists.flatMap(p=>p.tracks||[])].filter(t=>t&&isFullAudio(t)&&t.type!=='radio'&&artistMatch(a.name,t.artist||''));
      const seen=new Set();const tracks=[...mine,...aud.sort((x,y)=>y.plays-x.plays),...others].filter(t=>{const k=normalize(t.artist)+'|'+normalize(plainTitle(t.title));if(seen.has(k))return false;seen.add(k);return true});
      colState.metaFn=tr=>[d?.follower_count?compactNum(d.follower_count)+' подписчиков':'',plural(tr.length,'трек','трека','треков'),albums.length?plural(albums.length,'альбом','альбома','альбомов'):''].filter(Boolean).join(' · ');
      return tracks;
    }});
};

/* Albums from the catalogue: find a full recording for every song automatically */
async function bestMatch(t){
  const q=t.artist+' '+plainTitle(t.title);
  const jobs=sourceJobs(q,{withLocal:true,withCatalog:false,withRadio:false}).filter(([s])=>s!=='commons');
  const out=(await Promise.all(jobs.map(([s,fn])=>bounded(s==='local'?fn():cachedSearch(s,q,fn),12000).catch(()=>[])))).flat();
  let best=null,bestScore=0;
  for(const c of out){if(!isFullAudio(c)||c.type==='radio')continue;
    let sc=similarity(plainTitle(t.title),plainTitle(c.title))*.62+similarity(t.artist,c.artist)*.38;
    if(t.duration&&c.duration){const dd=Math.abs(t.duration-c.duration);sc-=dd>20?.25:dd>8?.08:0}
    if(/(cover|remix|karaoke|instrumental|минус|кавер|live)/i.test(c.title)&&!/(cover|remix|karaoke|instrumental|live)/i.test(t.title))sc-=.15;
    if(sc>bestScore){bestScore=sc;best=c}}
  return bestScore>=.78?best:null;
}
let albumRenderQueued=false;
const renderAlbumSoon=()=>{if(albumRenderQueued)return;albumRenderQueued=true;requestAnimationFrame(()=>{albumRenderQueued=false;if(view==='album')renderAlbumTracks()})};
async function resolveAlbum(state){
  const gen=albumGeneration;const todo=state.tracks.map((t,i)=>[t,i]).filter(([t])=>t.type==='catalogTrack');if(!todo.length)return;
  const total=todo.length;let found=0,done=0;
  const status=()=>{$('#albumAvailability').textContent=`Найдено ${found} из ${total}`+(done<total?' · ищем…':'');$('#albumFootnote').textContent=done<total?'Подбираем полные записи из подключённых источников. Можно уже слушать найденное.':found<total?'Для песен без аудио нажми на строку — покажем все варианты.':'Все песни альбома найдены.'};
  status();
  const worker=async()=>{while(todo.length){const [t,i]=todo.shift();if(gen!==albumGeneration)return;const m=await bestMatch(t).catch(()=>null);done++;
    if(gen!==albumGeneration||albumState!==state)return;
    if(m){found++;state.tracks[i]={...m,_found:true,trackNumber:t.trackNumber,discNumber:t.discNumber,albumName:t.albumName,album:t.album,albumTrackId:t.id,art:t.art||m.art,meta:t.meta||m.meta};$('#albumPlay').disabled=$('#albumShuffle').disabled=false}
    else state.tracks[i]={...t,_missing:true};
    status();renderAlbumSoon()}};
  await Promise.all([worker(),worker(),worker()]);
}
const baseRenderAlbumTracks=renderAlbumTracks;
renderAlbumTracks=function(){baseRenderAlbumTracks();if(!albumState)return;
  $$('#albumTracks [data-album-track]').forEach(row=>{const t=albumState.tracks.find(x=>x.id===row.dataset.albumTrack);if(!t)return;
    row.classList.toggle('pending',t.type==='catalogTrack'&&!t._missing);row.classList.toggle('missing',!!t._missing);row.classList.toggle('found',!!t._found)})};
const baseOpenAlbum=openAlbum;
openAlbum=async function(a){await baseOpenAlbum(a);if(albumState&&albumState.album===a&&a.catalog==='apple')resolveAlbum(albumState)};
