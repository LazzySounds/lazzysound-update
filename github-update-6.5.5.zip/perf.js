'use strict';
/* Lazzy sound 3.6 — runs well on any phone.
   Three tiers decide how much eye candy is drawn:
   • high — everything (blur glass, particles at ~72 fps, drifting wallpaper, 120/144 Hz);
   • mid  — lighter blur, slower wallpaper, particles at ~45 fps, fewer of them;
   • low  — no live blur (solid glass), static wallpaper, no particles by default, simpler transitions, 60 Hz.
   The tier is guessed from RAM / CPU before the first paint, and in Auto mode a frame-time probe steps it down
   if the phone still drops frames. Profile → Вид → Производительность overrides it. */
const PERF_LABEL={auto:'Авто',high:'Красиво',mid:'Баланс',low:'Экономно'};
const perfTier=()=>document.documentElement.dataset.perf||'high';
const perfLow=()=>perfTier()==='low';
/* frame budget for decorative canvases (ms between draws) */
const perfFrameGap=()=>({high:12.5,mid:21,low:32})[perfTier()]||12.5;
function perfApplyRefresh(){try{window.LumenNative?.setRefreshMode?.(perfTier()==='low'?'60':'max')}catch{}}
function setPerf(mode){
  store.set('perfMode',mode);store.set('perfAuto',null);
  location.reload();
}
function renderPerfSettings(){
  const host=$('#perfSettings');if(!host)return;const mode=document.documentElement.dataset.perfMode||'auto';
  let dev='';try{const i=JSON.parse(window.LumenNative?.deviceInfo?.()||'{}');if(i.ramMb)dev=`${(i.ramMb/1024).toFixed(1).replace('.0','')} ГБ ОЗУ · ${i.cores} ядер · до ${i.maxHz} Гц`}catch{}
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-bolt"/></svg><h2>Производительность</h2></div>
    <p class="settings-help">${mode==='auto'?'Сейчас: <b>'+PERF_LABEL[perfTier()]+'</b> — подобрано под это устройство.':'Выбрано вручную.'}${dev?' '+dev+'.':''}</p>
    <div class="choice-row perf-row" id="perfChoices">${Object.entries(PERF_LABEL).map(([k,l])=>`<button data-perf-mode="${k}" class="${k===mode?'on':''}">${l}</button>`).join('')}</div>
    <p class="settings-help">«Экономно» убирает живое размытие, частицы и сложные переходы — для самых слабых телефонов и экономии батареи.</p>`;
  $('#perfChoices').onclick=e=>{const b=e.target.closest('[data-perf-mode]');if(b&&b.dataset.perfMode!==mode)setPerf(b.dataset.perfMode)};
}
renderPerfSettings();perfApplyRefresh();

/* Auto mode: watch real frame times for a few seconds of use; step down a tier if too many frames are late. */
(function perfProbe(){
  if((document.documentElement.dataset.perfMode||'auto')!=='auto'||perfLow())return;
  let samples=[],last=0,running=false,checks=0,timer=0;
  function tick(t){if(!running)return;if(last&&!document.hidden)samples.push(t-last);last=t;requestAnimationFrame(tick)}
  function start(ms){if(running||checks>=3)return;running=true;last=0;samples=[];requestAnimationFrame(tick);clearTimeout(timer);timer=setTimeout(stop,ms)}
  function stop(){
    running=false;checks++;if(samples.length<40)return;
    const slow=samples.filter(x=>x>34).length/samples.length,sorted=[...samples].sort((a,b)=>a-b),med=sorted[sorted.length>>1];
    if(slow>.2||med>26){
      const pc=!/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);if(pc&&perfTier()==='mid')return;
      const next=perfTier()==='high'?'mid':'low';store.set('perfAuto',next);document.documentElement.dataset.perf=next;
      perfApplyRefresh();if(typeof FxEngine!=='undefined')FxEngine.restart();renderPerfSettings();
      toast(next==='low'?'Включён экономный режим — так плавнее':'Анимации облегчены под этот телефон');
    }
  }
  document.addEventListener('lazzy:intro-done',()=>setTimeout(()=>start(3000),600),{once:true});
  let scrollProbe=0;addEventListener('scroll',()=>{if(++scrollProbe===8)start(2500)},{passive:true});
  document.addEventListener('click',e=>{if(e.target.closest('.tabbar,#mini,.seg'))setTimeout(()=>start(1500),0)},{passive:true});
})();
