'use strict';
/* Lazzy sound 3.2 — Spotify-like home: quick grid, Audius trends, recently played shelf, mixes from history, genres. */
const cardHTML=(t,i,sub)=>`<button class="card" data-i="${i}"><span class="card-art">${t.coverHTML||coverHTML(t,'cv-lg')}<span class="card-play" aria-hidden="true"><svg><use href="#i-play"/></svg></span></span><b>${esc(t.title)}</b><small>${esc(sub??t.artist??'')}</small></button>`;
const skeleton=n=>Array.from({length:n},()=>'<span class="card skeleton"><span class="card-art"></span><b></b><small></small></span>').join('');

/* Quick grid (Spotify's 2×3 "jump back in") */
renderHero=function(){
  const el=$('#homeHero');if(!el)return;const tiles=[{kind:'liked',title:'Любимые треки',html:likedCoverHTML('sm')}];
  [...Library.playlists].sort((a,b)=>b.updatedAt-a.updatedAt).slice(0,2).forEach(p=>tiles.push({kind:'pl',id:p.id,title:p.name,html:mosaicHTML(p.tracks,'sm')}));
  const seen=new Set();for(const t of S.recent){if(tiles.length>=6)break;if(!isUsableEntry(t)||seen.has(t.id))continue;seen.add(t.id);tiles.push({kind:'t',t,title:t.title,html:coverHTML(t,'sm')})}
  for(const t of S.favs){if(tiles.length>=6)break;if(seen.has(t.id)||!isUsableEntry(t))continue;seen.add(t.id);tiles.push({kind:'t',t,title:t.title,html:coverHTML(t,'sm')})}
  const c=cur();
  el.innerHTML=tiles.map((x,i)=>`<button class="tile${x.t&&c&&x.t.id===c.id?' playing':''}" data-tile="${i}">${x.html}<b>${esc(x.title)}</b>${x.t&&c&&x.t.id===c.id?'<span class="tile-eq"><i></i><i></i><i></i></span>':''}</button>`).join('');
  el.onclick=e=>{const b=e.target.closest('[data-tile]');if(!b)return;const x=tiles[+b.dataset.tile];
    if(x.kind==='liked')return openLiked();if(x.kind==='pl'){const p=Library.get(x.id);if(p)openPlaylist(p);return}
    if(x.t.type==='album')return openAlbum(x.t);if(cur()?.id===x.t.id){$('#full').classList.add('open');return}
    const list=S.recent.filter(isFullAudio);const i=list.findIndex(y=>y.id===x.t.id);i>=0?playTrack(list,i):playTrack([x.t],0)};
};

/* Recently played as a horizontal shelf */
renderRecent=function(){
  const el=$('#recentList');if(!el)return;const items=S.recent.filter(isUsableEntry).slice(0,14);
  el.closest('.shelf').hidden=!items.length;
  el.innerHTML=items.map((t,i)=>cardHTML(t,i,t.type==='radio'?'Радио':t.artist)).join('');
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(!b)return;const t=items[+b.dataset.i];if(t.type==='album')return openAlbum(t);const q=items.filter(isFullAudio);playTrack(q,q.findIndex(x=>x.id===t.id))};
  renderHero();renderMixes();
};

/* Mixes from the artists you play most */
function renderMixes(){
  const el=$('#shelfMixes');if(!el)return;const score=new Map();
  for(const [list,w] of [[S.recent,2],[S.favs,3]])for(const t of list){if(!t.artist||t.type==='radio'||t.type==='album'||t.type==='local')continue;const k=normalize(t.artist);const o=score.get(k)||{name:t.artist,art:t.art||t.artistArt||'',n:0};o.n+=w;if(!o.art)o.art=t.art||'';score.set(k,o)}
  const mixes=[...score.values()].sort((a,b)=>b.n-a.n).slice(0,6);
  el.closest('.shelf').hidden=!mixes.length;
  el.innerHTML=mixes.map((m,i)=>cardHTML({title:'Микс: '+m.name,artist:m.name,art:m.art},i,'По твоей истории')).join('');
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(b){const m=mixes[+b.dataset.i];openMix(m.name,m.art)}};
}

/* Trending on Audius — painted instantly from cache, refreshed in the background */
let trending=store.get('trendCache',{t:0,items:[]}).items||[];
function paintTrending(){
  const el=$('#shelfTrending');if(!el)return;
  if(!trending.length){el.innerHTML=skeleton(5);return}
  el.innerHTML=trending.slice(0,16).map((t,i)=>cardHTML(t,i,t.artist+(t.plays?' · ▶︎ '+compactNum(t.plays):''))).join('');
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(b)playTrack(trending.filter(isFullAudio),+b.dataset.i)};
}
async function loadTrending(){
  paintTrending();
  try{const list=await audiusTrending('','week');if(list.length){trending=list;store.set('trendCache',{t:Date.now(),items:list.slice(0,24)});paintTrending()}}
  catch{if(!trending.length){const el=$('#shelfTrending');el.innerHTML='<p class="info-muted shelf-fail">Тренды Audius сейчас недоступны. <button class="text-link" id="trRetry">Повторить</button></p>';$('#trRetry').onclick=loadTrending}}
}
$('#trendAll').onclick=()=>openCollection({kind:'trending',kindLabel:'Audius · неделя',title:'Тренды недели',sub:'Самое популярное на Audius',cover:{title:'Тренды',artist:'Audius'},loader:()=>audiusTrending('','week'),metaFn:tr=>plural(tr.length,'трек','трека','треков')});

/* Genres grid */
$('#shelfGenres').innerHTML=AUDIUS_GENRES.map(([g,h])=>`<button class="genre" style="--gh:${h}" data-genre="${esc(g)}"><b>${esc(g)}</b><i aria-hidden="true"></i></button>`).join('');
$('#shelfGenres').onclick=e=>{const b=e.target.closest('[data-genre]');if(b)openGenre(b.dataset.genre)};

renderRecent();loadTrending();
/* play/pause needs no re-render: the equaliser pauses via CSS (body:not(.is-playing)) */

/* ---------- 3.5: greetings from around the world (tap the title for another one) ---------- */
const GREETINGS=[
  ['Привет','по‑русски'],['Hola','по‑испански'],['Bonjour','по‑французски'],['Ciao','по‑итальянски'],['Hallo','по‑немецки'],
  ['Olá','по‑португальски'],['Hej','по‑шведски'],['Ahoj','по‑чешски · и по‑пиратски'],['Szia','по‑венгерски'],['Merhaba','по‑турецки'],
  ['Konnichiwa','по‑японски · こんにちは'],['Annyeong','по‑корейски · 안녕'],['Nǐ hǎo','по‑китайски · 你好'],['Namaste','на хинди · नमस्ते'],
  ['Aloha','по‑гавайски · и «пока» тоже'],['Kia ora','на маори'],['Jambo','на суахили'],['Sawubona','на зулу · «я тебя вижу»'],
  ['Salam','по‑арабски · سلام'],['Sälem','по‑казахски'],['Shalom','на иврите · שלום'],['Yassas','по‑гречески'],
  ['Hei','по‑фински'],['Dia dhuit','по‑ирландски'],['Mingalaba','по‑бирмански'],['Sawasdee','по‑тайски'],['Xin chào','по‑вьетнамски'],
  ['Привіт','по‑украински'],['Sveiki','по‑латышски'],['Bula','по‑фиджийски'],['Howdy','по‑техасски'],['Yo','по‑уличному']
];
const GREET_MOODS=h=>h<5?[['Не спится?','ночной режим включён'],['Тихой ночи','звук на минимум, вайб на максимум']]
  :h<12?[['Доброе утро','кофе и музыка'],['Подъём','плейлист уже разогрет'],['Утро доброе','начнём с хорошего']]
  :h<18?[['Добрый день','перерыв на трек?'],['Погнали','день в самом разгаре']]
  :[['Добрый вечер','время любимых треков'],['Чилим','вечер — лучшее время']];
let greetIdx=-1;
function pickGreeting(){
  const h=new Date().getHours(),day=new Date().getDay();
  const pool=[...GREET_MOODS(h),...GREETINGS];if(day===5&&h>=15)pool.push(['Пятница!','наконец‑то']);
  let i;do i=Math.floor(Math.random()*pool.length);while(pool.length>1&&i===greetIdx);greetIdx=i;return pool[i];
}
let currentGreeting=null;
function renderGreeting(fresh=true){
  if(fresh||!currentGreeting)currentGreeting=pickGreeting();
  const [word,note]=currentGreeting,name=(typeof Prefs!=='undefined'&&Prefs.name.trim())||'';
  const el=$('#greet'),k=$('#greetKicker');
  el.innerHTML=`<span class="greet-word">${esc(word)}</span>${name?`<span class="greet-name">, ${esc(name)}</span>`:''}`;
  el.classList.toggle('long',(word+name).length>16);
  if(k)k.textContent=note;
}
renderGreeting();
$('#greet').addEventListener('click',()=>{
  const el=$('#greet'),k=$('#greetKicker'),reduce=document.documentElement.dataset.motion==='reduce';
  if(reduce){renderGreeting();return}
  const out=[el,k].map(n=>n.animate([{opacity:1,transform:'none'},{opacity:0,transform:'translate3d(0,-10px,0)'}],{duration:160,easing:'ease-in',fill:'forwards'}));
  out[0].onfinish=()=>{renderGreeting();out.forEach(a=>a.cancel());
    [el,k].forEach((n,i)=>n.animate([{opacity:0,transform:'translate3d(0,12px,0)'},{opacity:1,transform:'none'}],{duration:520,delay:i*40,easing:'cubic-bezier(.16,1,.3,1)',fill:'backwards'}))};
});
