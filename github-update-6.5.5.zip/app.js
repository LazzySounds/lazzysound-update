'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = t => !isFinite(t) || t < 0 ? '0:00' : Math.floor(t/60) + ':' + String(Math.floor(t%60)).padStart(2,'0');
const hash = s => { let h = 0; for (const c of String(s)) h = (h*31 + c.charCodeAt(0)) | 0; return Math.abs(h); };
const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400); };
const store = { get:(k,d)=>{ try{ return JSON.parse(localStorage.getItem('lumen.'+k)) ?? d }catch{ return d } }, set:(k,v)=>localStorage.setItem('lumen.'+k, JSON.stringify(v)) };

/* ---------- IndexedDB: music and an optional private custom font ---------- */
const DB = (() => {
  let db; const open = () => db ? Promise.resolve(db) : new Promise((resolve,reject) => {
    const r = indexedDB.open('lumen', 3);
    r.onupgradeneeded = () => { for (const n of ['files','assets','collections']) if (!r.result.objectStoreNames.contains(n)) r.result.createObjectStore(n,{keyPath:'id'}); };
    r.onsuccess=()=>resolve(db=r.result); r.onerror=()=>reject(r.error);
  });
  const tx=(name,mode,fn)=>open().then(d=>new Promise((resolve,reject)=>{ const t=d.transaction(name,mode),r=fn(t.objectStore(name)); t.oncomplete=()=>resolve(r.result); t.onerror=()=>reject(t.error); t.onabort=()=>reject(t.error); }));
  return {collection:id=>tx('collections','readonly',x=>x.get(id)),saveCollection:(id,items)=>tx('collections','readwrite',x=>x.put({id,items})),put:o=>tx('files','readwrite',x=>x.put(o)),get:id=>tx('files','readonly',x=>x.get(id)),del:id=>tx('files','readwrite',x=>x.delete(id)),all:()=>tx('files','readonly',x=>x.getAll()),asset:()=>tx('assets','readonly',x=>x.get('font')),saveAsset:o=>tx('assets','readwrite',x=>x.put({...o,id:'font'})),removeAsset:()=>tx('assets','readwrite',x=>x.delete('font'))};
})();

/* ---------- Covers ---------- */
function coverHTML(t, cls = '') {
  const h = hash(t.artist + t.title) % 360;
  const bg = `linear-gradient(135deg,hsl(${h} 42% 52%),hsl(${(h+50)%360} 40% 38%))`;
  const letter = esc((t.title || '?').trim()[0]?.toUpperCase() || '♪︎');
  /* small rows get the 150 px artwork: 10× fewer pixels to download and decode on weak phones */
  const src = (t.artSm && (document.documentElement.dataset.perf==='low' || !/\b(xl|cv-lg|lg|md)\b/.test(cls))) ? t.artSm : t.art;
  const img = src ? `background-image:url('${esc(src)}'),${bg}` : `background:${bg}`;
  return `<div class="cover ${cls}" style="${img}">${t.art ? '' : letter}</div>`;
}
function setCover(el, t) {
  const key = (t.art || '') + '|' + t.title + '|' + t.artist;
  if (el.dataset.ck === key) { tint(t); return; } /* same cover: no restyle, no image re-decode */
  el.dataset.ck = key;
  const h = hash(t.artist + t.title) % 360;
  const bg = `linear-gradient(135deg,hsl(${h} 42% 52%),hsl(${(h+50)%360} 40% 38%))`;
  el.style.background = ''; el.style.backgroundImage = t.art ? `url('${t.art}'),${bg}` : bg;
  el.textContent = t.art ? '' : ((t.title||'♪︎').trim()[0]||'♪︎').toUpperCase();
  tint(t);
}
/* The whole app takes the colour of the cover: hash hue first, then the real dominant colour when the image allows it. */
const tintCache=new Map();let tintToken=0;
let lastTint='';function applyTint(h,sat){const k=Math.round(h)+'/'+Math.round(sat);if(k===lastTint)return;lastTint=k;const r=document.documentElement.style;r.setProperty('--hue',Math.round(h));r.setProperty('--sat',Math.round(sat)+'%');}
function tint(t){
  if(!t)return;const token=++tintToken;const fallback=hash((t.artist||'')+(t.title||''))%360;
  if(!t.art){applyTint(fallback,70);return}
  if(tintCache.has(t.art)){const c=tintCache.get(t.art);applyTint(c?c[0]:fallback,c?c[1]:70);return}
  applyTint(fallback,70);
  const img=new Image();img.crossOrigin='anonymous';img.decoding='async';
  img.onload=()=>{try{const c=document.createElement('canvas');c.width=c.height=24;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(img,0,0,24,24);const d=x.getImageData(0,0,24,24).data;const bins=new Array(36).fill(0),sats=new Array(36).fill(0),cnt=new Array(36).fill(0);
    for(let i=0;i<d.length;i+=4){const r=d[i]/255,g=d[i+1]/255,b=d[i+2]/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2,dl=mx-mn;if(dl<.08||l<.12||l>.92)continue;const sa=dl/(1-Math.abs(2*l-1));let hh=mx===r?((g-b)/dl)%6:mx===g?(b-r)/dl+2:(r-g)/dl+4;hh=(hh*60+360)%360;const k=Math.floor(hh/10)%36;bins[k]+=sa*sa;sats[k]+=sa;cnt[k]++}
    const k=bins.indexOf(Math.max(...bins));const best=bins[k]>0.4?[k*10+5,Math.min(90,Math.max(45,sats[k]/cnt[k]*100))]:null;
    tintCache.set(t.art,best);if(token===tintToken)applyTint(best?best[0]:fallback,best?best[1]:70)}catch{tintCache.set(t.art,null)}};
  img.onerror=()=>tintCache.set(t.art,null);img.src=t.art;
}

/* ---------- Player state ---------- */
const audio = new Audio(); audio.preload = 'auto';
const S = { queue: [], idx: -1, shuffle: store.get('shuffle', false), repeat: store.get('repeat', 'off'),
  favs: store.get('favs', []), recent: store.get('recent', []), objUrl: null, sleep: 0, sleepTimer: null };
const isRemovedEntry=t=>!t||['deezer','itunes','musicbrainz'].includes(t.type)||t.isPreview===true;
const isFullAudio=t=>!isRemovedEntry(t)&&(t.type==='local'||(t.type==='jade'&&t.fullStream===true&&/^https:\/\//i.test(t.src||''))||(['hitmoz','jamendo','audius','archive','commons','ccmixter','radio','soundcloud','cloud','phish','youtube'].includes(t.type)&&!!t.src));
const isUsableEntry=t=>isFullAudio(t)||(!isRemovedEntry(t)&&t.type==='album'&&!!t.ident);
for(const key of ['favs','recent']){const clean=S[key].filter(isUsableEntry);if(clean.length!==S[key].length){S[key]=clean;store.set(key,clean)}}
const cur = () => S.queue[S.idx];
const isFav = t => t && S.favs.some(f => f.id === t.id);
audio.volume = store.get('vol', 1);

async function playTrack(list, i) {
  const chosen=list[i];if(!isFullAudio(chosen)){toast('Доступны только полные аудиофайлы и радио');return;}S.queue=list.filter(isFullAudio);S.idx=S.queue.findIndex(t=>t.id===chosen.id);await load(); }
async function load() {
  const t = cur(); if (!t) return;
  if (!isFullAudio(t)) { audio.pause();toast('Этот источник отключён: доступны только полные аудиофайлы');return; }
  if (S.objUrl) { URL.revokeObjectURL(S.objUrl); S.objUrl = null; }
  let src = t.src;
  if (t.type === 'local') {
    const rec = await DB.get(t.id); if (!rec) { toast('Файл не найден'); return; }
    src = S.objUrl = URL.createObjectURL(rec.blob);
  }
  audio.src = src;
  audio.play().catch(e => { if (e.name !== 'AbortError') toast('Не удалось воспроизвести. Попробуйте другой трек.'); });
  S.recent = [t, ...S.recent.filter(r => r.id !== t.id)].slice(0, 12); store.set('recent', S.recent);
  updateUI(); updateMediaSession(); renderRecent(); if(typeof playerContextChanged==='function')playerContextChanged();
}
function toggle() { if (!cur()) return; audio.paused ? audio.play() : audio.pause(); }
function next(auto = false) {
  if (!S.queue.length) return;
  if (auto && S.repeat === 'one') { audio.currentTime = 0; audio.play(); return; }
  if (S.shuffle && S.queue.length > 1) { let n = S.nextIdx; if (n == null || n === S.idx || n >= S.queue.length) do n = Math.floor(Math.random()*S.queue.length); while (n === S.idx); S.nextIdx = null; S.idx = n; }
  else if (S.idx < S.queue.length - 1) S.idx++;
  else if (S.repeat === 'all' || !auto) S.idx = 0;
  else { audio.pause(); return; }
  load();
}
function prev() { if (audio.currentTime > 3 || cur()?.type === 'radio') { audio.currentTime = 0; return; } S.idx = (S.idx - 1 + S.queue.length) % S.queue.length; load(); }
function toggleFav(t) {
  if (!isUsableEntry(t)) return;
  if (isFav(t)) { S.favs = S.favs.filter(f => f.id !== t.id); toast('Удалено из избранного'); }
  else { S.favs.unshift(t); toast('Добавлено в избранное ♥︎'); }
  if(typeof cloudFavoriteChanged==='function')cloudFavoriteChanged(t,isFav(t));
  store.set('favs', S.favs); DB.saveCollection('favorites',S.favs).catch(()=>toast('Не удалось записать избранное в БД')); updateUI(); if (['favs','albums'].includes(libTab)) renderLib();
}

audio.addEventListener('play', updateUI); audio.addEventListener('pause', updateUI);
audio.addEventListener('ended', () => next(true));
audio.addEventListener('error', () => { audio.pause(); });
audio.addEventListener('timeupdate', () => {
  const d = audio.duration, c = audio.currentTime, live = !isFinite(d);
  const p = live ? 100 : (c / d * 100 || 0);
  const mp = $('#miniProg'), sx = 'scaleX(' + (p / 100).toFixed(4) + ')'; if (mp.style.transform !== sx) mp.style.transform = sx;
  /* the big player's seek bar and clock only update while it is open (no hidden layout work) */
  if (document.body.classList.contains('full-open')) {
    if (!seeking) { const v = live ? 1000 : Math.round(p * 10); if (+$('#seek').value !== v) { $('#seek').value = v; $('#seek').style.setProperty('--p', p + '%'); } }
    const tc = fmt(c), td = live ? 'LIVE' : fmt(d); if ($('#tCur').textContent !== tc) $('#tCur').textContent = tc; if ($('#tDur').textContent !== td) $('#tDur').textContent = td;
  }
  if ('setPositionState' in (navigator.mediaSession||{}) && !live && d) try { navigator.mediaSession.setPositionState({ duration: d, position: c, playbackRate: 1 }); } catch {}
});
let seeking = false;
$('#seek').addEventListener('input', e => { seeking = true; e.target.style.setProperty('--p', e.target.value/10 + '%'); });
$('#seek').addEventListener('change', e => { seeking = false; if (isFinite(audio.duration)) audio.currentTime = e.target.value / 1000 * audio.duration; });
$('#vol').value = audio.volume * 100; $('#vol').style.setProperty('--p', audio.volume*100 + '%');
$('#vol').addEventListener('input', e => { audio.volume = e.target.value/100; e.target.style.setProperty('--p', e.target.value + '%'); store.set('vol', audio.volume); });

function updateUI() {
  const t = cur(); const playing = !audio.paused;
  document.body.classList.toggle('paused-all', !playing);document.body.classList.toggle('is-playing', playing && !!t);
  $('#mini').classList.toggle('hidden', !t);
  const ic = `<svg><use href="#i-${playing ? 'pause' : 'play'}"/></svg>`;
  $('#miniPlay').innerHTML = ic; $('#playBtn').innerHTML = ic;
  $('#full').classList.toggle('paused', !playing);
  if (t) {
    $('#miniTitle').textContent = $('#fullTitle').textContent = t.title;
    $('#miniArtist').textContent = $('#fullArtist').textContent = t.artist || '';
    setCover($('#miniCover'), t); setCover($('#fullCover'), t);
    const artEl=$('#fullArt'),artKey=t.art||'';if(artEl.dataset.art!==artKey){artEl.dataset.art=artKey;artEl.style.backgroundImage=t.art?`url('${t.art.replace(/'/g,"%27")}')`:'none';}
    const sourceLink=$('#fullSourceLink');sourceLink.hidden=false;sourceLink.textContent='О треке и исполнителе';
    const f = isFav(t), h = `<svg><use href="#i-heart${f ? '-f' : ''}"/></svg>`;
    $('#miniFav').innerHTML = $('#fullFav').innerHTML = h;
    $('#miniFav').classList.toggle('fav', f); $('#fullFav').classList.toggle('fav', f);
    document.title = (playing ? '▶︎ ' : '') + t.title + ' — Lazzy sound';
  }
  $('#shuffleBtn').classList.toggle('on', S.shuffle);
  $('#repeatBtn').classList.toggle('on', S.repeat !== 'off'); $('#repeatBtn').classList.toggle('one', S.repeat === 'one');
  $$('.item').forEach(el => el.classList.toggle('playing', !!t && el.dataset.id === t.id));
}
function updateMediaSession() {
  if (!('mediaSession' in navigator)) return; const t = cur();
  navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist || '', album: 'Lazzy sound',
    artwork: t.art ? [{ src: t.art, sizes: '512x512' }] : [{ src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' }] });
  const ms = navigator.mediaSession;
  ms.setActionHandler('play', () => audio.play()); ms.setActionHandler('pause', () => audio.pause());
  ms.setActionHandler('nexttrack', () => next()); ms.setActionHandler('previoustrack', prev);
  try { ms.setActionHandler('seekto', d => { audio.currentTime = d.seekTime; }); } catch {}
}

/* ---------- Controls ---------- */
$('#miniPlay').onclick = e => { e.stopPropagation(); toggle(); };
$('#miniFav').onclick = e => { e.stopPropagation(); toggleFav(cur()); };
$('#mini').onclick = () => $('#full').classList.add('open');
$('#fullClose').onclick = () => $('#full').classList.remove('open');
$('#playBtn').onclick = toggle; $('#nextBtn').onclick = () => next(); $('#prevBtn').onclick = prev;
$('#fullFav').onclick = () => toggleFav(cur());
$('#shuffleBtn').onclick = () => { S.shuffle = !S.shuffle; store.set('shuffle', S.shuffle); updateUI(); toast(S.shuffle ? 'Перемешивание вкл.' : 'Перемешивание выкл.'); };
$('#repeatBtn').onclick = () => { S.repeat = { off: 'all', all: 'one', one: 'off' }[S.repeat]; store.set('repeat', S.repeat); updateUI();
  toast({ off: 'Повтор выкл.', all: 'Повтор очереди', one: 'Повтор трека' }[S.repeat]); };
$('#sleepBtn').onclick = () => {
  const opts = [0, 15, 30, 60, 90]; S.sleep = opts[(opts.indexOf(S.sleep) + 1) % opts.length];
  clearTimeout(S.sleepTimer);
  if (S.sleep) { S.sleepTimer = setTimeout(() => { audio.pause(); S.sleep = 0; $('#sleepLbl').textContent = 'Таймер сна'; $('#sleepBtn').classList.remove('on'); }, S.sleep * 60000); }
  $('#sleepLbl').textContent = S.sleep ? S.sleep + ' мин' : 'Таймер сна'; $('#sleepBtn').classList.toggle('on', !!S.sleep);
};
$('#queueBtn').onclick = () => openSheet({ title: 'Очередь', sub: S.queue.length + ' треков', tracks: S.queue, cover: cur() || {} });
document.addEventListener('keydown', e => { if (e.target.tagName === 'INPUT') return;
  if (e.code === 'Space') { e.preventDefault(); toggle(); } if (e.code === 'ArrowRight') next(); if (e.code === 'ArrowLeft') prev(); });
/* ---------- Lists ---------- */
function trackRow(t, opts = {}) {
  return `<div class="item" data-id="${esc(t.id)}"><div class="cover-wrap">${coverHTML(t)}<span class="eq" aria-hidden="true"><i></i><i></i><i></i></span></div>
    <div class="meta"><b>${esc(t.title)}</b><span>${esc(t.artist || '')}${t.meta ? ' · ' + esc(t.meta) : ''}</span></div>
    <button class="ibtn track-menu" data-info aria-label="О треке и действия"><svg><use href="#i-more"/></svg></button>
    ${opts.del ? `<button class="ibtn" data-del="${esc(t.id)}" aria-label="Удалить файл"><svg><use href="#i-trash"/></svg></button>` : `<button class="ibtn ${isFav(t) ? 'fav' : ''}" data-fav aria-label="Избранное"><svg><use href="#i-heart${isFav(t) ? '-f' : ''}"/></svg></button>`}</div>`;
}
function renderList(el, tracks, opts = {}) {
  tracks=tracks.filter(isUsableEntry).filter(t=>t.type!=='radio'||typeof RadioPrefs==='undefined'||!RadioPrefs.blocked.includes(t.id));
  if (!tracks.length) { el.innerHTML = `<div class="empty">${opts.empty || 'Пусто'}</div>`; return; }
  el.innerHTML = tracks.map(t => trackRow(t, opts)).join('');
  el.onclick = async e => {
    const row = e.target.closest('.item'); if (!row) return;
    const i = tracks.findIndex(t => t.id === row.dataset.id); const t = tracks[i];
    if (e.target.closest('[data-info]')) {e.preventDefault();e.stopPropagation();openTrackInfo(t);return;}
    if (e.target.closest('[data-fav]')) { toggleFav(t); const b = e.target.closest('[data-fav]'); b.classList.toggle('fav', isFav(t)); b.innerHTML = `<svg><use href="#i-heart${isFav(t)?'-f':''}"/></svg>`; return; }
    if (e.target.closest('[data-del]')) { await DB.del(t.id); toast('Удалено'); renderLib(); return; }
    if (opts.onOpen) return opts.onOpen(t);
    if (t.type === 'album') return openAlbum(t);
    if (!isFullAudio(t)) { toast('Аудиофайл недоступен');return; }
    playTrack(tracks.filter(isFullAudio), tracks.filter(isFullAudio).findIndex(x => x.id === t.id));
  };
  updateUI();
}
const loading = el => el.innerHTML = '<div class="loader"><i></i><i></i><i></i></div>';

/* ---------- Sheet ---------- */
function openSheet({ title, sub, tracks, cover }) {
  $('#sheet').dataset.mode='list';
  $('#sheetTitle').textContent = title; $('#sheetSub').textContent = sub || '';
  setCover($('#sheetCover'), cover); if (cur()) tint(cur());
  $('#sheetActions').innerHTML = tracks?.length ? `<button class="btn-accent" id="sheetPlay"><svg><use href="#i-play"/></svg>Слушать всё</button>` : '';
  if (tracks) renderList($('#sheetList'), tracks); else loading($('#sheetList'));
  const sp = $('#sheetPlay'); if (sp) sp.onclick = () => { playTrack(tracks, 0); closeSheet(); };
  $('#sheet').classList.add('open'); $('#sheetBack').classList.add('open');
}
const closeSheet = () => { $('#sheet').dataset.mode='closed'; $('#sheet').classList.remove('open'); $('#sheetBack').classList.remove('open'); };
$('#sheetBack').onclick = closeSheet;
/* PC: scrolling the wheel over the dimmed area beside the sheet must not scroll the page behind it */
$('#sheetBack').addEventListener('wheel', e => e.preventDefault(), { passive: false });

/* ---------- Internet Archive: licensed full files and album browsing ---------- */
const archiveMetadataCache=new Map();
async function getArchiveTracks(album){
  if(archiveMetadataCache.has(album.ident))return archiveMetadataCache.get(album.ident);
  const r=await fetch(`https://archive.org/metadata/${encodeURIComponent(album.ident)}`);if(!r.ok)throw new Error('Archive');const j=await r.json();
  const licenses=[j.metadata?.licenseurl].flat().filter(Boolean).map(String);
  if(!licenses.some(x=>/^https?:\/\/(www\.)?creativecommons\.org\//i.test(x)||/^https?:\/\/(www\.)?publicdomain\./i.test(x)))throw new Error('license');
  const files=(j.files||[]).filter(f=>!/(^|[_. -])(preview|sample|snippet|excerpt)([_. -]|$)/i.test(f.name||''));
  let audioFiles=files.filter(f=>/VBR MP3/i.test(f.format));if(!audioFiles.length)audioFiles=files.filter(f=>/MP3/i.test(f.format));if(!audioFiles.length)audioFiles=files.filter(f=>/Ogg Vorbis|Opus|FLAC/i.test(f.format));
  const image=(j.files||[]).find(f=>f.source==='original'&&/JPEG|PNG/i.test(f.format||'')&&!/waveform|spectrogram|spectra/i.test(f.name||''));
  const art=image?`https://archive.org/download/${encodeURIComponent(album.ident)}/${encodeURIComponent(image.name)}`:'';
  const tracks=audioFiles.sort((a,b)=>(parseInt(a.track)||0)-(parseInt(b.track)||0)||a.name.localeCompare(b.name)).map(f=>({id:`ia:${album.ident}/${f.name}`,title:f.title||f.name.replace(/\.[^.]+$/,'').replace(/_/g,' '),artist:f.creator||f.artist||album.artist,art,type:'archive',src:`https://archive.org/download/${encodeURIComponent(album.ident)}/${encodeURIComponent(f.name).replace(/%2F/g,'/')}`,meta:f.length?fmt(+f.length||0):'',sourceUrl:`https://archive.org/details/${encodeURIComponent(album.ident)}`,license:licenses[0]}));
  archiveMetadataCache.set(album.ident,tracks);if(archiveMetadataCache.size>30)archiveMetadataCache.delete(archiveMetadataCache.keys().next().value);return tracks;
}
async function searchArchive(q){
  const safe=q.replace(/[()[\]{}"\\]/g,' ').replace(/\s+/g,' ').trim();
  const query=`(${safe}) AND mediatype:(audio) AND (licenseurl:*creativecommons* OR licenseurl:*publicdomain*)`;
  const url=`https://archive.org/advancedsearch.php?q=${encodeURIComponent(query)}&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=year&sort[]=downloads+desc&rows=24&output=json`;
  const r=await fetch(url);if(!r.ok)throw new Error('Archive');const j=await r.json();
  const albums=(j.response?.docs||[]).map(d=>({id:'ia:'+d.identifier,ident:d.identifier,title:d.title||d.identifier,artist:Array.isArray(d.creator)?d.creator[0]:(d.creator||'Неизвестный'),meta:d.year?String(d.year).slice(0,4):'альбом',art:'',type:'album'}));
  // Unpack a bounded number of releases in parallel so full tracks are directly playable in search.
  const expanded=await Promise.all(albums.slice(0,4).map(a=>bounded(getArchiveTracks(a),6500).catch(()=>[])));
  const fullTracks=expanded.flat().slice(0,100);return [...fullTracks,...albums.slice(0,20)];
}
async function openAlbum(a){
  const token=Symbol();openAlbum.token=token;openSheet({title:a.title,sub:a.artist,tracks:null,cover:a});
  try{const tracks=await getArchiveTracks(a);if(openAlbum.token!==token||!$('#sheet').classList.contains('open'))return;if(tracks[0])setCover($('#sheetCover'),tracks[0]);
    $('#sheetSub').textContent=`${a.artist} · ${tracks.length} треков`;$('#sheetActions').innerHTML=(tracks.length?`<button class="btn-accent" id="sheetPlay"><svg><use href="#i-play"/></svg>Слушать всё</button>`:'')+`<button class="chip" id="sheetAlbumFav"><svg><use href="#i-heart"/></svg>${isFav(a)?'Альбом сохранён':'Сохранить альбом'}</button>`;$('#sheetAlbumFav').onclick=()=>{toggleFav(a);$('#sheetAlbumFav').lastChild.textContent=isFav(a)?'Альбом сохранён':'Сохранить альбом'};
    if($('#sheetPlay'))$('#sheetPlay').onclick=()=>{playTrack(tracks,0);closeSheet()};renderList($('#sheetList'),tracks,{empty:'В этом релизе нет доступных полных аудиофайлов'});
  }catch{if(openAlbum.token===token)$('#sheetList').innerHTML='<div class="empty">Не удалось получить полные файлы с подтверждённой лицензией. Попробуй другой релиз.</div>'}
}

/* ---------- Audius: official public, ungated full streams; no preview endpoint ---------- */
const audiusPending=new Map();
window.__lumenAudiusResult=(id,payload)=>{const p=audiusPending.get(id);if(!p)return;audiusPending.delete(id);clearTimeout(p.timer);try{const j=JSON.parse(payload);if(j.error)throw new Error('Audius временно недоступен');p.resolve(j)}catch(e){p.reject(e)}};
async function audiusRequest(query){
  if(window.LumenNative?.searchAudius)return new Promise((resolve,reject)=>{const id='au-'+Date.now()+'-'+Math.random().toString(36).slice(2);const timer=setTimeout(()=>{audiusPending.delete(id);reject(new Error('Audius не ответил'))},18000);audiusPending.set(id,{resolve,reject,timer});LumenNative.searchAudius(query,id)});
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
  try{const r=await fetch('https://api.audius.co/v1/tracks/search?limit=40&app_name=Lumen&query='+encodeURIComponent(query),{signal:controller.signal});if(!r.ok)throw new Error('Audius HTTP '+r.status);return await r.json()}finally{clearTimeout(timer)}
}
function mapAudiusTracks(j){
  return (Array.isArray(j.data)?j.data:[]).filter(t=>/^[a-zA-Z0-9]+$/.test(t.id||'')&&t.is_streamable===true&&t.is_stream_gated===false&&!t.stream_conditions&&t.is_available!==false&&!t.is_delete&&!t.is_unlisted&&t.access?.stream!==false&&t.isPreview!==true&&!/(^|\W)(preview|snippet|teaser)(\W|$)/i.test(t.title||'')).map(t=>({
    id:'audius:'+t.id,remoteId:t.id,type:'audius',title:t.title||'Без названия',artist:t.user?.name||t.user?.handle||'Артист Audius',duration:t.duration||0,meta:fmt(t.duration||0)+(t.play_count?' · ▶︎ '+compactNum(t.play_count):''),
    artistId:/^[a-zA-Z0-9]+$/.test(t.user?.id||'')?t.user.id:'',handle:t.user?.handle||'',artistArt:(t.user?.profile_picture?.['150x150']||'').startsWith('https://')?t.user.profile_picture['150x150']:'',plays:t.play_count||0,likes:t.favorite_count||0,reposts:t.repost_count||0,genre:t.genre||'',
    src:'https://api.audius.co/v1/tracks/'+encodeURIComponent(t.id)+'/stream?app_name=Lumen',
    art:(t.artwork?.['480x480']||t.artwork?.['150x150']||'').startsWith('https://')?(t.artwork['480x480']||t.artwork['150x150']):'',
    artSm:(t.artwork?.['150x150']||'').startsWith('https://')?t.artwork['150x150']:'',
    sourceUrl:t.permalink?.startsWith('/')?'https://audius.co'+t.permalink:'https://audius.co',fullStream:true
  }));
}
async function searchAudius(query){return mapAudiusTracks(await audiusRequest(query))}
function compactNum(n){n=+n||0;return n>=1e6?(n/1e6).toFixed(n>=1e7?0:1).replace('.0','')+'M':n>=1e3?(n/1e3).toFixed(n>=1e4?0:1).replace('.0','')+'K':String(n)}

/* ---------- Wikimedia Commons (freely licensed audio) ---------- */
const htmlText = value => {
  const node = document.createElement('div'); node.innerHTML = value || '';
  return (node.textContent || '').replace(/\s+/g, ' ').trim();
};
async function searchCommons(q) {
  const params = new URLSearchParams({
    action: 'query', generator: 'search', gsrsearch: `filetype:audio ${q}`,
    gsrnamespace: '6', gsrlimit: '100', prop: 'imageinfo',
    iiprop: 'url|mime|extmetadata',
    iiextmetadatafilter: 'Artist|LicenseShortName|LicenseUrl|UsageTerms|Credit|AttributionRequired',
    format: 'json', origin: '*'
  });
  const r = await fetch(`https://commons.wikimedia.org/w/api.php?${params}`);
  if (!r.ok) throw new Error('Wikimedia Commons');
  const j = await r.json();
  return Object.values(j.query?.pages || {}).flatMap(page => {
    const info = page.imageinfo?.[0], meta = info?.extmetadata || {};
    const url = info?.url || '', mime = info?.mime || '';
    if (!url || !/^(audio\/|application\/ogg)/i.test(mime) || /midi/i.test(mime)) return [];
    const license = htmlText(meta.LicenseShortName?.value || meta.UsageTerms?.value);
    if (!license) return [];
    const name = page.title.replace(/^File:/i, '').replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ');
    const artist = htmlText(meta.Artist?.value || meta.Credit?.value) || 'Автор не указан';
    return [{
      id: 'commons:' + page.pageid, title: name, artist,
      meta: license, src: url, sourceUrl: info.descriptionurl || `https://commons.wikimedia.org/wiki/${encodeURIComponent(page.title.replace(/ /g, '_'))}`,
      art: '', type: 'commons'
    }];
  });
}

/* ---------- ccMixter (CC-licensed music; Android native API bridge) ---------- */
const ccMixterPending = new Map();
let ccMixterSeq = 0;
window.__lumenCcMixterResult = (requestId, payload) => {
  const pending = ccMixterPending.get(requestId);
  if (!pending) return;
  clearTimeout(pending.timer);
  ccMixterPending.delete(requestId);
  try {
    const data = JSON.parse(payload);
    if (data?.error) throw new Error(data.error);
    pending.resolve(data);
  } catch (error) { pending.reject(error); }
};
function searchCcMixter(q) {
  if (!window.LumenNative?.searchCcMixter)
    return Promise.reject(new Error('Каталог ccMixter доступен в установленном APK.'));
  const requestId = `cc-${Date.now()}-${++ccMixterSeq}`;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      ccMixterPending.delete(requestId);
      reject(new Error('ccMixter долго не отвечает. Попробуйте ещё раз.'));
    }, 30000);
    ccMixterPending.set(requestId, { resolve, reject, timer });
    window.LumenNative.searchCcMixter(q, requestId);
  });
}


$$('[data-query]').forEach(b => b.onclick = () => { $('#q').value = b.dataset.query; doSearch(); });

/* ---------- Radio Browser (30 000+ stations) ---------- */
const RadioPrefs={blocked:store.get('radioBlocked',[])};
const RB = ['https://de1.api.radio-browser.info', 'https://fi1.api.radio-browser.info', 'https://de2.api.radio-browser.info'];
async function rb(path) {
  for (const h of RB) { try { const r = await fetch(h + path); if (r.ok) return await r.json(); } catch {} }
  throw new Error('radio');
}
const stationToTrack = s => ({ id: 'rb:' + s.stationuuid, title: s.name.trim(), artist: [s.country, (s.tags||'').split(',').slice(0,2).join(', ')].filter(Boolean).join(' · '),
  tags:s.tags||'',country:s.country||'',homepage:s.homepage||'',src: s.url_resolved, art: s.favicon && s.favicon.startsWith('https') ? s.favicon : '', type: 'radio', meta: s.bitrate ? s.bitrate + ' kbps' : '' });
async function searchRadio({ name = '', tag = '' } = {}) {
  const p = new URLSearchParams({ limit: 60, hidebroken: 'true', order: 'clickcount', reverse: 'true', is_https: 'true' });
  if (name) p.set('name', name); if (tag) { p.set('tag', tag); p.set('tagExact', 'false'); }
  const list = await rb('/json/stations/search?' + p);
  const seen = new Set(); return list.filter(s=>isMusicStation(s)&&!RadioPrefs.blocked.includes('rb:'+s.stationuuid)&&s.url_resolved?.startsWith('https')&&!seen.has(s.name.trim())&&seen.add(s.name.trim())).map(stationToTrack);
}

/* ---------- Views ---------- */
let view = 'home';
function go(v) {
  view = v; $$('.view').forEach(s => s.classList.toggle('active', s.dataset.view === v));
  $$('.tabbar button').forEach(b => b.classList.toggle('on', b.dataset.go === v));
  window.scrollTo({ top: 0 });
  if (v === 'radio' && !$('#radioList').children.length) loadRadioTag(RADIO_TAGS[0]);
  if (v === 'library') renderLib();
  if (v === 'profile') refreshProfile();
  if (v === 'search') setTimeout(() => $('#q').focus(), 50);
}
$$('[data-go]').forEach(b => b.addEventListener('click', () => { if (b.dataset.lib) libTab = b.dataset.lib; go(b.dataset.go); }));

// Home
const h = new Date().getHours();
$('#greet').textContent = h < 5 ? 'Доброй ночи' : h < 12 ? 'Доброе утро' : h < 18 ? 'Добрый день' : 'Добрый вечер';const greetBase=$('#greet').textContent;
function renderRecent() { renderList($('#recentList'), S.recent.slice(0, 6), { empty: '<svg><use href="#i-note"/></svg><b>Здесь появится история</b><span>Найди первый трек или добавь музыку с телефона.</span>' }); renderHero(); }
function renderHero(){
  const el=$('#homeHero');if(!el)return;const t=cur()||S.recent.find(isFullAudio);
  if($('#recentCount'))$('#recentCount').textContent=S.recent.length?Math.min(6,S.recent.length)+' '+(S.recent.length===1?'трек':S.recent.length<5?'трека':'треков'):'';
  if(!t){el.innerHTML='';return}
  const now=cur()&&cur().id===t.id,playing=now&&!audio.paused;const stack=[t,...S.recent.filter(x=>x.id!==t.id)].slice(0,3);
  el.innerHTML=`<div class="continue" role="button" tabindex="0" data-hero="open"><span class="stack">${stack.map(x=>coverHTML(x,'xs')).join('')}</span><span class="continue-copy"><small>${now?(playing?'Сейчас играет':'На паузе'):'Продолжить'}</small><b>${esc(t.title)}</b></span><button class="continue-play" data-hero="play" aria-label="${playing?'Пауза':'Играть'}"><svg><use href="#i-${playing?'pause':'play'}"/></svg></button></div>`;
  el.onclick=e=>{const a=e.target.closest('[data-hero]')?.dataset.hero;if(!a)return;const list=S.recent.filter(isFullAudio),i=list.findIndex(x=>x.id===t.id);
    if(a==='play'){e.stopPropagation();if(cur()?.id===t.id)toggle();else playTrack(list,i);return}
    if(cur()?.id!==t.id)playTrack(list,i);$('#full').classList.add('open');};
}
audio.addEventListener('play',()=>renderHero());audio.addEventListener('pause',()=>renderHero());
const MOODS = [
  ['Лоу-фай для учёбы', 'lofi', 200, 'Lo-fi'], ['Джаз вечером', 'jazz', 30, 'Jazz'], ['Классика', 'classical', 260, 'Classical'], ['Электроника', 'electronic', 190, 'Electronic'],
  ['Чилл и эмбиент', 'ambient', 170, 'Ambient'], ['Рок', 'rock', 5, 'Rock'], ['Хип-хоп', 'hip hop', 320, 'Hip-hop'], ['Синтвейв', 'synthwave', 290, 'Synthwave']];
$('#moods').innerHTML = MOODS.map(([n,,hue,tag], i) => `<button class="mood mood-${i}" style="--mh:${hue}"><span class="mood-art" aria-hidden="true"><i></i><em>${tag}</em></span><span class="mood-meta"><b>${n}</b><small>Треки и радио</small></span></button>`).join('');
$$('#moods .mood').forEach((b, i) => b.onclick = () => { $('#q').value = MOODS[i][1]; go('search'); doSearch(); });

// Unified search: all connected sources, progressive results, no provider tabs.
let st, searchFilter='all', mergedResults=[], searchGeneration=0;
const PROVIDER_LABELS={cloud:'Lazzy',soundcloud:'SoundCloud',hitmoz:'Hitmoz',jamendo:'Jamendo',jade:'Твой API',audius:'Audius',archive:'Archive',commons:'Commons',ccmixter:'ccMixter',radio:'Радио',local:'Мои файлы'};
const searchCache=new Map();
const groupOf=t=>t.type==='radio'?'radio':t.type==='album'?'catalog':'audio';
const normalize=s=>String(s||'').toLocaleLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
function mergeSearchResults(items,query){
  const groups=new Map(); const q=normalize(query),words=q.split(' ').filter(Boolean);
  const quality=t=>t.type==='local'?8:['hitmoz','jamendo','jade','audius','commons','ccmixter','archive'].includes(t.type)&&t.src?7:t.src&&t.type!=='radio'?6:t.type==='radio'?2:t.type==='album'?1:0;
  for(const raw of items.filter(isUsableEntry)){
    const t={...raw};const kind=groupOf(t);const key=kind==='radio'?t.id:kind==='catalog'?t.id:normalize(t.artist)+'|'+normalize(t.title);
    const label=PROVIDER_LABELS[t.type==='album'?'archive':t.type]||t.type;
    const old=groups.get(key);
    if(!old){t.providers=[label];groups.set(key,t);}else{const providers=[...new Set([...old.providers,label])];if(quality(t)>quality(old))groups.set(key,{...t,providers});else old.providers=providers;}
  }
  return [...groups.values()].map(t=>{const title=normalize(t.title),artist=normalize(t.artist);return {...t,_rank:(title===q?100:0)+(artist===q?50:0)+words.filter(w=>title.includes(w)).length*8+words.filter(w=>artist.includes(w)).length*6+quality(t)};}).sort((a,b)=>b._rank-a._rank||a.title.localeCompare(b.title));
}
function renderMergedSearch(){
  const list=mergedResults.filter(t=>t.type!=='youtube'&&(searchFilter==='all'||groupOf(t)===searchFilter));if(typeof renderYtResults==='function')renderYtResults();
  renderList($('#searchList'),list,{empty:mergedResults.length?'В этой категории пока нет результатов. Попробуй «Всё».':'Ничего не найдено. Проверь запрос или попробуй другие слова.',onOpen:t=>{
    if(t.type==='album')return openAlbum(t);
    if(!isFullAudio(t))return;
    const queue=list.filter(isFullAudio);playTrack(queue,queue.findIndex(x=>x.id===t.id));
  }});
  $$('#resultFilters button').forEach(b=>{b.classList.toggle('on',b.dataset.filter===searchFilter);b.setAttribute('aria-pressed',b.dataset.filter===searchFilter?'true':'false');});
}
$$('#resultFilters button').forEach(b=>b.onclick=()=>{searchFilter=b.dataset.filter;renderMergedSearch()});
$('#q').addEventListener('input',()=>{clearTimeout(st);searchGeneration++;if(!$('#q').value.trim())clearSearch();else st=setTimeout(()=>doSearch({auto:true}),800)});
$('#q').addEventListener('keydown',e=>{if(e.key==='Enter'){clearTimeout(st);doSearch();e.target.blur()}});
function clearSearch(){mergedResults=[];$('#searchList').innerHTML='';$('#searchSuggestions').hidden=false;$('#searchMore').hidden=true;$('#searchProgress').textContent='Полные файлы';$('#searchHint').textContent='Один запрос — полные аудиофайлы и твоя музыка.';}
const bounded=(promise,ms)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('timeout')),ms);Promise.resolve(promise).then(v=>{clearTimeout(timer);resolve(v)},e=>{clearTimeout(timer);reject(e)})});
async function cachedSearch(source,query,fn){const k=source+'|'+query.toLowerCase();const old=searchCache.get(k);if(old&&Date.now()-old.time<300000)return old.data;const data=await bounded(Promise.resolve().then(fn),14000);searchCache.set(k,{time:Date.now(),data});if(searchCache.size>60)searchCache.delete(searchCache.keys().next().value);return data;}
async function doSearch(){
  clearTimeout(st);const query=$('#q').value.trim(),token=++searchGeneration;
  $('#searchSuggestions').hidden=!!query;$('#searchMore').hidden=!query;
  if(!query){clearSearch();return;}if(query.length<2){mergedResults=[];$('#searchProgress').textContent='Введите запрос';$('#searchList').innerHTML='<div class="empty">Введи хотя бы два символа.</div>';return;}
  mergedResults=[];loading($('#searchList'));$('#searchProgress').textContent='Ищем…';$('#searchHint').textContent='Собираем результаты. Не нужно выбирать источник.';
  const jobs=[['albumCatalog',()=>searchAlbumCatalog(query)],['audius',()=>searchAudius(query)],['archive',()=>searchArchive(query)],['commons',()=>searchCommons(query)],['ccmixter',()=>searchCcMixter(query)],['radio',()=>searchRadio({name:query})],['local',async()=>{const q=normalize(query).split(' ').filter(Boolean);return (await DB.all()).filter(t=>q.every(w=>normalize(t.title+' '+t.artist).includes(w))).map(({blob,...t})=>t)}]];
  if(typeof Connections!=='undefined'&&Connections.jadeEndpoint){const endpoint=Connections.jadeEndpoint;jobs.unshift(['jade:'+endpoint,()=>searchJade(query,endpoint)])}
  if(typeof Connections!=='undefined'&&Connections.jamendoId){const clientId=Connections.jamendoId;jobs.unshift(['jamendo:'+clientId,()=>searchJamendo(query,clientId)])}
  if(typeof Connections!=='undefined'&&Connections.hitmozEnabled)jobs.unshift(['hitmoz',()=>searchHitmoz(query)]);
  let done=0,failed=0;const gathered=[];
  await Promise.all(jobs.map(async([source,fn])=>{
    try{const data=source==='local'?await fn():await cachedSearch(source,query,fn);if(token!==searchGeneration)return;gathered.push(...data.slice(0,120));}
    catch(e){if(token!==searchGeneration)return;failed++;}
    if(token!==searchGeneration)return;done++;mergedResults=mergeSearchResults(gathered,query);renderMergedSearch();$('#searchProgress').textContent=done<jobs.length?`Поиск ${done}/${jobs.length} · ${mergedResults.length} найдено`:`Найдено: ${mergedResults.length}`;
    $('#searchHint').textContent=done<jobs.length?'Результаты дополняются. Уже можно выбирать музыку.':failed?`Поиск завершён. Источников без ответа: ${failed}. Доступные результаты показаны.`:'Поиск завершён. Повторы объединены; альбомы собраны из доступных каталогов.';
  }));
}
$('#soundcloudSearch').onclick=()=>{const q=$('#q').value.trim();if(q)window.open('https://soundcloud.com/search/sounds?q='+encodeURIComponent(q),'_blank','noopener')};

// Radio
const RADIO_TAGS = ['pop', 'rock', 'jazz', 'lofi', 'electronic', 'classical', 'chillout', 'hip hop', 'ambient', 'metal', 'soul', 'funk'];
$('#radioTags').innerHTML = RADIO_TAGS.map(t => `<button class="tag" data-tag="${t}">${t}</button>`).join('');
$$('#radioTags .tag').forEach(b => b.onclick = () => loadRadioTag(b.dataset.tag));
let radioGeneration=0;
async function loadRadioTag(tag) {const generation=++radioGeneration;
  $$('#radioTags .tag').forEach(b => b.classList.toggle('on', b.dataset.tag === tag));
  loading($('#radioList'));
  try {const tracks=await searchRadio({tag});if(generation!==radioGeneration)return;renderList($('#radioList'),tracks,{empty:'Музыкальных станций по этому жанру пока нет. Попробуй другой.'});}
  catch {if(generation===radioGeneration)$('#radioList').innerHTML='<div class="empty">Радиокаталог не ответил. Попробуй другой жанр или повтори позже.</div>';}
}

// Library
let libTab = 'files';
$$('#libSeg button').forEach(b => b.onclick = () => { libTab = b.dataset.lib; renderLib(); });
async function renderLib() {
  $$('#libSeg button').forEach(b => b.classList.toggle('on', b.dataset.lib === libTab));
  const el = $('#libList');
  if (libTab === 'favs'||libTab==='albums') {$('#libActions').innerHTML='';return renderList(el,S.favs.filter(t=>libTab==='albums'?t.type==='album':t.type!=='album'),{empty:libTab==='albums'?'Найди альбом и нажми ♥︎ на его странице.':'Нажми ♥︎ у трека или станции. Избранное сохраняется на устройстве.'});}
  const files = (await DB.all()).sort((a, b) => b.added - a.added).map(({ blob, ...m }) => m);
  $('#libActions').innerHTML = files.length ? `<button class="chip" id="libPlayAll"><svg><use href="#i-play"/></svg>Слушать всё</button><button class="chip" id="libShuffle"><svg><use href="#i-shuffle"/></svg>Вперемешку</button>` : '';
  if (files.length) { $('#libPlayAll').onclick = () => { S.shuffle = false; playTrack(files, 0); };
    $('#libShuffle').onclick = () => { S.shuffle = true; store.set('shuffle', true); playTrack(files, Math.floor(Math.random() * files.length)); }; }
  renderList(el, files, { del: true, empty: 'Добавьте музыку с телефона или компьютера — MP3, FLAC, M4A, OGG, WAV.<br>Файлы сохранятся в приложении и будут играть без интернета.' });
}
$('#fileInput').addEventListener('change', async e => {
  const fs = [...e.target.files]; if (!fs.length) return; toast(`Добавляю ${fs.length}…`);
  for (const f of fs) {
    const base = f.name.replace(/\.[^.]+$/, '').replace(/_/g, ' ');
    const [artist, title] = base.includes(' - ') ? base.split(' - ').map(s => s.trim()) : ['Мой файл', base];
    await DB.put({ id: 'loc:' + f.name + ':' + f.size, title: title || base, artist, type: 'local', meta: (f.size / 1048576).toFixed(1) + ' МБ', added: Date.now(), blob: f });
  }
  e.target.value = ''; libTab = 'files'; renderLib(); toast(`Добавлено: ${fs.length}`);
});

/* ---------- PWA ---------- */
let deferred; window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; $('#installBtn').classList.remove('hidden'); });
$('#installBtn').onclick = async () => { if (!deferred) return; deferred.prompt(); await deferred.userChoice; deferred = null; $('#installBtn').classList.add('hidden'); };
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  /* In the app (Android/PC) files are local: an old service worker would keep serving the previous version's design. */
  if (window.LumenNative || location.host === 'appassets.androidplatform.net') {
    navigator.serviceWorker.getRegistrations().then(rs => { if (!rs.length) return; Promise.all(rs.map(r => r.unregister())).then(() => caches.keys()).then(ks => Promise.all(ks.map(k => caches.delete(k)))).then(() => { if (navigator.serviceWorker.controller && !sessionStorage.getItem('swGone')) { sessionStorage.setItem('swGone', '1'); location.reload(); } }); }).catch(() => {});
  } else navigator.serviceWorker.register('sw.js').catch(() => {});
}
if (navigator.storage?.persist) navigator.storage.persist();

renderRecent(); updateUI();
/* ---------- Local profile and device-only appearance ---------- */
const ACCENTS={tide:{label:'Прилив',color:'#46b7ff',c2:'#8bf3e6',c3:'#2e7dff',ink:'#1663c7'},auto:{label:'Из обложки',color:'',ink:''},ember:{label:'Закат',color:'#ff8a5c',c2:'#ffd27a',c3:'#ff4f7b',ink:'#b8431c'},violet:{label:'Аметист',color:'#a58bff',c2:'#e0b3ff',c3:'#6a5cff',ink:'#5b3fc4'},lime:{label:'Лайм',color:'#b8f36b',c2:'#eaff9e',c3:'#4fd18b',ink:'#3f7a12'},rose:{label:'Роза',color:'#ff7eb6',c2:'#ffc2dc',c3:'#d94dff',ink:'#a8306a'},mono:{label:'Графит',color:'#e9edf2',c2:'#ffffff',c3:'#9aa2ad',ink:'#3a4250'},red:{label:'Красный',color:'#fa2d48',c2:'#ff7a8a',c3:'#e0183a',ink:'#d70f3a'},green:{label:'Зелёный',color:'#1ed760',c2:'#7cf0a5',c3:'#14a84a',ink:'#118a3c'}};
const AVATARS=['headphones','disc','wave','spark','moon','bolt','note','cassette','mic','leaf','sun','star'];
const AVATAR_NAMES=['Наушники','Винил','Звуковая волна','Искра','Луна','Молния','Нота','Кассета','Микрофон','Лист','Солнце','Звезда'];
const defaults={name:'',theme:'dark',accent:'tide',font:'system',customFontName:'',avatar:'headphones',density:'comfortable',reduceMotion:false};
let Prefs={...defaults,...store.get('profile',{})},loadedFont=null;if(Prefs.v!==4){Prefs.accent='tide';Prefs.v=4;store.set('profile',Prefs)}
for(const [key,allowed] of Object.entries({theme:['dark','light','auto'],accent:Object.keys(ACCENTS),font:['system','serif','mono','custom'],avatar:AVATARS,density:['comfortable','compact']}))if(!allowed.includes(Prefs[key]))Prefs[key]=defaults[key];
Prefs.name=String(Prefs.name||'').slice(0,32);Prefs.customFontName=String(Prefs.customFontName||'').slice(0,120);
const systemTheme=window.matchMedia('(prefers-color-scheme: light)');
function applyAppearance(){
  const root=document.documentElement,theme=Prefs.theme==='auto'?(systemTheme.matches?'light':'dark'):Prefs.theme;
  const accent=ACCENTS[Prefs.accent];root.dataset.theme=theme;root.dataset.density=Prefs.density;root.dataset.motion=Prefs.reduceMotion?'reduce':'normal';
  root.dataset.accent=Prefs.accent;
  if(accent.color){root.style.setProperty('--accent',accent.color);root.style.setProperty('--accent-2',accent.c2);root.style.setProperty('--accent-3',accent.c3);root.style.setProperty('--accent-ink',theme==='light'?accent.ink:accent.color)}else{for(const k of ['--accent','--accent-2','--accent-3','--accent-ink'])root.style.removeProperty(k)}
  const families={system:'"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif',serif:'"Noto Serif",Georgia,serif',mono:'"Roboto Mono",Consolas,monospace',custom:'"LumenCustom",-apple-system,Roboto,Arial,sans-serif'};
  root.style.setProperty('--app-font',families[Prefs.font]);root.style.setProperty('--display-font',families[Prefs.font]);
  document.querySelector('meta[name="theme-color"]').content=theme==='light'?'#eef1f7':'#06070b';
  $('#headerAvatar')?.setAttribute('href','#i-'+Prefs.avatar);$('#profileAvatar').setAttribute('href','#i-'+Prefs.avatar);
  $('#profileDisplayName').textContent=Prefs.name.trim()||'Слушатель';if(typeof renderGreeting==='function')renderGreeting(false);else if(typeof greetBase!=='undefined')$('#greet').textContent=greetBase+(Prefs.name.trim()?', '+Prefs.name.trim():'');
  if(window.LumenNative?.setAppearance)window.LumenNative.setAppearance(theme==='light');
}
function saveProfile(){store.set('profile',Prefs);applyAppearance();syncProfileControls()}
function syncProfileControls(){
  $$('#themeChoices button').forEach(b=>{const on=b.dataset.themeChoice===Prefs.theme;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  $$('#accentChoices button').forEach(b=>{const on=b.dataset.accent===Prefs.accent;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  $$('#avatarChoices button').forEach(b=>{const on=b.dataset.avatar===Prefs.avatar;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  $$('#densityChoices button').forEach(b=>{const on=b.dataset.density===Prefs.density;b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on))});
  $('#fontChoice').value=Prefs.font;const custom=$('#fontChoice option[value="custom"]');custom.disabled=!Prefs.customFontName;custom.textContent=Prefs.customFontName?'Мой: '+Prefs.customFontName:'Мой шрифт';$('#customFontName').textContent=Prefs.customFontName||'Шрифт не загружен';$('#removeFont').hidden=!Prefs.customFontName;$('#reduceMotion').checked=!!Prefs.reduceMotion;
}
async function refreshProfile(){
  $('#profileName').value=Prefs.name;syncProfileControls();$('#profileFavCount').textContent=S.favs.length;$('#profileRecentCount').textContent=S.recent.length;
  try{$('#profileFileCount').textContent=(await DB.all()).length}catch{$('#profileFileCount').textContent='—'}
}
$('#accentChoices').innerHTML=Object.entries(ACCENTS).map(([k,a])=>`<button data-accent="${k}" style="--swatch:${a.color?`linear-gradient(135deg,${a.c2},${a.color},${a.c3})`:'transparent'}" aria-label="${a.label}" title="${a.label}"><svg><use href="#i-check"/></svg></button>`).join('');
$('#avatarChoices').innerHTML=AVATARS.map((a,i)=>`<button data-avatar="${a}" aria-label="${AVATAR_NAMES[i]}" title="${AVATAR_NAMES[i]}"><svg><use href="#i-${a}"/></svg></button>`).join('');
$('#profileName').addEventListener('input',e=>{Prefs.name=e.target.value.slice(0,32);saveProfile()});
$$('#themeChoices button').forEach(b=>b.onclick=()=>{Prefs.theme=b.dataset.themeChoice;saveProfile()});
$$('#accentChoices button').forEach(b=>b.onclick=()=>{Prefs.accent=b.dataset.accent;saveProfile()});
$$('#avatarChoices button').forEach(b=>b.onclick=()=>{Prefs.avatar=b.dataset.avatar;saveProfile()});
$$('#densityChoices button').forEach(b=>b.onclick=()=>{Prefs.density=b.dataset.density;saveProfile()});
$('#fontChoice').onchange=e=>{Prefs.font=e.target.value;saveProfile()};
$('#reduceMotion').onchange=e=>{Prefs.reduceMotion=e.target.checked;saveProfile()};
const themeChanged=()=>{if(Prefs.theme==='auto')applyAppearance()};
if(systemTheme.addEventListener)systemTheme.addEventListener('change',themeChanged);else systemTheme.addListener(themeChanged);
async function createCustomFont(bytes){return await new FontFace('LumenCustom',bytes).load()}
function activateCustomFont(font){if(loadedFont)document.fonts.delete(loadedFont);loadedFont=font;document.fonts.add(font)}
$('#fontInput').onchange=async e=>{
  const file=e.target.files?.[0];if(!file)return;e.target.value='';
  if(file.size>8*1024*1024||!file.size){toast('Выбери файл шрифта размером до 8 МБ');return}
  if(!/\.(ttf|otf|woff2?)$/i.test(file.name)){toast('Поддерживаются TTF, OTF, WOFF и WOFF2');return}
  try{const bytes=await file.arrayBuffer(),font=await createCustomFont(bytes);await DB.saveAsset({name:file.name,bytes});activateCustomFont(font);Prefs.customFontName=file.name;Prefs.font='custom';saveProfile();toast('Твой шрифт применён во всём приложении')}
  catch{toast('Не удалось загрузить шрифт. Проверь файл и свободное место.')}
};
$('#removeFont').onclick=async()=>{try{await DB.removeAsset();if(loadedFont)document.fonts.delete(loadedFont);loadedFont=null;Prefs.customFontName='';if(Prefs.font==='custom')Prefs.font='system';saveProfile();toast('Пользовательский шрифт удалён')}catch{toast('Не удалось удалить шрифт')}};
$('#resetAppearance').onclick=()=>{Prefs={...defaults,v:4,name:Prefs.name,avatar:Prefs.avatar,customFontName:Prefs.customFontName};saveProfile();toast('Оформление сброшено. Твоя музыка на месте.')};
applyAppearance();syncProfileControls();
DB.asset().then(async record=>{if(!record?.bytes){if(Prefs.font==='custom'){Prefs.font='system';Prefs.customFontName='';saveProfile()}return}const font=await createCustomFont(record.bytes);activateCustomFont(font);Prefs.customFontName=record.name;syncProfileControls();applyAppearance()}).catch(()=>{if(Prefs.font==='custom'){Prefs.font='system';applyAppearance();syncProfileControls();toast('Шрифт недоступен, выбран системный')}});
/* 6.0.6: mini progress ring follows the (hidden) progress line, whatever source updates it */
{const m=$('#mini'),p=$('#miniProg');if(m&&p){m.insertAdjacentHTML('afterbegin','<span class="mini-ring" aria-hidden="true"></span>');
  new MutationObserver(()=>{const v=/scaleX\(([\d.]+)\)/.exec(p.style.transform);m.style.setProperty('--mp',v?Math.min(1,+v[1]).toFixed(4):0)}).observe(p,{attributes:true,attributeFilter:['style']})}}
