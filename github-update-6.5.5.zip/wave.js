'use strict';
/* Lazzy sound 3.4 — «Моя волна»: an endless personal stream.
   Taste = artists and genres from likes (×3), playlists (×2) and history (×1).
   Each batch mixes three pools — familiar artists, artists related to them, and genre trends — in proportions set
   by the mode. The queue is topped up before it runs out, played and disliked tracks are skipped. */
const WAVE_MODES={ai:{label:'✦︎ ИИ',mix:[.1,.1,.2],ai:.6},fav:{label:'Любимое',mix:[.6,.2,.2]},mix:{label:'Микс',mix:[.35,.35,.3]},new:{label:'Новое',mix:[.1,.5,.4]},calm:{label:'Спокойное',mix:[.3,.3,.4],genres:['Lo-Fi','Ambient','Jazz','R&B/Soul','Classical']},drive:{label:'Бодрое',mix:[.3,.3,.4],genres:['Electronic','House','Drum & Bass','Techno','Trap','Dubstep']}};
const MyWave={on:false,busy:false,mode:WAVE_MODES[store.get('waveMode','mix')]?store.get('waveMode','mix'):'mix',
  played:store.get('wavePlayed',[]),ban:store.get('waveBan',{tracks:[],artists:{}}),
  tune:Object.assign({prompt:'',genres:[],ai:true},store.get('waveTune',{}))};
const shuffled=a=>{const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]]}return b};
const pick=(a,n)=>shuffled(a).slice(0,n);

function tasteProfile(){
  const artists=new Map(),genres=new Map();
  const add=(t,w)=>{if(!t||!t.artist||['radio','album','local'].includes(t.type))return;const k=normalize(t.artist);const o=artists.get(k)||{name:t.artist,id:'',n:0};o.n+=w;if(t.artistId)o.id=t.artistId;artists.set(k,o);if(t.genre)genres.set(t.genre,(genres.get(t.genre)||0)+w)};
  S.favs.forEach(t=>add(t,3));(typeof Library!=='undefined'?Library.playlists:[]).forEach(p=>p.tracks.forEach(t=>add(t,2)));S.recent.forEach(t=>add(t,1));
  for(const [k,v] of Object.entries(MyWave.ban.artists))if(v>=2)artists.delete(k);
  return{artists:[...artists.values()].sort((a,b)=>b.n-a.n),genres:[...genres.entries()].sort((a,b)=>b[1]-a[1]).map(g=>g[0])};
}
async function artistTracks(a){
  try{
    if(a.id){const j=await audiusApi(`/v1/users/${a.id}/tracks?limit=50`);return mapAudiusTracks(j)}
    return (await searchAudius(a.name)).filter(t=>similarity(a.name,t.artist)>.8);
  }catch{return []}
}
async function relatedTracks(a){
  try{
    if(!a.id){const hit=(await searchAudius(a.name)).find(t=>similarity(a.name,t.artist)>.8&&t.artistId);if(!hit)return [];a={...a,id:hit.artistId}}
    const j=await audiusApi(`/v1/users/${a.id}/related?limit=12`);const users=(j.data||[]).filter(u=>/^[a-zA-Z0-9]+$/.test(u.id||''));
    const lists=await Promise.all(pick(users,3).map(u=>audiusApi(`/v1/users/${u.id}/tracks?limit=20`).then(mapAudiusTracks).catch(()=>[])));
    return lists.flatMap(l=>[...l].sort((x,y)=>(y.plays||0)-(x.plays||0)).slice(0,6));
  }catch{return []}
}
/* ---------- AI curator: turns taste + your words into artists, search queries and genres ---------- */
let aiPlanCache=store.get('waveAiPlan',{key:'',t:0,plan:null}),aiPlanWarned=false;
async function aiPlan(prof){
  if(!MyWave.tune.ai||typeof aiAsk!=='function'||typeof aiReady!=='function'||!aiReady())return null;
  const top=prof.artists.slice(0,12).map(a=>a.name),mode=WAVE_MODES[MyWave.mode];
  const key=[MyWave.mode,MyWave.tune.prompt,MyWave.tune.genres.join(','),top.slice(0,6).join(',')].join('|');
  if(aiPlanCache.key===key&&aiPlanCache.plan&&Date.now()-aiPlanCache.t<6*3600e3)return aiPlanCache.plan;
  const system='Ты музыкальный куратор стримингового сервиса. Отвечай только JSON без пояснений.';
  const prompt=`Собери «Мою волну» — бесконечный поток музыки.
Слушатель часто играет: ${top.join(', ')||'пока ничего'}.
Режим: ${mode.label}. ${MyWave.tune.prompt?'Пожелание слушателя: «'+MyWave.tune.prompt+'».':''} ${MyWave.tune.genres.length?'Жанры, которые он выбрал: '+MyWave.tune.genres.join(', ')+'.':''}
Каталог — в основном независимые артисты Audius, поэтому кроме известных имён дай поисковые запросы.
Верни JSON: {"artists":[до 12 реальных артистов, похожих на вкус и пожелание],"queries":[до 8 коротких английских поисковых запросов: жанр, настроение, стиль],"genres":[до 3 из списка: ${AUDIUS_GENRES.map(g=>g[0]).join(', ')}]}`;
  try{
    const j=aiJSON(await aiAsk(system,prompt));
    const clean=(a,n)=>(Array.isArray(a)?a:[]).map(x=>String(x).trim()).filter(x=>x&&x.length<60).slice(0,n);
    const plan={artists:clean(j.artists,12),queries:clean(j.queries,8),genres:clean(j.genres,3)};
    if(!plan.artists.length&&!plan.queries.length)return null;
    aiPlanCache={key,t:Date.now(),plan};store.set('waveAiPlan',aiPlanCache);return plan;
  }catch(e){
    if(!aiPlanWarned){aiPlanWarned=true;toast(e.rateLimit?'ИИ занят — волна подбирается по твоей истории':'ИИ не ответил — волна подбирается по твоей истории')}
    return aiPlanCache.plan||null;
  }
}
/* 6.3.2: search every connected source (not only Audius) — never YouTube: the wave also plays in the background */
async function waveSearch(q){if(typeof sourceJobs!=='function')return searchAudius(q).catch(()=>[]);
  const jobs=sourceJobs(q,{withLocal:false,withCatalog:false,withRadio:false}).filter(([s])=>!/^youtube/.test(s));
  return (await Promise.all(jobs.map(([src,fn])=>bounded(cachedSearch(src,q,fn),12000).catch(()=>[])))).flat()}
/* the listener's own words come first: an artist name → that artist's tracks (saved ones too), anything else → a search */
async function wishTracks(prompt){
  const q=String(prompt||'').trim();if(!q)return [];const am=t=>(typeof artistSim==='function'?artistSim(q,t.artist||''):similarity(q,t.artist||''));
  const pls=typeof Library!=='undefined'?Library.playlists.flatMap(p=>p.tracks||[]):[];
  const saved=[...S.favs,...S.recent,...pls].filter(t=>t&&isFullAudio(t)&&t.type!=='youtube'&&(am(t)>.75||similarity(q,(t.artist||'')+' '+(t.title||''))>.6));
  const found=(await waveSearch(q).catch(()=>[])).filter(t=>isFullAudio(t)&&t.type!=='youtube');
  const byArtist=found.filter(t=>am(t)>.75),rest=found.filter(t=>am(t)<=.75);
  const list=byArtist.length+saved.length>=3?[...saved,...byArtist]:[...saved,...byArtist,...rest];
  return [...new Map(list.map(t=>[t.id,t])).values()]}
async function aiTracks(plan){
  if(!plan)return [];
  const byArtist=pick(plan.artists,4).map(name=>waveSearch(name).then(r=>r.filter(t=>similarity(name,t.artist)>.75).sort((a,b)=>(b.plays||0)-(a.plays||0)).slice(0,4)).catch(()=>[]));
  const byQuery=pick(plan.queries,3).map(q=>searchAudius(q).then(r=>r.slice(0,6)).catch(()=>[]));
  return (await Promise.all([...byArtist,...byQuery])).flat();
}
/* Genres the listener typed: Audius genre trends when the name matches, otherwise a search. */
function genreJobs(list){
  return list.map(g=>{const m=AUDIUS_GENRES.map(x=>x[0]).find(x=>similarity(x,g)>.75||normalize(x)===normalize(g));
    return m?audiusTrending(m,Math.random()<.5?'week':'month').catch(()=>[]):searchAudius(g).catch(()=>[])});
}

async function waveBatch(n=14){
  const mode=WAVE_MODES[MyWave.mode],prof=tasteProfile();
  const planP=aiPlan(prof);const wishP=MyWave.tune.prompt?wishTracks(MyWave.tune.prompt):Promise.resolve([]);
  const own=MyWave.tune.genres;
  const genres=own.length?pick(own,3):mode.genres?pick(mode.genres,3):(prof.genres.length?prof.genres.slice(0,3):pick(AUDIUS_GENRES.map(g=>g[0]),2));
  const top=prof.artists.slice(0,10);
  const famP=Promise.all(pick(top,3).map(artistTracks)).then(l=>l.flat());
  const relP=Promise.all(pick(top.filter(a=>a.n>=2).length?top.filter(a=>a.n>=2):top,2).map(relatedTracks)).then(l=>l.flat());
  const genP=Promise.all(genreJobs(genres)).then(l=>l.flat());
  // Don't make the listener wait for a slow AI: start with what we have, AI picks join the queue when ready.
  const quick=await Promise.race([planP,new Promise(r=>setTimeout(()=>r(undefined),3500))]);
  if(quick===undefined)planP.then(p=>{if(p)injectAi(p)});
  const aiP=Promise.resolve(quick||null).then(plan=>Promise.all([aiTracks(plan),plan?Promise.all(genreJobs(plan.genres.slice(0,2))).then(l=>l.flat()):[]])).then(([a,g])=>[...a,...g]);
  let [fam,rel,gen,ai,wish]=await Promise.all([famP,relP,genP,aiP,wishP].map(p=>bounded(p,45000).catch(()=>[])));
  if(!fam.length&&!rel.length&&!gen.length&&!ai.length&&!wish.length)gen=await audiusTrending('','week').catch(()=>[]);
  const known=new Set(prof.artists.map(a=>normalize(a.name)));
  if(MyWave.mode==='new'){rel=rel.filter(t=>!known.has(normalize(t.artist)));gen=gen.filter(t=>!known.has(normalize(t.artist)))}
  const played=new Set(MyWave.played),banned=new Set(MyWave.ban.tracks),inQueue=new Set(S.queue.map(t=>t.id));
  const ok=t=>isFullAudio(t)&&!played.has(t.id)&&!banned.has(t.id)&&!inQueue.has(t.id)&&(MyWave.ban.artists[normalize(t.artist)]||0)<2&&(!t.duration||t.duration>70&&t.duration<900);
  const wishPool=shuffled(wish.filter(ok));
  const pools=[ai,fam,rel,gen].map(p=>shuffled(p.filter(ok)));
  const aiShare=ai.length?(mode.ai??(MyWave.tune.prompt?.45:.3)):0;
  const want=[aiShare,...mode.mix.map(w=>w*(1-aiShare)/mode.mix.reduce((a,b)=>a+b,0))].map(w=>Math.round(w*n));const out=[],per=new Map(),seen=new Set();
  const take=(pool,k)=>{for(const t of pool){if(k<=0)break;const a=normalize(t.artist);if(seen.has(t.id)||(per.get(a)||0)>=2)continue;seen.add(t.id);per.set(a,(per.get(a)||0)+1);out.push(t);k--}};
  /* the wish fills about two thirds of every batch (no per-artist cap: «System of a Down» means System of a Down) */
  if(wishPool.length){let k=Math.round(n*.65);for(const t of wishPool){if(k<=0)break;if(seen.has(t.id))continue;seen.add(t.id);out.push(t);k--}}
  pools.forEach((p,i)=>take(p,Math.max(0,Math.round(want[i]*(n-out.length)/n))));if(out.length<n)pools.forEach(p=>take(p,n-out.length));
  // interleave so one pool never plays three in a row
  const aiIds=new Set(ai.map(t=>t.id));
  return shuffled(out).map(t=>({...t,_wave:true,_ai:aiIds.has(t.id)}));
}
async function injectAi(plan){
  const got=await aiTracks(plan).catch(()=>[]);if(!MyWave.on||!got.length)return;
  const inQueue=new Set(S.queue.map(t=>t.id)),banned=new Set(MyWave.ban.tracks),played=new Set(MyWave.played);
  const add=shuffled(got.filter(t=>isFullAudio(t)&&!inQueue.has(t.id)&&!banned.has(t.id)&&!played.has(t.id))).slice(0,5).map(t=>({...t,_wave:true,_ai:true}));
  if(add.length){S.queue.splice(S.idx+2,0,...add);toast('✦︎ ИИ добавил '+plural(add.length,'трек','трека','треков')+' в волну')}
}
function rememberPlayed(t){if(!t?._wave)return;MyWave.played=[t.id,...MyWave.played.filter(x=>x!==t.id)].slice(0,500);store.set('wavePlayed',MyWave.played)}
async function topUpWave(){
  if(!MyWave.on||MyWave.busy||S.idx<S.queue.length-3)return;MyWave.busy=true;
  try{const more=await waveBatch(12);if(MyWave.on&&more.length)S.queue.push(...more)}finally{MyWave.busy=false}
}
async function startWave(mode){
  if(mode&&WAVE_MODES[mode]){MyWave.mode=mode;store.set('waveMode',mode);paintWaveModes()}
  if(MyWave.busy)return;MyWave.busy=true;document.body.classList.add('wave-loading');
  try{
    const batch=await waveBatch(14);
    if(!batch.length){toast('Волна не собралась — проверь интернет');return}
    MyWave.on=true;if(S.shuffle){S.shuffle=false;store.set('shuffle',false)}
    await playTrack(batch,0);toast('Моя волна · '+WAVE_MODES[MyWave.mode].label);
  }catch{toast('Волна не собралась — проверь интернет')}
  finally{MyWave.busy=false;document.body.classList.remove('wave-loading');paintWaveState()}
}
function dislikeWave(){
  const t=cur();if(!t?._wave)return;
  MyWave.ban.tracks=[t.id,...MyWave.ban.tracks].slice(0,800);const a=normalize(t.artist);MyWave.ban.artists[a]=(MyWave.ban.artists[a]||0)+1;store.set('waveBan',MyWave.ban);
  toast(MyWave.ban.artists[a]>=2?'Больше не будем ставить '+t.artist:'Понял, такое реже');next();
}
/* Leaving the wave: anything started outside it switches it off. */
audio.addEventListener('loadstart',()=>{const t=cur();if(!t)return;if(!t._wave){if(MyWave.on){MyWave.on=false;paintWaveState()}return}rememberPlayed(t);topUpWave();paintWaveState()});
audio.addEventListener('play',paintWaveState);audio.addEventListener('pause',paintWaveState);

/* ---------- UI: banner on Home + dislike in the player ---------- */
function paintWaveModes(){const el=$('#waveModes');if(!el)return;const t=MyWave.tune,tuned=t.prompt||t.genres.length;
  el.innerHTML=Object.entries(WAVE_MODES).map(([k,m])=>`<button class="${k===MyWave.mode?'on':''}" data-wave-mode="${k}">${m.label}</button>`).join('')+`<button class="wave-tune-btn${tuned?' tuned':''}" data-wave-tune aria-label="Настроить волну"><svg><use href="#i-sliders"/></svg>${tuned?'Настроено':'Настроить'}</button>`}
function openWaveTune(){
  const t=MyWave.tune;const custom=t.genres.filter(g=>!AUDIUS_GENRES.some(x=>x[0]===g));
  openSheet({title:'Настроить волну',sub:'Пожелание, жанры и ИИ',tracks:[],cover:{title:'Моя волна',artist:'wave'}});$('#sheet').dataset.mode='tune';$('#sheetList').onclick=null;$('#sheetList').innerHTML='';
  const chips=()=>[...AUDIUS_GENRES.map(x=>x[0]),...custom].map(g=>`<button type="button" class="${t.genres.includes(g)?'on':''}" data-g="${esc(g)}">${esc(g)}</button>`).join('');
  $('#sheetActions').innerHTML=`<div class="wave-tune">
    <label class="field-label" for="tunePrompt">Что хочешь послушать</label>
    <textarea class="settings-input" id="tunePrompt" rows="2" maxlength="160" placeholder="Например: «грустный инди под дождь», «как Daft Punk, но свежее»">${esc(t.prompt)}</textarea>
    <p class="field-label">Жанры</p><div class="tune-genres" id="tuneGenres">${chips()}</div>
    <form class="tune-add" id="tuneAdd"><input class="settings-input" id="tuneGenreInput" maxlength="40" autocomplete="off" placeholder="Свой жанр: фонк, шугейз, синти‑поп…"><button class="chip" type="submit"><svg><use href="#i-plus"/></svg></button></form>
    <label class="toggle-row"><span><b>ИИ подбирает</b><small>Предлагает артистов и запросы под вкус и пожелание</small></span><input type="checkbox" id="tuneAi" ${t.ai?'checked':''}></label>
    <div class="api-actions"><button class="btn-accent" id="tuneGo"><svg><use href="#i-play"/></svg>Запустить волну</button><button class="text-link" id="tuneReset">Сбросить</button></div></div>`;
  $('#tuneGenres').onclick=e=>{const b=e.target.closest('[data-g]');if(!b)return;const g=b.dataset.g;t.genres=t.genres.includes(g)?t.genres.filter(x=>x!==g):[...t.genres,g].slice(-6);b.classList.toggle('on',t.genres.includes(g))};
  $('#tuneAdd').onsubmit=e=>{e.preventDefault();const v=$('#tuneGenreInput').value.trim().replace(/\s+/g,' ');if(v.length<2)return;if(!custom.includes(v)&&!AUDIUS_GENRES.some(x=>x[0].toLowerCase()===v.toLowerCase()))custom.push(v);if(!t.genres.includes(v))t.genres=[...t.genres,v].slice(-6);$('#tuneGenres').innerHTML=chips();$('#tuneGenreInput').value=''};
  $('#tuneReset').onclick=()=>{t.prompt='';t.genres=[];$('#tunePrompt').value='';$('#tuneGenres').innerHTML=chips()};
  $('#tuneGo').onclick=()=>{t.prompt=$('#tunePrompt').value.trim();t.ai=$('#tuneAi').checked;store.set('waveTune',t);closeSheet();paintWaveModes();MyWave.on=false;startWave(t.prompt&&t.ai?'ai':undefined)};
}
function paintWaveState(){
  const on=MyWave.on&&!!cur()?._wave,playing=on&&!audio.paused;
  document.body.classList.toggle('wave-on',on);document.body.classList.toggle('wave-playing',playing);
  const b=$('#wavePlay');if(b){b.innerHTML=`<svg><use href="#i-${playing?'pause':'play'}"/></svg>`;b.setAttribute('aria-label',playing?'Пауза':'Слушать мою волну')}
  const sub=$('#waveSub');if(sub)sub.textContent=on?`${cur().title} · ${cur().artist}`:'Бесконечный поток под твой вкус';
  const d=$('#waveDislike');if(d)d.hidden=!on;
}
$('#waveModes').onclick=e=>{if(e.target.closest('[data-wave-tune]'))return openWaveTune();const b=e.target.closest('[data-wave-mode]');if(!b)return;const m=b.dataset.waveMode;if(m==='ai'&&!MyWave.tune.prompt&&!MyWave.on){MyWave.mode='ai';store.set('waveMode','ai');paintWaveModes();return openWaveTune()}if(m===MyWave.mode&&MyWave.on)return;MyWave.mode=m;store.set('waveMode',m);paintWaveModes();if(MyWave.on){MyWave.on=false;startWave(m)}};
$('#wavePlay').onclick=e=>{e.stopPropagation();if(MyWave.on&&cur()?._wave){toggle();return}startWave()};
$('#waveCard').onclick=e=>{if(e.target.closest('#wavePlay,#waveModes'))return;if(MyWave.on&&cur()?._wave){$('#full').classList.add('open');return}startWave()};
$('#waveDislike').onclick=dislikeWave;
paintWaveModes();paintWaveState();

/* Flowing ribbons: drawn only while the banner is on screen; speed follows playback. */
(function waveCanvas(){
  const cv=$('#waveCanvas');if(!cv)return;const x=cv.getContext('2d',{willReadFrequently:true});let idleFrames=0,raf=0,visible=false,t=0,last=0,energy=.25,cols=null,colsAt=0,grad=null,gradW=0;
  const io=new IntersectionObserver(es=>{visible=es[0].isIntersecting;if(visible&&!raf)raf=requestAnimationFrame(frame)},{threshold:0});io.observe(cv);
  function frame(now){
    raf=0;if(!visible||document.hidden||view!=='home')return;
    if(last&&now-last<(typeof perfFrameGap==='function'?perfFrameGap():12.5)){raf=requestAnimationFrame(frame);return}
    const dt=Math.min(.05,(now-(last||now))/1000);last=now;
    const target=document.body.classList.contains('wave-playing')?1:(document.body.classList.contains('wave-loading')?.8:.25);energy+=(target-energy)*Math.min(1,dt*3);
    t+=dt*(.35+energy*.9);
    const dpr=Math.min(1.5,devicePixelRatio||1),w=cv.clientWidth,h=cv.clientHeight;if(!w){raf=requestAnimationFrame(frame);return}
    if(cv.width!==Math.round(w*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr)}
    x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,w,h);
    if(!cols||now-colsAt>1000){const cs=getComputedStyle(document.documentElement);const n=[cs.getPropertyValue('--accent').trim()||'#46b7ff',cs.getPropertyValue('--accent-2').trim()||'#8bf3e6'];colsAt=now;if(!cols||n[0]!==cols[0]||n[1]!==cols[1]){cols=n;grad=null}}
    if(!grad||gradW!==w){gradW=w;grad=x.createLinearGradient(0,0,w,0);grad.addColorStop(0,cols[0]);grad.addColorStop(1,cols[1])}
    for(let k=0;k<4;k++){
      const amp=h*(.1+.07*k)*(.55+energy*.6),freq=1.2+k*.45,ph=t*(1+k*.35)+k*1.7,y0=h*(.58+.05*k);
            x.beginPath();for(let i=0;i<=40;i++){const px=i/40*w,py=y0+Math.sin(i/40*Math.PI*2*freq+ph)*amp*Math.sin(i/40*Math.PI);i?x.lineTo(px,py):x.moveTo(px,py)}
      x.strokeStyle=grad;x.globalAlpha=.42-k*.08;x.lineWidth=2.4-k*.35;x.stroke();
    }
    x.globalAlpha=1;
    const idle=target<.3&&Math.abs(energy-target)<.01;
    if(idle&&document.documentElement.dataset.perf!=='high'&&idleFrames++>(document.documentElement.dataset.perf==='low'?1:90)){idleFrames=0;return}
    if(!idle)idleFrames=0;raf=requestAnimationFrame(frame);
  }
  new MutationObserver(()=>{if(visible&&!raf)raf=requestAnimationFrame(frame)}).observe(document.body,{attributes:true,attributeFilter:['class']});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&visible&&!raf)raf=requestAnimationFrame(frame)});
})();
/* 6.4.4: «Волна по треку» как в Яндекс Музыке — сам исполнитель, его фиты, похожие артисты (Deezer), ИИ только добивает */
const TW={on:false,next:[],used:new Set(),busy:false,seed:null};
const twMain=t=>{const a=typeof splitArtists==='function'?splitArtists(t.artist):[t.artist];const ft=/(?:feat\.?|ft\.?|при уч\.?|&)\s*([^()\[\]]+)/i.exec(t.title||'');return [...new Set([...a,...(ft?splitArtists(ft[1]):[])].map(x=>String(x||'').trim()).filter(Boolean))].slice(0,3)};
const twSim=(a,b)=>typeof artistSim==='function'?artistSim(a,b):similarity(a,b);
async function twArtistTracks(name,max){const r=await bounded(waveSearch(name),14000).catch(()=>[]);
  return r.filter(c=>isFullAudio(c)&&c.type!=='youtube'&&twSim(name,c.artist||'')>.75).sort((x,y)=>(y.plays||0)-(x.plays||0)).slice(0,max)}
async function twDeezer(name){try{const a=await deezerArtist(name);if(!a)return {rel:[],collab:[]};
  const [rel,top]=await Promise.all([extGet('https://api.deezer.com/artist/'+a.id+'/related?limit=25').catch(()=>({})),extGet('https://api.deezer.com/artist/'+a.id+'/top?limit=50').catch(()=>({}))]);
  const collab=(top.data||[]).flatMap(x=>(x.contributors||[]).map(c=>c.name)).filter(n=>n&&twSim(n,name)<.75);
  return {rel:(rel.data||[]).map(x=>x.name),collab:[...new Set(collab)]}}catch{return {rel:[],collab:[]}}}
async function twAiArtists(t,known){try{const ask=typeof lyrAi==='function'?lyrAi:aiAsk;
  const j=aiJSON(await ask('Ты музыкальный эксперт. Отвечай только JSON {"artists":["..."]}. Только реальные исполнители той же сцены и жанра, близкие по звучанию; лучше малоизвестные из той же тусовки, чем мейнстрим. Никаких «классиков» другого жанра.',`Исполнитель: ${t.artist}. Трек: «${t.title}».${known.length?' Уже известны похожие: '+known.slice(0,8).join(', ')+'.':''} Дай 12 похожих исполнителей.`));
  return (j.artists||[]).map(String).filter(x=>x&&x.length<60).slice(0,12)}catch{return []}}
async function trackWaveList(t){
  const main=twMain(t);TW.used=new Set([t.id]);
  const saved=[...S.favs,...S.recent,...(typeof Library!=='undefined'?Library.playlists.flatMap(p=>p.tracks||[]):[])].filter(x=>x&&isFullAudio(x)&&x.type!=='youtube'&&main.some(m=>twSim(m,x.artist||'')>.75));
  const [own,dz]=await Promise.all([Promise.all(main.map(m=>twArtistTracks(m,10))).then(l=>l.flat()),Promise.all(main.slice(0,2).map(twDeezer))]);
  /* collaborators: from the artist's own tracks (feat/&/,) and Deezer contributors */
  const collab=new Set(dz.flatMap(d=>d.collab));
  for(const x of [...own,...saved])for(const n of [...splitArtists(x.artist||''),...(twMain({artist:'',title:x.title}))])if(n&&!main.some(m=>twSim(m,n)>.75))collab.add(n);
  let rel=[...new Set(dz.flatMap(d=>d.rel))].filter(n=>!main.some(m=>twSim(m,n)>.75));
  if(rel.length<6)rel=[...rel,...(await twAiArtists(t,rel)).filter(n=>!main.some(m=>twSim(m,n)>.75)&&!rel.some(r=>twSim(r,n)>.8))];
  const col=[...collab].slice(0,6);rel=rel.filter(n=>!col.some(c=>twSim(c,n)>.8));const relNow=rel.slice(0,8);TW.next=rel.slice(8);TW.seed=t;
  const [colT,relT]=await Promise.all([Promise.all(col.map(n=>twArtistTracks(n,3))).then(l=>l.flat()),Promise.all(relNow.map(n=>twArtistTracks(n,4))).then(l=>l.flat())]);
  const pools=[shuffled([...new Map([...saved,...own].map(x=>[x.id,x])).values()]).slice(0,12),shuffled(colT),shuffled(relT)];
  return twMix(pools,40);
}
/* mix: own ≈ 30%, collabs ≈ 25%, related ≈ 45%; no artist twice in a row, ≤3 per artist (own ≤12) */
function twMix(pools,n){const out=[],per=new Map(),order=[0,2,1,2,0,2,1,2];let i=0,dry=0;
  while(out.length<n&&dry<order.length*2){const p=pools[order[i++%order.length]],t=p.find(x=>{const a=normalize(x.artist||'');return !TW.used.has(x.id)&&(per.get(a)||0)<(p===pools[0]?12:3)&&normalize(out[out.length-1]?.artist||'')!==a});
    if(!t){dry++;continue}dry=0;TW.used.add(t.id);const a=normalize(t.artist||'');per.set(a,(per.get(a)||0)+1);out.push({...t,_tw:true,_ai:true})}
  return out}
async function twMore(){if(!TW.on||TW.busy||!TW.next.length)return;TW.busy=true;
  try{const names=TW.next.splice(0,6);const got=(await Promise.all(names.map(n=>twArtistTracks(n,4)))).flat();
    const add=twMix([[],shuffled(got),shuffled(got)],20);if(add.length&&TW.on)S.queue.push(...add);
    if(TW.next.length<6&&TW.seed){const more=await twAiArtists(TW.seed,names);TW.next.push(...more)}}finally{TW.busy=false}}
audio.addEventListener('loadstart',()=>{const t=cur();if(!t?._tw){TW.on=false;return}if(S.idx>=S.queue.length-5)twMore()});
async function openTrackWave(){
  const t=cur();if(!t){toast('Сначала включи трек');return}
  openSheet({title:'Волна по треку',sub:'ИИ подбирает похожее на «'+t.title+'»…',tracks:null,cover:t});
  const token=Symbol();openTrackWave.token=token;
  try{const list=await trackWaveList(t);if(openTrackWave.token!==token||$('#sheet').dataset.mode!=='list')return;
    if(!list.length){$('#sheetList').innerHTML='<div class="empty"><b>Не нашлось</b><span>ИИ не подобрал треки, которые есть в источниках. Попробуй позже.</span></div>';return}
    $('#sheetSub').textContent=plural(list.length,'трек','трека','треков')+' · похоже на «'+t.title+'»';
    $('#sheetActions').innerHTML='<button class="btn-accent" id="twPlay"><svg><use href="#i-play"/></svg>Слушать волну</button><button class="chip" id="twNext"><svg><use href="#i-queue"/></svg>После текущего</button><button class="chip" id="twSave"><svg><use href="#i-plus"/></svg>В плейлист</button>';
    renderList($('#sheetList'),list);
    $('#twSave').onclick=()=>saveAsPlaylist([t,...list],'Волна: '+t.title);$('#twPlay').onclick=()=>{closeSheet();TW.on=true;playTrack([{...t,_tw:true},...list],0)};
    $('#twNext').onclick=()=>{S.queue.splice(S.idx+1,0,...list.filter(x=>!S.queue.some(q=>q.id===x.id)));toast('Добавлено в очередь: '+plural(list.length,'трек','трека','треков'));closeSheet()};
  }catch(e){if(openTrackWave.token===token)$('#sheetList').innerHTML=`<div class="empty"><b>Не получилось</b><span>${esc(e.message||'ИИ недоступен')}</span></div>`}
}
(()=>{const nav=$('.player-bottom-nav');if(!nav||$('#trackWave'))return;nav.querySelector('#aiSimilar')?.insertAdjacentHTML('beforebegin','<button class="chip" id="trackWave"><svg><use href="#i-wave"/></svg>Волна</button>');$('#trackWave').onclick=openTrackWave})();

/* 6.5.2: any wave → playlist */
async function saveAsPlaylist(tracks,name){
  const list=[...new Map((tracks||[]).filter(t=>t&&t.type!=='radio'&&isFullAudio(t)).map(t=>[t.id,t])).values()];
  if(!list.length){toast('Нечего сохранять');return null}
  const n=(await askText('Название плейлиста',name||'Волна '+new Date().toLocaleDateString('ru-RU'))||'').trim();if(!n)return null;
  const pl=Library.create(n);list.forEach(t=>{const {_wave,_ai,_tw,...c}=t;Library.toggle(pl,c)});Library.save();
  if(typeof offlineSync==='function')offlineSync();if(view==='library')renderLib();
  toast('Плейлист «'+n+'» · '+plural(list.length,'трек','трека','треков'));return pl}
