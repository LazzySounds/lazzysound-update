'use strict';
/* Lazzy sound 3.3 — brand: the chosen logo everywhere, the launcher-icon picker and the start-up intro. */
const ICON_IDS=Object.keys(LAZZY_LOGOS);
let appIcon=(()=>{try{const n=window.LumenNative?.getAppIcon?.();if(n&&LAZZY_LOGOS[n])return n}catch{}const s=store.get('appIcon','wave');return LAZZY_LOGOS[s]?s:'wave'})();
function paintBrand(){const m=$('#brandMark');if(m)m.innerHTML=logoSVG(appIcon,'logo')}
function renderIconPicker(){
  const el=$('#iconChoices');if(!el)return;
  el.innerHTML=ICON_IDS.map(id=>`<button class="icon-choice${id===appIcon?' on':''}" data-icon="${id}" aria-pressed="${id===appIcon}">${logoSVG(id)}<span>${LAZZY_LOGOS[id].name}</span></button>`).join('');
  el.onclick=e=>{const b=e.target.closest('[data-icon]');if(!b||b.dataset.icon===appIcon)return;appIcon=b.dataset.icon;store.set('appIcon',appIcon);paintBrand();renderIconPicker();
    let ok=false;try{ok=!!window.LumenNative?.setAppIcon?.(appIcon[0].toUpperCase()+appIcon.slice(1))}catch{}
    toast(ok?'Значок на рабочем столе обновится через пару секунд':'Логотип в приложении обновлён');
    b.querySelector('svg')?.animate([{transform:'scale(.8) rotate(-8deg)'},{transform:'none'}],{duration:600,easing:typeof SPRING!=='undefined'?SPRING:'ease-out'})};
}
paintBrand();renderIconPicker();

/* ---------- Intro: the logo catches the light, the name rises, the app opens from the mark ---------- */
(function intro(){
  const el=$('#intro');if(!el)return;
  let finished=false;const done=()=>{if(finished)return;finished=true;el.remove();document.dispatchEvent(new Event('lazzy:intro-done'))};
  const reduce=document.documentElement.dataset.motion==='reduce'||window.LZ_OSREDUCE===true;
  $('#introLogo').innerHTML=logoSVG(appIcon)+'<span class="intro-glare" id="introGlare"></span>';
  const word=$('#introWord');word.innerHTML=[...'lazzy'].map(c=>`<i>${c}</i>`).join('')+'<b>'+[...'sound'].map(c=>`<i>${c}</i>`).join('')+'</b>';
  if(reduce){el.animate([{opacity:1},{opacity:0}],{duration:200,delay:150,fill:'forwards'}).onfinish=done;return}
  const spring=(()=>{const pts=[];let x=0,v=0;for(let i=0;i<=60;i++){pts.push(+x.toFixed(4));const a=150*(1-x)-16*v;v+=a/60;x+=v/60}pts[60]=1;const s=`linear(${pts.join(',')})`;return CSS.supports('animation-timing-function',s)?s:'cubic-bezier(.34,1.4,.5,1)'})();
  const logo=$('#introLogo'),glare=$('#introGlare'),ring=$('#introRing');
  logo.animate([{transform:'scale(.86)',filter:'brightness(1)'},{transform:'scale(1)',filter:'brightness(1.15)',offset:.5},{transform:'scale(1)',filter:'brightness(1)'}],{duration:900,easing:spring,fill:'both'});
  /* the wave rises bar by bar, overshoots like a VU meter, settles */
  logo.querySelectorAll('.lz-bar').forEach((b,i)=>{b.style.transformBox='fill-box';b.style.transformOrigin='50% 50%';b.animate([{transform:'scaleY(.12)'},{transform:'scaleY(1.18)',offset:.55},{transform:'scaleY(.92)',offset:.8},{transform:'scaleY(1)'}],{duration:760,delay:110+i*55,easing:'cubic-bezier(.3,.7,.3,1)',fill:'both'})});
  glare.animate([{transform:'translateX(-120%) rotate(18deg)',opacity:0},{opacity:1,offset:.3},{transform:'translateX(120%) rotate(18deg)',opacity:0}],{duration:900,delay:420,easing:'ease-in-out',fill:'both'});
  ring.animate([{transform:'scale(.6)',opacity:.0},{transform:'scale(1)',opacity:.7,offset:.35},{transform:'scale(1.9)',opacity:0}],{duration:1300,delay:300,easing:'cubic-bezier(.16,1,.3,1)',fill:'both'});
  [...word.querySelectorAll('i')].forEach((c,i)=>c.animate([{transform:'translateY(110%)',opacity:0},{transform:'none',opacity:1}],{duration:700,delay:520+i*38,easing:spring,fill:'both'}));
  const out=document.documentElement.dataset.perf==='low'?1050:1650;
  setTimeout(()=>{
    logo.animate([{transform:'scale(1)',opacity:1},{transform:'scale(5)',opacity:0}],{duration:620,easing:'cubic-bezier(.7,0,.2,1)',fill:'forwards'});
    word.animate([{transform:'none',opacity:1},{transform:'translateY(20px)',opacity:0}],{duration:360,easing:'ease-in',fill:'forwards'});
    el.animate([{opacity:1},{opacity:0}],{duration:520,delay:180,easing:'ease-out',fill:'forwards'}).onfinish=done;
  },out);
  el.addEventListener('click',()=>{el.getAnimations({subtree:true}).forEach(a=>a.finish?.());el.animate([{opacity:1},{opacity:0}],{duration:200,fill:'forwards'}).onfinish=done},{once:true});
})();
