'use strict';
/* 6.5.1 PC/web: ‹ › arrows on every horizontal row (albums, similar artists, clips, mixes…) — the wheel can't scroll them sideways */
(function(){
  if(!matchMedia('(pointer:fine)').matches)return;
  const SEL='.cards,.artist-hits,.dym-songs,.sk-row';
  const upd=w=>{const r=w._row;if(!r)return;const max=r.scrollWidth-r.clientWidth-2;w.classList.toggle('hs-l',r.scrollLeft>2);w.classList.toggle('hs-r',r.scrollLeft<max);w.classList.toggle('hs-none',max<=2)};
  function wrap(r){
    if(r._hs||!r.parentNode)return;r._hs=1;
    const w=document.createElement('div');w.className='hs-wrap';r.parentNode.insertBefore(w,r);w.appendChild(r);w._row=r;
    w.insertAdjacentHTML('beforeend','<button class="hs-btn hs-prev" aria-label="Назад" tabindex="-1"><svg><use href="#i-back"/></svg></button><button class="hs-btn hs-next" aria-label="Вперёд" tabindex="-1"><svg><use href="#i-back"/></svg></button>');
    const go=d=>r.scrollBy({left:d*Math.max(160,r.clientWidth*.8),behavior:'smooth'});
    w.querySelector('.hs-prev').onclick=e=>{e.stopPropagation();go(-1)};w.querySelector('.hs-next').onclick=e=>{e.stopPropagation();go(1)};
    r.addEventListener('scroll',()=>upd(w),{passive:true});
    /* vertical wheel over a row scrolls it sideways only while it can move that way */
    r.addEventListener('wheel',e=>{if(Math.abs(e.deltaX)>Math.abs(e.deltaY)||e.ctrlKey)return;const max=r.scrollWidth-r.clientWidth;if(max<=2)return;
      if((e.deltaY>0&&r.scrollLeft<max-1)||(e.deltaY<0&&r.scrollLeft>1)){e.preventDefault();r.scrollBy({left:e.deltaY,behavior:'auto'})}},{passive:false});
    new ResizeObserver(()=>upd(w)).observe(r);new MutationObserver(()=>upd(w)).observe(r,{childList:true});upd(w);
  }
  const scan=root=>{(root.matches?.(SEL)?[root]:[]).concat([...(root.querySelectorAll?.(SEL)||[])]).forEach(wrap)};
  scan(document.body);
  new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes)if(n.nodeType===1)scan(n)}).observe(document.body,{childList:true,subtree:true});
})();
