'use strict';
/* Lazzy sound 5.5 — exact lyrics timing with Whisper word timestamps (free Groq key, or your OpenAI-compatible AI key).
   The track's audio is transcribed once (cached), the lyrics' words are aligned to the recognised words, and every word
   gets the moment it is actually sung. Plain lyrics without timings become synced too. */
const ASR={on:store.get('asrOn',true)!==false,pending:new Map()};
window.__lazzyAsr=(id,payload)=>{const p=ASR.pending.get(id);if(!p)return;ASR.pending.delete(id);clearTimeout(p.t);try{const j=JSON.parse(payload);if(j.error)throw new Error(j.error);p.res(j)}catch(e){p.rej(e)}};
(function builtInKey(){const k=(window.LAZZY_CONFIG||{}).groqKey;if(!k)return;try{if(!LumenNative?.hasAsrKey?.()||store.get('asrKeyV','')!==k.slice(-6)){LumenNative.saveAsrKey(k);store.set('asrKeyV',k.slice(-6))}}catch{}})();
const asrHasKey=()=>{try{return !!window.LumenNative?.hasAsrKey?.()}catch{return false}};
const asrAiGroq=()=>typeof aiHasKey==='function'&&aiHasKey()&&/groq\.com|openai\.com/.test(AiConf.endpoint||'')&&AiConf.provider==='openai';
const asrWeb=()=>!window.LumenNative&&!!(window.LAZZY_CONFIG||{}).groqKey;
const asrReady=()=>ASR.on&&((!!window.LumenNative?.asrWords&&(asrHasKey()||asrAiGroq()))||asrWeb()||!!(window.LAZZY_CONFIG||{}).groqKey);
const asrNorm=w=>String(w||'').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g,'').replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,'');
function asrSim(a,b){if(a===b)return 1;if(!a||!b)return 0;const m=a.length,n=b.length;if(Math.abs(m-n)>Math.max(m,n)*.6)return 0;let prev=Array.from({length:n+1},(_,j)=>j);
  for(let i=1;i<=m;i++){const cur=[i];for(let j=1;j<=n;j++)cur[j]=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));prev=cur}return 1-prev[n]/Math.max(m,n)}
/* global alignment (Needleman–Wunsch) of lyric words to recognised words → index map */
function asrAlign(L,R){
  const n=L.length,m=R.length,G=-.6,S=new Float32Array((n+1)*(m+1)),B=new Uint8Array((n+1)*(m+1)),W=m+1;
  for(let i=1;i<=n;i++){S[i*W]=i*G;B[i*W]=1}for(let j=1;j<=m;j++){S[j]=j*G;B[j]=2}
  for(let i=1;i<=n;i++)for(let j=1;j<=m;j++){const sim=asrSim(L[i-1],R[j-1]),d=S[(i-1)*W+j-1]+(sim>=.67?1+sim:-.8),u=S[(i-1)*W+j]+G,l=S[i*W+j-1]+G;
    if(d>=u&&d>=l){S[i*W+j]=d;B[i*W+j]=sim>=.67?0:3}else if(u>=l){S[i*W+j]=u;B[i*W+j]=1}else{S[i*W+j]=l;B[i*W+j]=2}}
  const map=new Array(n).fill(-1);let i=n,j=m;while(i>0&&j>0){const b=B[i*W+j];if(b===0){map[i-1]=j-1;i--;j--}else if(b===3){i--;j--}else if(b===1)i--;else j--}
  return map;
}
async function asrFetch(t){
  const N=window.LumenNative,cacheKey='asr:'+t.id;
  try{const c=await DB.collection(cacheKey);if(c?.items?.words)return c.items}catch{}
  let url=cur()?.id===t.id&&/^https?:\/\//.test(audio.currentSrc||'')?audio.currentSrc:'';
  if(!url&&typeof isOffline==='function'&&isOffline(t))url=offlineUrl(t);
  if(!url&&/^https:\/\//.test(t.src||''))url=(typeof resolveStream==='function'?await resolveStream(t.src,4000):'')||t.src;
  if(!url&&t.type==='soundcloud'&&typeof scResolve==='function')url=await scResolve(t).catch(()=>'');
  if(!url)throw new Error('нет ссылки на аудио');
  /* 6.3.2: Hitmoz — prefer the same recording elsewhere, otherwise try the Hitmoz file itself (it plays, so it can usually be fetched) */
  if(isHitmoz(t,url)){const alt=await altSourceUrl(t).catch(()=>'');if(alt)url=alt}
  if(asrWeb()){const out=await asrDirect(url,LAZZY_CONFIG.groqKey);try{await DB.saveCollection(cacheKey,out)}catch{}return out}
  let src=url,name='';
  if(N.fetchAudio){const ru=window.hitmozAlt?.(url);let r=null;if(ru){r=await nativeCall('fetchAudio',[ru],150000);if(!r?.src&&N.webFetchAudio)r=await nativeCall('webFetchAudio',[ru],160000);if(r?.src)url=ru}
    if(!r?.src)r=await nativeCall('fetchAudio',[url],150000);
    if(!r?.src&&N.webFetchAudio){const w=await nativeCall('webFetchAudio',[url],160000);if(w?.src)r=w}
    if(!r?.src){const fresh=await freshTrackUrl(t,url);if(fresh){r=await nativeCall('fetchAudio',[fresh],150000);if(r?.src)url=fresh}}
    if(!r?.src){const alt=await altSourceUrl(t);if(alt){r=await nativeCall('fetchAudio',[alt],150000);if(r?.src)url=alt}}
    if(!r?.src){/* the WebView itself plays this stream — let it fetch the bytes and talk to Whisper directly */
      const k=(window.LAZZY_CONFIG||{}).groqKey;const host=(()=>{try{return new URL(url).host}catch{return '?'}})();if(!k)throw new Error('не удалось скачать трек с '+host+' ('+(r?.error||'нет ответа')+')');
      const out=await asrDirect(url,k).catch(e=>{throw new Error('не удалось скачать трек с '+host+' ('+(r?.error||'нет ответа')+'; '+e.message+')')});try{await DB.saveCollection(cacheKey,out)}catch{}return out}
    name=r.src.split('/').pop();src=name;
    /* 6.3.3: no key stored natively → send the downloaded copy (same-origin) to Whisper with the built-in key */
    if(!asrHasKey()&&!asrAiGroq()&&(window.LAZZY_CONFIG||{}).groqKey){try{const out=await asrDirect(new URL(r.src,location.href).href,LAZZY_CONFIG.groqKey);try{await DB.saveCollection(cacheKey,out)}catch{}return out}finally{try{N.envDone?.(name)}catch{}}}}
  else if(url.startsWith(location.origin))src=new URL(url).pathname;
  const ai=!asrHasKey(),ep=ai?(AiConf.endpoint||'https://api.groq.com/openai/v1'):'https://api.groq.com/openai/v1',model=/openai\.com/.test(ep)?'whisper-1':'whisper-large-v3-turbo';
  try{
    const j=await new Promise((res,rej)=>{const id='asr-'+Date.now();const tm=setTimeout(()=>{ASR.pending.delete(id);rej(new Error('Whisper долго отвечает'))},240000);ASR.pending.set(id,{res,rej,t:tm});
      try{N.asrWords(src,ep,model,'',ai,id)}catch(e){clearTimeout(tm);ASR.pending.delete(id);rej(e)}});
    const words=(j.words||[]).map(w=>({w:String(w.word||'').trim(),s:+w.start,e:+w.end})).filter(w=>w.w&&isFinite(w.s));
    if(words.length<5)throw new Error('Whisper не услышал слов');
    const out={words,lang:j.language||''};try{await DB.saveCollection(cacheKey,out)}catch{}return out;
  }finally{if(name)try{N.envDone?.(name)}catch{}}
}
/* Hitmoz links are short-lived/one-shot: ask the source again for a fresh link to the same song */
async function freshTrackUrl(t,old){
  try{if(t.type!=='hitmoz'||typeof searchHitmoz!=='function')return '';const list=await searchHitmoz(`${t.artist||''} ${t.title||''}`.trim());
    const n=x=>String(x||'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,'');const hit=list.find(x=>x.id===t.id)||list.find(x=>n(x.title)===n(t.title)&&n(x.artist)===n(t.artist));
    return hit&&hit.src&&hit.src!==old?hit.src:''}catch{return ''}
}
window.freshTrackUrl=freshTrackUrl;
/* the same recording from another source (same length ±2 s) — used only to time the lyrics when the original host blocks downloads */
async function altSourceUrl(t){
  try{if(typeof sourceJobs!=='function'||!t.duration)return '';const q=`${cleanArtist(t.artist)} ${cleanTitle(t.title)}`.trim();
    const jobs=sourceJobs(q,{withLocal:false,withCatalog:false,withRadio:false}).filter(([s])=>s!==t.type&&s!=='hitmoz');
    const found=(await Promise.all(jobs.map(([s,fn])=>cachedSearch(s,q,fn).catch(()=>[])))).flat();
    let best=null,bs=0;for(const c of found){if(!isFullAudio(c)||!c.duration||Math.abs(c.duration-t.duration)>2)continue;
      const sc=similarity(normalize(cleanTitle(t.title)),normalize(cleanTitle(c.title)))*.6+similarity(normalize(cleanArtist(t.artist)),normalize(cleanArtist(c.artist)))*.4;if(sc>bs&&sc>=.8){bs=sc;best=c}}
    if(!best)return '';if(best.type==='soundcloud')return await scResolve(best).catch(()=>'');if(best.type==='audius')return (await resolveStream(best.src,4000))||best.src;return best.src||''}catch{return ''}
}
window.altSourceUrl=altSourceUrl;
async function asrDirect(url,key){
  const blob=await (await fetch(url,{credentials:'omit'})).blob();if(blob.size<20000)throw new Error('пустой файл');if(blob.size>25*1024*1024)throw new Error('больше 25 МБ');
  const fd=new FormData();fd.append('model','whisper-large-v3-turbo');fd.append('response_format','verbose_json');fd.append('timestamp_granularities[]','word');fd.append('temperature','0');fd.append('file',blob,'track.mp3');
  const r=await fetch('https://api.groq.com/openai/v1/audio/transcriptions',{method:'POST',headers:{Authorization:'Bearer '+key},body:fd});if(!r.ok)throw new Error('Whisper HTTP '+r.status);
  const j=await r.json();const words=(j.words||[]).map(w=>({w:String(w.word||'').trim(),s:+w.start,e:+w.end})).filter(w=>w.w&&isFinite(w.s));if(words.length<5)throw new Error('Whisper не услышал слов');return {words,lang:j.language||''};
}
const LS=()=>Ly.synced&&!Ly.est;
async function asrApply(res,t){
  if(!asrReady()||!t||t.type==='radio'||res?.missing||res?.instrumental)return;
  const say=m=>{if(Ly.open&&cur()?.id===t.id)$('#lySrc').textContent=m};
  say('Точная синхронизация: распознаём слова (Whisper)…');
  let R;try{R=await asrFetch(t)}catch(e){say(e.calm?Ly.est?'≈ Примерные тайминги по длине трека (источник не дал файл для точных) — подстрой ± · '+(res.src||''):(LS()?'источник не дал файл — строки по таймингам':'Текст без таймингов (в LRCLIB нет, источник не дал звук) — «✍ Записать тайминги»')+' · '+(res.src||''):'Whisper: '+e.message+' · '+(res.src||''));return}
  if(cur()?.id!==t.id||Ly.id!==t.id)return;
  /* tempo-scaled lyrics (slowed / sped-up upload): move everything to audio time first */
  if(LS()&&Sync.scale!==1){const k=Sync.scale;Ly.lines.forEach(l=>l.t*=k);Ly.words.forEach(ws=>ws&&ws.forEach(w=>{w.s*=k;w.e*=k}));Sync.scale=1;if(Env.data)buildLyrEnv();Ly.align=[];Ly.plan=null}
  /* lyric lines → words (synced lines as they are; plain text becomes lines) */
  let lines=LS()?Ly.lines.map(l=>l.text.replace(WORD_TAG,'').trim()):String(res.plain||'').split('\n').map(x=>x.trim());
  const flat=[];lines.forEach((tx,i)=>tx.split(/\s+/).filter(Boolean).forEach((w,k)=>flat.push({i,k,w,n:asrNorm(w)})));
  const toks=flat.filter(x=>x.n);if(toks.length<4)return;
  const map=asrAlign(toks.map(x=>x.n),R.words.map(w=>asrNorm(w.w)));
  const hit=map.filter(x=>x>=0).length;if(hit/toks.length<.35){say('Whisper: текст не совпал с песней ('+Math.round(hit/toks.length*100)+'%) · '+(res.src||''));return}
  /* times for every token; unmatched ones are interpolated between neighbours */
  toks.forEach((x,k)=>{if(map[k]>=0){x.s=R.words[map[k]].s;x.e=R.words[map[k]].e}});
  /* repeated choruses can be matched to the wrong repeat: with LRC line times, keep only matches near their line
     (after the global shift), then force times to only move forward */
  if(LS()){const d=toks.filter(x=>x.s!=null).map(x=>x.s-Ly.lines[x.i].t).sort((a,b)=>a-b),off=d.length?d[d.length>>1]:0;
    toks.forEach(x=>{if(x.s!=null){const exp=Ly.lines[x.i].t+off,nx=(Ly.lines[x.i+1]?.t??exp+10)+off;if(x.s<exp-2.5||x.s>nx+1.5){x.s=null;x.e=null}}})}
  let last=-1;toks.forEach(x=>{if(x.s==null)return;if(x.s<last){x.s=null;x.e=null}else last=x.s});
  const kept=toks.filter(x=>x.s!=null).length;if(kept/toks.length<.3){say('Whisper: слишком мало совпадений — строки по таймингам · '+(res.src||''));return}
  toks.forEach(x=>{if(x.s!=null)x.m=1});
  const matchedLine=new Set(toks.filter(x=>x.s!=null).map(x=>x.i));
  try{const n=await asrLlmGaps(t,lines,toks,R,matchedLine);if(n)say('Точная синхронизация: ИИ расставил '+n+' строк…')}catch{}
  for(let k=0;k<toks.length;k++)if(toks[k].s==null){let a=k-1;while(a>=0&&toks[a].s==null)a--;let b=k+1;while(b<toks.length&&toks[b].s==null)b++;
    const t0=a>=0?toks[a].e:(b<toks.length?toks[b].s-1.5:0),t1=b<toks.length?toks[b].s:t0+1.5,gap=b-a;for(let q=a+1;q<b;q++){const f=(q-a)/gap;toks[q].s=t0+(t1-t0)*f-.01;toks[q].e=Math.min(t1,toks[q].s+(t1-t0)/gap)}k=b-1}
  const lineT=[];toks.forEach(x=>{if(lineT[x.i]==null)lineT[x.i]=x.s});
  if(LS()){const d=toks.filter(x=>matchedLine.has(x.i)).map(x=>lineT[x.i]-Ly.lines[x.i].t).sort((a,b)=>a-b),off=d.length?d[d.length>>1]:0;lineT.forEach((v,i)=>{if(v!=null&&!matchedLine.has(i))lineT[i]=Ly.lines[i].t+off})}
  {let prev=-1;for(let i=0;i<lineT.length;i++){if(lineT[i]==null)continue;if(lineT[i]<prev+.15)lineT[i]=prev+.15;prev=lineT[i]}}
  if(!LS()){ /* plain → synced, then render again */
    const synced=[];lines.forEach((tx,i)=>{if(tx&&lineT[i]!=null)synced.push({t:Math.max(0,lineT[i]-.08),text:tx})});
    if(synced.length<3)return;const newI=[];let q=0;lines.forEach((tx,i)=>{if(tx&&lineT[i]!=null)newI[i]=q++});
    const lt2=[];lineT.forEach((v,i)=>{if(newI[i]!=null)lt2[newI[i]]=v});
    baseLyrRender({...res,synced,estimated:false});toks.forEach(x=>{x.i=newI[x.i]});lineT.length=0;lt2.forEach((v,i)=>lineT[i]=v);
  }
  Ly.asr=true;Sync.auto=0;Sync.scale=1;paintOffset();
  Ly.lines.forEach((L,i)=>{if(lineT[i]!=null&&Ly.synced)L.t=Math.max(0,lineT[i]-.08)});
  asrEnvRefine(t,toks);
  for(const x of toks){const ws=Ly.words[x.i];const w=ws&&ws[x.k];if(w){w.s=x.s;w.e=Math.max(x.s+.08,x.e);w.sy=asrSyl(x.w,w.s,w.e,t)}}
  Ly.words.forEach(ws=>{if(ws)ws._fit=1});
  Ly.align=Ly.lines.map(()=>false);Ly.plan=null;Ly.gLine=-1;Ly.wk=-2;Ly.idx=-1;renderAligned();sync(true);
  say(`Точная синхронизация по словам (Whisper) · ${Math.round(hit/toks.length*100)}% слов · ${res.src||''}`);
}
/* ---------- phrase analysis: LLM places lines Whisper missed, envelope = forced-alignment-lite, syllables ---------- */
const ASR_LLM='qwen/qwen3.8-27b';
async function asrLlmGaps(t,lines,toks,R,matchedLine){
  if(typeof aiVisionCall!=='function'||!(window.LAZZY_CONFIG||{}).groqKey)return 0;
  const gaps=[];let i=0;const nL=lines.length;
  while(i<nL){if(!lines[i]||matchedLine.has(i)||!toks.some(x=>x.i===i)){i++;continue}let j=i;while(j<nL&&!matchedLine.has(j))j++;
    const prev=toks.filter(x=>x.i<i&&x.s!=null).pop(),next=toks.find(x=>x.i>=j&&x.s!=null);
    const a=prev?prev.e:0,b=next?next.s:(R.words[R.words.length-1]?.e||0)+2;if(b-a>1)gaps.push({a,b,ids:Array.from({length:j-i},(_,k)=>i+k).filter(k=>lines[k])});i=j}
  if(!gaps.length)return 0;
  const key='asrl:'+t.id,sig=gaps.map(g=>g.ids.join(',')).join('|');let ans=null;
  try{const c=await DB.collection(key);if(c?.items?.sig===sig)ans=c.items.ans}catch{}
  if(!ans){
    const f=v=>v.toFixed(2);
    const prompt=gaps.slice(0,12).map((g,n)=>`GAP ${n}: window ${f(g.a)}–${f(g.b)} s\nheard: ${R.words.filter(w=>w.s>=g.a-.2&&w.e<=g.b+.2).map(w=>`[${f(w.s)}-${f(w.e)}] ${w.w}`).join(' ')||'(nothing recognised)'}\nlines:\n${g.ids.map(k=>`${k}: ${lines[k]}`).join('\n')}`).join('\n\n');
    const sys='You time song lyrics. For each lyric line give its start time in seconds, inside its gap window, in increasing order, matching the heard word timings (sung words, syllables, pauses). Lines may be sung over unrecognised audio: spread them by syllable count. Reply JSON only: {"<line>":<start>,...}';
    const raw=String(await aiVisionCall('groq','',ASR_LLM,sys,'/no_think\n'+prompt,'')).replace(/<think>[\s\S]*?<\/think>/gi,'');ans=JSON.parse((raw.match(/\{[\s\S]*\}/)||['{}'])[0]);
    try{await DB.saveCollection(key,{sig,ans})}catch{}}
  let n=0;for(const g of gaps){let last=g.a;for(const k of g.ids){const v=+ans[k];if(!isFinite(v)||v<last||v>=g.b)continue;const x=toks.find(y=>y.i===k);if(!x)continue;x.s=v;x.e=v+.25;last=v+.2;matchedLine.add(k);n++}}
  return n;
}
function asrEnvRefine(t,toks){
  const E=typeof Env!=='undefined'&&Env.id===t.id?Env.data:null;if(!E||E.length<100)return;
  const at=s=>E[Math.max(0,Math.min(E.length-1,Math.round(s*100)))]||0;
  for(let k=0;k<toks.length;k++){const x=toks[k];if(!x.m)continue;const nx=toks[k+1];
    let bf=-1,bd=14;for(let f=Math.round((x.s-.15)*100);f<=Math.round((x.s+.12)*100);f++){const d=at((f+2)/100)-at((f-2)/100);if(d>bd){bd=d;bf=f}}
    let pk=0;for(let f=Math.round(x.s*100);f<=Math.round(x.e*100);f++)pk=Math.max(pk,at(f/100));
    let e=x.e;while(e>x.s+.1&&at(e)<pk-25)e-=.01;
    const lim=nx&&nx.s!=null?nx.s-.03:e+1.5;while(e<lim&&at(e+.01)>=pk-12)e+=.01;x.e=Math.max(x.s+.08,e)}
}
const SYL_V=/[aeiouyаеёиоуыэюяіїєáéíóúàèìòùäöü]+/gi;
function asrSyl(word,s,e,t){
  const L=word.length;const g=[...word.matchAll(SYL_V)];if(g.length<2||e-s<.2)return null;
  const cb=[];for(let k=0;k<g.length-1;k++){const end=g[k].index+g[k][0].length,nxt=g[k+1].index;cb.push((end+Math.floor((nxt-end)/2))/L)}cb.push(1);
  const E=typeof Env!=='undefined'&&Env.id===t?.id?Env.data:null;let tb=null;
  if(false){const f0=Math.round(s*100),f1=Math.round(e*100),dips=[];for(let f=f0+4;f<=f1-4;f++){const v=E[f];if(v<=E[f-1]&&v<=E[f+1]&&Math.min(E[f-4],E[f+4])-v>=6)dips.push({f,d:Math.min(E[f-4],E[f+4])-v})}
    const pick=dips.sort((a,b)=>b.d-a.d).filter((d,i,arr)=>arr.slice(0,i).every(o=>Math.abs(o.f-d.f)>=6)).slice(0,g.length-1);
    if(pick.length===g.length-1)tb=pick.map(d=>(d.f/100-s)/(e-s)).sort((a,b)=>a-b).concat(1)}
  if(!tb){const per=e-s,held=per/g.length>.45,base=held?(per-.3*(g.length-1))/per:0;tb=cb.map((c,k)=>k===g.length-1?1:held?(.3*(k+1))/per:c)}
  return {t:tb,c:cb};
}
const baseLyrRender=render;
render=function(res){baseLyrRender(res);const t=cur();if(t)asrApply(res,t)};
/* plain lyrics are rendered through render() too, so they get synced as well */

/* ---------- settings ---------- */
function renderAsrSettings(){
  const host=$('#asrSettings');if(!host)return;
  host.innerHTML=`<div class="setting-title"><svg><use href="#i-mic"/></svg><h2>Точная синхронизация текста</h2></div>
    <p class="settings-help">Whisper распознаёт, когда звучит каждое слово, и текст подсвечивается точно по голосу — даже у песен без таймингов. Один раз на трек, результат сохраняется.</p>
    <label class="toggle-row"><span><b>Включить</b><small>${asrReady()?'Работает':'Недоступно в этой версии'}</small></span><input type="checkbox" id="asrOn" ${ASR.on?'checked':''}></label>`;
  $('#asrOn').onchange=e=>{ASR.on=e.target.checked;store.set('asrOn',ASR.on);renderAsrSettings()};
}
renderAsrSettings();
